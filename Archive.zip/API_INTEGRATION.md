# OMS REST API Integration

The UI reads and writes through `src/services/omsApi.ts`. It uses the populated mock REST adapter by default, so the demo works without a server.

## Connect a backend

Create `.env.local` from `.env.example` and set:

```env
VITE_API_BASE_URL=http://localhost:8080/api/v1
VITE_API_TIMEOUT_MS=15000
VITE_USE_MOCK_API=false
```

Restart Vite after changing environment variables. Requests send and accept JSON and use `credentials: include` for cookie-based sessions. Authentication headers can be added once in `src/services/apiClient.ts` if the backend uses bearer tokens.

## Read endpoints

| Method | Endpoint | UI consumer | Response |
| --- | --- | --- | --- |
| GET | `/dashboard` | Executive Dashboard | `DashboardResponse` |
| GET | `/orders` | Order Live Tracking | `CollectionResponse<Order>` |
| GET | `/inventory` | Inventory Management | `InventoryResponse` |
| GET | `/products` | Common Products | `CollectionResponse<Product>` |
| GET | `/products/{sku}/documentation` | SKU Documentation | `SkuDocumentationResponse` |
| GET | `/users` | User Management | `CollectionResponse<OmsUser>` |
| GET | `/notifications` | Header notification drawer | `NotificationResponse` |

`GET /orders` accepts `page`, `pageSize`, repeated `orderNumber`, `sku`, repeated `status`, `orderDateFrom`, `orderDateTo`, `fulfillmentType`, `banner`, and `search` query parameters.

Collection responses use this envelope:

```json
{
  "items": [],
  "total": 0,
  "page": 1,
  "pageSize": 20
}
```

## Command endpoints

| Method | Endpoint | Request body |
| --- | --- | --- |
| POST | `/releases/{releaseId}/rerelease` | none |
| POST | `/releases/{releaseId}/reroute` | `{ "createDeliveryNote": true }` |
| POST | `/releases/{releaseId}/hard-cancel` | none |
| POST | `/fulfillments/{fulfillmentId}/sync` | none |

All TypeScript response contracts are exported from `src/services/omsApi.ts`. Failed non-2xx responses may return `{ "message": "..." }`; the shared client turns these into `ApiError` instances and the screens expose retry states.
