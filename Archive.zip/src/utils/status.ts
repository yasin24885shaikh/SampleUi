import type { ChipProps } from '@mui/material';

export type OrderStatus =
  | 'Created'
  | 'Scheduled'
  | 'Open'
  | 'Released'
  | 'Picked'
  | 'Packed'
  | 'Backordered'
  | 'Shipped'
  | 'Delivered'
  | 'Cancelled'
  | 'Pending Return'
  | 'Return'
  | 'Return Initiated'
  | 'Returned';

export const orderStatuses: OrderStatus[] = [
  'Created',
  'Scheduled',
  'Open',
  'Released',
  'Picked',
  'Packed',
  'Backordered',
  'Shipped',
  'Delivered',
  'Cancelled',
  'Pending Return',
  'Return',
  'Return Initiated',
  'Returned'
];

export const statusColor: Record<OrderStatus | string, ChipProps['color']> = {
  Created: 'info',
  Scheduled: 'secondary',
  Open: 'info',
  Released: 'warning',
  Picked: 'secondary',
  Packed: 'secondary',
  Backordered: 'error',
  Shipped: 'success',
  Delivered: 'success',
  Cancelled: 'error',
  'Pending Return': 'warning',
  Return: 'warning',
  'Return Initiated': 'warning',
  Returned: 'default'
};
