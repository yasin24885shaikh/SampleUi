import { Box, Chip, Stack, Typography } from '@mui/material';

type PageHeaderProps = {
  title: string;
  subtitle: string;
  badge?: string;
};

export default function PageHeader({ title, subtitle, badge }: PageHeaderProps) {
  return (
    <Box sx={{ mb: 3 }}>
      <Stack direction={{ xs: 'column', sm: 'row' }} justifyContent="space-between" gap={1.5}>
        <Box>
          <Typography variant="h4" sx={{ fontSize: { xs: 27, md: 32 }, lineHeight: 1.15 }}>
            {title}
          </Typography>
          <Typography variant="body1" color="text.secondary" sx={{ mt: 0.75, maxWidth: 780 }}>
            {subtitle}
          </Typography>
        </Box>
        {badge && <Chip label={badge} color="primary" variant="outlined" sx={{ alignSelf: 'flex-start' }} />}
      </Stack>
    </Box>
  );
}
