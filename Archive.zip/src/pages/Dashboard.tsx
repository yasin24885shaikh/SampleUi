import type { ReactNode } from 'react';
import { Box, Chip, List, ListItem, ListItemText, Stack, Typography } from '@mui/material';
import Grid from '@mui/material/GridLegacy';
import WarningAmberIcon from '@mui/icons-material/WarningAmber';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import InsightsOutlinedIcon from '@mui/icons-material/InsightsOutlined';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ComposedChart,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis
} from 'recharts';
import PageHeader from '../components/PageHeader';
import KpiCard from '../components/KpiCard';
import GlassCard from '../components/GlassCard';
import { ApiErrorState, ApiLoading } from '../components/ApiFeedback';
import { useApiResource } from '../hooks/useApiResource';
import { omsApi } from '../services/omsApi';

const chartColors = ['#1769e0', '#e77718', '#168a51', '#117c8b', '#c62828'];
const gridColor = 'rgba(100,116,139,.18)';

export default function Dashboard() {
  const { data, loading, error, reload } = useApiResource(omsApi.getDashboard);

  if (!data) {
    return (
      <Box>
        <PageHeader title="Executive Dashboard" subtitle="Real-time order orchestration, fulfillment health, revenue performance, and customer promise outcomes across Foot Locker banners." badge="Live OMS Telemetry" />
        {error ? <ApiErrorState message={error.message} onRetry={reload} /> : <ApiLoading rows={6} />}
      </Box>
    );
  }

  const {
    kpis: dashboardKpis, ordersByStatus, fulfillmentMix, inventoryTrend, dailyOrderVolume,
    serviceLevelTrend, exceptionTrend, bannerPerformance, nodePerformance, returnTrend,
    activities, alerts
  } = data;

  return (
    <Box>
      <PageHeader
        title="Executive Dashboard"
        subtitle="Real-time order orchestration, fulfillment health, revenue performance, and customer promise outcomes across Foot Locker banners."
        badge="Live OMS Telemetry"
      />

      <Stack direction={{ xs: 'column', md: 'row' }} justifyContent="space-between" alignItems={{ xs: 'flex-start', md: 'center' }} gap={1.5} sx={{ mb: 2.25 }}>
        <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap>
          <Chip icon={<CheckCircleOutlineIcon />} label="Service levels above plan" color="success" variant="outlined" />
          <Chip icon={<InsightsOutlinedIcon />} label="Exceptions down 18%" color="info" variant="outlined" />
          <Chip icon={<WarningAmberIcon />} label="Supplier direct requires attention" color="warning" variant="outlined" />
        </Stack>
        <Typography variant="caption" color="text.secondary" fontWeight={700}>{loading ? 'Refreshing OMS telemetry...' : `Last refreshed ${new Date(data.refreshedAt).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })} · Rolling 7 days`}</Typography>
      </Stack>

      <SectionHeading title="Enterprise Pulse" subtitle="Demand, throughput, inventory, and customer promise performance" />
      <Grid container spacing={2}>
        {dashboardKpis.map((kpi) => (
          <Grid item xs={12} sm={6} md={4} lg={2} key={kpi.label}>
            <KpiCard {...kpi} />
          </Grid>
        ))}

        <Grid item xs={12} lg={8}>
          <ChartCard title="Demand, Sales & Order Volume" subtitle="Daily gross demand and net sales in USD millions" badge="+10.2% net sales">
            <ResponsiveContainer width="100%" height={300}>
              <ComposedChart data={dailyOrderVolume}>
                <CartesianGrid stroke={gridColor} strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="day" />
                <YAxis yAxisId="revenue" label={{ value: '$M', angle: -90, position: 'insideLeft' }} />
                <YAxis yAxisId="orders" orientation="right" />
                <Tooltip />
                <Legend />
                <Area yAxisId="revenue" type="monotone" dataKey="grossDemand" name="Gross Demand ($M)" stroke="#7c3aed" fill="#7c3aed" fillOpacity={0.12} strokeWidth={2.5} />
                <Area yAxisId="revenue" type="monotone" dataKey="netSales" name="Net Sales ($M)" stroke="#0f766e" fill="#0f766e" fillOpacity={0.1} strokeWidth={3} />
                <Bar yAxisId="orders" dataKey="orders" name="Orders" fill="#1769e0" opacity={0.34} radius={[4, 4, 0, 0]} />
              </ComposedChart>
            </ResponsiveContainer>
          </ChartCard>
        </Grid>

        <Grid item xs={12} lg={4}>
          <ChartCard title="Order Portfolio" subtitle="Current order mix by lifecycle status">
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie data={ordersByStatus} dataKey="value" nameKey="name" innerRadius={62} outerRadius={98} paddingAngle={4}>
                  {ordersByStatus.map((entry, index) => <Cell key={entry.name} fill={chartColors[index % chartColors.length]} />)}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </ChartCard>
        </Grid>
      </Grid>

      <SectionHeading title="Service & Fulfillment" subtitle="Promise attainment, channel capacity, and node-level execution" />
      <Grid container spacing={2}>
        <Grid item xs={12} lg={8}>
          <ChartCard title="Customer Promise Performance" subtitle="Fill rate, on-time ship, and perfect order trend" badge="All metrics improving">
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={serviceLevelTrend}>
                <CartesianGrid stroke={gridColor} strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="day" />
                <YAxis domain={[85, 100]} unit="%" />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="fillRate" name="Fill Rate" stroke="#168a51" strokeWidth={3} dot={{ r: 3 }} />
                <Line type="monotone" dataKey="onTimeShip" name="On-Time Ship" stroke="#1769e0" strokeWidth={3} dot={{ r: 3 }} />
                <Line type="monotone" dataKey="perfectOrder" name="Perfect Order" stroke="#e77718" strokeWidth={3} dot={{ r: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          </ChartCard>
        </Grid>

        <Grid item xs={12} lg={4}>
          <ChartCard title="Fulfillment Mix" subtitle="Volume routed through each execution channel">
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={fulfillmentMix}>
                <CartesianGrid stroke={gridColor} strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="orders" name="Orders" radius={[6, 6, 0, 0]} fill="#d71920" />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>
        </Grid>

        <Grid item xs={12} lg={7}>
          <ChartCard title="Fulfillment Node Scorecard" subtitle="Service attainment and open backlog by node" badge="Supplier direct below target">
            <ResponsiveContainer width="100%" height={320}>
              <ComposedChart data={nodePerformance}>
                <CartesianGrid stroke={gridColor} strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                <YAxis yAxisId="service" domain={[85, 100]} unit="%" />
                <YAxis yAxisId="backlog" orientation="right" />
                <Tooltip />
                <Legend />
                <Bar yAxisId="backlog" dataKey="backlog" name="Open Backlog" fill="#cbd5e1" radius={[5, 5, 0, 0]} />
                <Line yAxisId="service" type="monotone" dataKey="onTime" name="On-Time Ship" stroke="#1769e0" strokeWidth={3} />
                <Line yAxisId="service" type="monotone" dataKey="fillRate" name="Fill Rate" stroke="#168a51" strokeWidth={3} />
              </ComposedChart>
            </ResponsiveContainer>
          </ChartCard>
        </Grid>

        <Grid item xs={12} lg={5}>
          <ChartCard title="Inventory Position" subtitle="Available inventory and reserved demand index">
            <ResponsiveContainer width="100%" height={320}>
              <AreaChart data={inventoryTrend}>
                <defs>
                  <linearGradient id="availableDashboard" x1="0" x2="0" y1="0" y2="1">
                    <stop offset="5%" stopColor="#117c8b" stopOpacity={0.42} />
                    <stop offset="95%" stopColor="#117c8b" stopOpacity={0.03} />
                  </linearGradient>
                </defs>
                <CartesianGrid stroke={gridColor} strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="day" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Area type="monotone" dataKey="available" name="Available %" stroke="#117c8b" fill="url(#availableDashboard)" strokeWidth={3} />
                <Line type="monotone" dataKey="reserved" name="Reserved Index" stroke="#e77718" strokeWidth={3} />
              </AreaChart>
            </ResponsiveContainer>
          </ChartCard>
        </Grid>
      </Grid>

      <SectionHeading title="Risk & Customer Outcomes" subtitle="Exception exposure, banner performance, returns, and active intervention" />
      <Grid container spacing={2}>
        <Grid item xs={12} lg={6}>
          <ChartCard title="Order Exceptions" subtitle="Daily exception volume by root cause" badge="Down 18% week over week">
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={exceptionTrend}>
                <CartesianGrid stroke={gridColor} strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="day" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="inventory" name="Inventory" stackId="exceptions" fill="#c62828" />
                <Bar dataKey="payment" name="Payment" stackId="exceptions" fill="#e77718" />
                <Bar dataKey="carrier" name="Carrier" stackId="exceptions" fill="#64748b" radius={[5, 5, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>
        </Grid>

        <Grid item xs={12} lg={6}>
          <ChartCard title="Banner Performance" subtitle="Order volume with banner-level fill rate">
            <ResponsiveContainer width="100%" height={300}>
              <ComposedChart data={bannerPerformance}>
                <CartesianGrid stroke={gridColor} strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                <YAxis yAxisId="orders" />
                <YAxis yAxisId="rate" orientation="right" domain={[90, 100]} unit="%" />
                <Tooltip />
                <Legend />
                <Bar yAxisId="orders" dataKey="orders" name="Orders" fill="#1769e0" radius={[5, 5, 0, 0]} />
                <Line yAxisId="rate" type="monotone" dataKey="fillRate" name="Fill Rate" stroke="#168a51" strokeWidth={3} />
              </ComposedChart>
            </ResponsiveContainer>
          </ChartCard>
        </Grid>

        <Grid item xs={12} lg={6}>
          <ChartCard title="Returns & Refund Cycle" subtitle="Return rate and average refund completion time">
            <ResponsiveContainer width="100%" height={285}>
              <LineChart data={returnTrend}>
                <CartesianGrid stroke={gridColor} strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="week" />
                <YAxis yAxisId="rate" domain={[6, 10]} unit="%" />
                <YAxis yAxisId="days" orientation="right" domain={[2, 5]} unit="d" />
                <Tooltip />
                <Legend />
                <Line yAxisId="rate" type="monotone" dataKey="returnRate" name="Return Rate" stroke="#9a6700" strokeWidth={3} dot={{ r: 4 }} />
                <Line yAxisId="days" type="monotone" dataKey="refundCycle" name="Refund Cycle" stroke="#7c3aed" strokeWidth={3} dot={{ r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          </ChartCard>
        </Grid>

        <Grid item xs={12} lg={6}>
          <GlassCard sx={{ p: 2.5, height: '100%' }}>
            <Stack direction="row" justifyContent="space-between" alignItems="center">
              <Box>
                <Typography variant="h6">Operational Alerts</Typography>
                <Typography variant="body2" color="text.secondary">Items requiring executive awareness</Typography>
              </Box>
              <Chip size="small" label={`${alerts.length} active`} color="warning" variant="outlined" />
            </Stack>
            <Stack spacing={1.5} sx={{ mt: 2.25 }}>
              {alerts.map((alert) => (
                <Stack key={alert.text} direction="row" spacing={1.25} alignItems="center" sx={{ p: 1.25, border: 1, borderColor: 'divider', borderRadius: 1.5 }}>
                  <WarningAmberIcon color={alert.severity === 'High' ? 'error' : alert.severity === 'Medium' ? 'warning' : 'info'} />
                  <Typography sx={{ flex: 1 }}>{alert.text}</Typography>
                  <Chip size="small" label={alert.severity} color={alert.severity === 'High' ? 'error' : alert.severity === 'Medium' ? 'warning' : 'info'} variant="outlined" />
                </Stack>
              ))}
            </Stack>
          </GlassCard>
        </Grid>

        <Grid item xs={12}>
          <GlassCard sx={{ p: 2.5 }}>
            <Stack direction="row" justifyContent="space-between" alignItems="center">
              <Box>
                <Typography variant="h6">Recent Enterprise Activity</Typography>
                <Typography variant="body2" color="text.secondary">Latest events with cross-network impact</Typography>
              </Box>
              <Chip size="small" label="Live feed" color="success" variant="outlined" />
            </Stack>
            <List sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: 'repeat(2, minmax(0, 1fr))' }, columnGap: 3, py: 1 }}>
              {activities.map((activity) => (
                <ListItem key={activity} sx={{ px: 0, borderBottom: 1, borderColor: 'divider' }}>
                  <ListItemText primary={activity} secondary="Updated moments ago" />
                </ListItem>
              ))}
            </List>
          </GlassCard>
        </Grid>
      </Grid>
    </Box>
  );
}

function SectionHeading({ title, subtitle }: { title: string; subtitle: string }) {
  return (
    <Box sx={{ mt: 3.5, mb: 1.5 }}>
      <Typography variant="h6" fontWeight={900}>{title}</Typography>
      <Typography variant="body2" color="text.secondary">{subtitle}</Typography>
    </Box>
  );
}

function ChartCard({ title, subtitle, badge, children }: { title: string; subtitle?: string; badge?: string; children: ReactNode }) {
  return (
    <GlassCard sx={{ p: 2.5, height: '100%' }}>
      <Stack direction="row" justifyContent="space-between" alignItems="flex-start" spacing={1.5} sx={{ mb: 2 }}>
        <Box>
          <Typography variant="h6">{title}</Typography>
          {subtitle && <Typography variant="body2" color="text.secondary">{subtitle}</Typography>}
        </Box>
        {badge && <Chip size="small" label={badge} color="info" variant="outlined" />}
      </Stack>
      {children}
    </GlassCard>
  );
}
