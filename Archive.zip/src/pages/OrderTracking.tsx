import { useMemo, useState, type MouseEvent as ReactMouseEvent, type ReactNode } from 'react';
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Alert,
  Box,
  Button,
  ButtonBase,
  Checkbox,
  Chip,
  Divider,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControl,
  IconButton,
  InputAdornment,
  InputLabel,
  ListItemText,
  ListItemIcon,
  Menu,
  MenuItem,
  OutlinedInput,
  Pagination,
  Select,
  Snackbar,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  TableSortLabel,
  TextField,
  Typography
} from '@mui/material';
import Grid from '@mui/material/GridLegacy';
import { alpha } from '@mui/material/styles';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import SearchIcon from '@mui/icons-material/Search';
import RestartAltIcon from '@mui/icons-material/RestartAlt';
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import WarehouseIcon from '@mui/icons-material/Warehouse';
import StorefrontIcon from '@mui/icons-material/Storefront';
import LocalShippingIcon from '@mui/icons-material/LocalShipping';
import CreditCardIcon from '@mui/icons-material/CreditCard';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import ConfirmationNumberIcon from '@mui/icons-material/ConfirmationNumber';
import PersonOutlineIcon from '@mui/icons-material/PersonOutline';
import EmailOutlinedIcon from '@mui/icons-material/EmailOutlined';
import ReceiptLongOutlinedIcon from '@mui/icons-material/ReceiptLongOutlined';
import TuneIcon from '@mui/icons-material/Tune';
import PauseCircleFilledIcon from '@mui/icons-material/PauseCircleFilled';
import AssignmentReturnIcon from '@mui/icons-material/AssignmentReturn';
import ChatBubbleOutlineIcon from '@mui/icons-material/ChatBubbleOutline';
import CloseIcon from '@mui/icons-material/Close';
import SupportAgentIcon from '@mui/icons-material/SupportAgent';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import AltRouteIcon from '@mui/icons-material/AltRoute';
import BlockIcon from '@mui/icons-material/Block';
import SyncIcon from '@mui/icons-material/Sync';
import WarningAmberRoundedIcon from '@mui/icons-material/WarningAmberRounded';
import OpenInNewIcon from '@mui/icons-material/OpenInNew';
import { motion } from 'framer-motion';
import GlassCard from '../components/GlassCard';
import PageHeader from '../components/PageHeader';
import StatusChip from '../components/StatusChip';
import { ApiErrorState, ApiLoading } from '../components/ApiFeedback';
import { useApiResource } from '../hooks/useApiResource';
import { type Fulfillment, type Order, type OrderLine, type Release } from '../services/mockData';
import { omsApi } from '../services/omsApi';
import { orderStatuses, type OrderStatus } from '../utils/status';

const fulfillmentTypes: Fulfillment['type'][] = ['Warehouse', 'Store', 'Dropship'];
const banners = ['footlocker.com', 'Champs Sports', 'Kids Foot Locker', 'Foot Locker CA'];
const pageSize = 20;
const popupPageSize = 10;
const loadOrders = (signal: AbortSignal) => omsApi.getOrders(signal, { page: 1, pageSize: 1000 });

type SubmittedSearchCriteria = {
  orderNumbers: string[];
  sku: string;
  statuses: OrderStatus[];
  fromDate: string;
  toDate: string;
  fulfillmentType: string;
  banner: string;
};

function getOrderAccent(status: OrderStatus) {
  const accents: Partial<Record<OrderStatus, string>> = {
    Released: '#e77718',
    Shipped: '#168a51',
    Delivered: '#168a51',
    Backordered: '#c62828',
    Cancelled: '#64748b',
    'Pending Return': '#9a6700',
    Return: '#9a6700',
    Returned: '#596475'
  };
  return accents[status] ?? '#1769e0';
}

function getFulfillmentAccent(type: Fulfillment['type']) {
  return type === 'Warehouse' ? '#1769e0' : type === 'Store' ? '#16a064' : '#8b5cf6';
}

function csvCell(value: string | number) {
  return `"${String(value).replace(/"/g, '""')}"`;
}

function formatCurrency(value: number) {
  return value.toLocaleString('en-US', { style: 'currency', currency: 'USD' });
}

function buildExportCsv(exportOrders: Order[]) {
  const header = ['Order ID', 'Banner', 'Customer', 'Email', 'Order Status', 'On Hold', 'Hold Reason', 'Return Order ID', 'Payment Status', 'Order Total', 'Order Line ID', 'Item ID', 'Item Description', 'Line Status', 'Line Total', 'Line Cancelled Total', 'Release ID', 'Release Line ID', 'Release Status', 'Release Quantity', 'Fulfilled Qty', 'Cancelled Qty', 'Assigned Node', 'Release Updated Date', 'Delivery Method', 'Fulfillment ID', 'Fulfillment Type', 'Fulfillment Node ID', 'Fulfillment Node Name', 'Fulfillment Status', 'Package ID', 'Package Detail ID', 'Shipment ID', 'Fulfillment Quantity', 'Ship Via', 'Tracking Number'];
  const rows = exportOrders.flatMap((order) => order.lines.flatMap((line) => {
    const releases = order.releases.filter((release) => release.orderLineId === line.lineNumber);
    return (releases.length ? releases : [undefined]).flatMap((release) => {
      const fulfillments = release
        ? order.fulfillments.filter((fulfillment) => fulfillment.releaseLineId === release.releaseLineId)
        : [];
      return (fulfillments.length ? fulfillments : [undefined]).map((fulfillment) => [
        order.orderNumber, order.organization, order.customerName, order.customerEmail, order.status,
        order.onHold ? 'Yes' : 'No', order.holdReason ?? '', order.returnOrderId ?? '', order.paymentStatus, order.totalAmount.toFixed(2),
        line.lineNumber, line.sku, line.productName, line.currentStatus, line.lineTotal.toFixed(2), line.cancelledTotal.toFixed(2),
        release?.releaseNumber ?? '', release?.releaseLineId ?? '',
        release?.releaseStatus ?? '', release?.quantity ?? '', release?.fulfilledQty ?? '',
        release?.cancelledQty ?? '', release?.assignedNode ?? '', release?.updatedDate ?? '',
        release?.fulfillmentMethod ?? '', fulfillment?.fulfillmentId ?? '', fulfillment?.type ?? '',
        fulfillment?.nodeId ?? '', fulfillment?.nodeName ?? '', fulfillment?.status ?? '',
        fulfillment?.packageId ?? '', fulfillment?.packageDetailId ?? '', fulfillment?.shipmentId ?? '',
        fulfillment?.quantity ?? '', fulfillment?.shipVia ?? '', fulfillment?.trackingNumber ?? ''
      ]);
    });
  }));
  return [header, ...rows].map((row) => row.map(csvCell).join(',')).join('\n');
}

export default function OrderTracking() {
  const { data: orderResponse, loading, error, reload } = useApiResource(loadOrders);
  const orders = orderResponse?.items ?? [];
  const [orderNumbers, setOrderNumbers] = useState('');
  const [sku, setSku] = useState('');
  const [statuses, setStatuses] = useState<OrderStatus[]>([]);
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');
  const [fulfillmentType, setFulfillmentType] = useState('');
  const [banner, setBanner] = useState('');
  const [searched, setSearched] = useState(false);
  const [submittedCriteria, setSubmittedCriteria] = useState<SubmittedSearchCriteria | null>(null);
  const [resultSearch, setResultSearch] = useState('');
  const [page, setPage] = useState(1);
  const [exportNotice, setExportNotice] = useState(false);

  const orderNumberList = useMemo(
    () => orderNumbers.split(/\n|,|\s/).map((value) => value.trim()).filter(Boolean),
    [orderNumbers]
  );
  const hasTooManyOrders = orderNumberList.length > 400;

  const filteredOrders = useMemo(() => {
    if (!searched || !submittedCriteria) return [];
    const query = resultSearch.trim().toLowerCase();

    return orders
      .filter((order) => !submittedCriteria.orderNumbers.length || submittedCriteria.orderNumbers.includes(order.orderNumber))
      .filter((order) => !submittedCriteria.sku || order.lines.some((line) => line.sku.toLowerCase().includes(submittedCriteria.sku.toLowerCase())))
      .filter((order) => !submittedCriteria.statuses.length || submittedCriteria.statuses.includes(order.status))
      .filter((order) => !submittedCriteria.fromDate || order.orderDate >= submittedCriteria.fromDate)
      .filter((order) => !submittedCriteria.toDate || order.orderDate <= submittedCriteria.toDate)
      .filter((order) => !submittedCriteria.fulfillmentType || order.fulfillments.some((fulfillment) => fulfillment.type === submittedCriteria.fulfillmentType))
      .filter((order) => !submittedCriteria.banner || order.organization === submittedCriteria.banner)
      .filter((order) => {
        if (!query) return true;
        const haystack = [
          order.orderNumber,
          order.customerName,
          order.customerEmail,
          order.status,
          order.organization,
          order.onHold ? 'on hold' : '',
          order.holdReason ?? '',
          order.returnOrderId ?? '',
          order.fulfillmentTypeSummary,
          ...order.lines.map((line) => `${line.lineNumber} ${line.sku} ${line.productName} ${line.currentStatus}`),
          ...order.releases.map((release) => `${release.releaseNumber} ${release.releaseLineId} ${release.assignedNode}`),
          ...order.fulfillments.map((fulfillment) => `${fulfillment.fulfillmentId} ${fulfillment.type} ${fulfillment.nodeId} ${fulfillment.nodeName} ${fulfillment.packageId} ${fulfillment.shipmentId} ${fulfillment.trackingNumber}`),
          ...order.communications.map((communication) => `${communication.channel} ${communication.agent} ${communication.direction} ${communication.summary} ${communication.caseId}`)
        ].join(' ').toLowerCase();
        return haystack.includes(query);
      });
  }, [orders, resultSearch, searched, submittedCriteria]);

  const pageCount = Math.max(1, Math.ceil(filteredOrders.length / pageSize));
  const activePage = Math.min(page, pageCount);
  const pagedOrders = filteredOrders.slice((activePage - 1) * pageSize, activePage * pageSize);
  const exportHref = useMemo(
    () => filteredOrders.length ? `data:text/csv;charset=utf-8,${encodeURIComponent(buildExportCsv(filteredOrders))}` : undefined,
    [filteredOrders]
  );

  const handleReset = () => {
    setOrderNumbers('');
    setSku('');
    setStatuses([]);
    setFromDate('');
    setToDate('');
    setFulfillmentType('');
    setBanner('');
    setSearched(false);
    setSubmittedCriteria(null);
    setResultSearch('');
    setPage(1);
  };

  const handleSearch = () => {
    setSubmittedCriteria({
      orderNumbers: orderNumberList,
      sku,
      statuses,
      fromDate,
      toDate,
      fulfillmentType,
      banner
    });
    setSearched(true);
    setResultSearch('');
    setPage(1);
  };

  return (
    <Box>
      <PageHeader
        title="Order Live Tracking"
        subtitle="Search, trace, and inspect order journeys across every Foot Locker fulfillment channel."
        badge="Live Operations"
      />

      {error && <ApiErrorState message={error.message} onRetry={reload} />}
      {loading && <Box sx={{ mb: 2.5 }}><ApiLoading rows={3} /></Box>}

      <GlassCard sx={{ p: 0, mb: 2.5, overflow: 'hidden', bgcolor: 'transparent' }}>
        <Box sx={{ px: { xs: 2, md: 3 }, py: 2.25, background: 'linear-gradient(115deg, #151b23 0%, #414a55 34%, #252c35 68%, #4d262a 100%)', color: 'common.white', boxShadow: 'inset 0 1px 0 rgba(255,255,255,.18), inset 0 -1px 0 rgba(0,0,0,.32)' }}>
          <Stack direction={{ xs: 'column', sm: 'row' }} justifyContent="space-between" gap={1.5}>
            <Box>
              <Stack direction="row" spacing={1} alignItems="center">
                <TuneIcon fontSize="small" />
                <Typography variant="h6">Search Criteria</Typography>
              </Stack>
              <Typography variant="body2" sx={{ color: 'rgba(255,255,255,.68)', mt: 0.4 }}>
                Start with order IDs, then narrow the search using operational attributes.
              </Typography>
            </Box>
            <Chip label={`${orderNumberList.length} / 400 orders`} color={hasTooManyOrders ? 'error' : 'default'} sx={{ color: 'common.white', borderColor: 'rgba(255,255,255,.25)', bgcolor: 'rgba(255,255,255,.08)' }} variant="outlined" />
          </Stack>
        </Box>

        <Box sx={{ p: { xs: 2, md: 3 }, background: (theme) => theme.palette.mode === 'light' ? 'linear-gradient(145deg, rgba(252,253,254,.92), rgba(224,228,233,.82))' : 'linear-gradient(145deg, rgba(34,40,49,.9), rgba(21,26,34,.9))' }}>
          <TextField
            label="Order Numbers"
            size="small"
            multiline
            minRows={3}
            maxRows={3}
            fullWidth
            value={orderNumbers}
            onChange={(event) => setOrderNumbers(event.target.value)}
            error={hasTooManyOrders}
            helperText={hasTooManyOrders ? 'Maximum 400 order numbers allowed.' : 'Paste one or multiple order IDs, separated by a line break, comma, or space.'}
            placeholder={'FL-10048291\nFL-10048307\nFL-10048355'}
            InputProps={{ sx: { alignItems: 'flex-start', bgcolor: (theme) => alpha(theme.palette.background.default, 0.58), '& textarea': { overflowY: 'auto !important', resize: 'none' } } }}
          />

          <Divider sx={{ my: 2.5 }}>
            <Chip icon={<TuneIcon />} label="Refine results" size="small" />
          </Divider>

          <Grid container spacing={2}>
            <Grid item xs={12} md={4}>
              <TextField size="small" label="Single SKU Search" fullWidth value={sku} onChange={(event) => setSku(event.target.value)} placeholder="HF2903-100" />
            </Grid>
            <Grid item xs={12} md={8}>
              <FormControl fullWidth size="small">
                <InputLabel>Order Status</InputLabel>
                <Select
                  multiple
                  value={statuses}
                  input={<OutlinedInput label="Order Status" />}
                  renderValue={(selected) => selected.join(', ')}
                  onChange={(event) => setStatuses(event.target.value as OrderStatus[])}
                >
                  {orderStatuses.map((status) => (
                    <MenuItem key={status} value={status}>
                      <Checkbox checked={statuses.includes(status)} />
                      <ListItemText primary={status} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <TextField size="small" label="Order Date From" type="date" fullWidth value={fromDate} onChange={(event) => setFromDate(event.target.value)} InputLabelProps={{ shrink: true }} />
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <TextField size="small" label="Order Date To" type="date" fullWidth value={toDate} onChange={(event) => setToDate(event.target.value)} InputLabelProps={{ shrink: true }} />
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <TextField size="small" select label="Fulfillment Type" fullWidth value={fulfillmentType} onChange={(event) => setFulfillmentType(event.target.value)}>
                <MenuItem value="">All</MenuItem>
                {fulfillmentTypes.map((type) => <MenuItem key={type} value={type}>{type}</MenuItem>)}
              </TextField>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <TextField size="small" select label="Banner" fullWidth value={banner} onChange={(event) => setBanner(event.target.value)}>
                <MenuItem value="">All Banners</MenuItem>
                {banners.map((value) => <MenuItem key={value} value={value}>{value}</MenuItem>)}
              </TextField>
            </Grid>
          </Grid>

          <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.25} justifyContent="flex-end" sx={{ mt: 2.5, pt: 2, borderTop: 1, borderColor: 'divider' }}>
            <Button startIcon={<RestartAltIcon />} variant="text" onClick={handleReset}>Reset</Button>
            <Button
              component="a"
              href={exportHref}
              download={`foot-locker-orders-${new Date().toISOString().slice(0, 10)}.csv`}
              startIcon={<FileDownloadIcon />}
              variant="outlined"
              disabled={!filteredOrders.length}
              onClick={() => setExportNotice(true)}
            >
              Export Results
            </Button>
            <Button startIcon={<SearchIcon />} disabled={hasTooManyOrders || loading || Boolean(error)} variant="contained" onClick={handleSearch}>Search Orders</Button>
          </Stack>
        </Box>
      </GlassCard>

      {searched && (
        <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }}>
          <GlassCard sx={{ p: { xs: 2, md: 2.5 }, bgcolor: (theme) => alpha(theme.palette.background.paper, 0.74) }}>
            <Stack direction={{ xs: 'column', md: 'row' }} justifyContent="space-between" gap={2} sx={{ mb: 2 }}>
              <Box>
                <Typography variant="h6">Search Results</Typography>
                <Typography color="text.secondary">{filteredOrders.length} matching orders</Typography>
              </Box>
              <TextField
                size="small"
                value={resultSearch}
                onChange={(event) => { setResultSearch(event.target.value); setPage(1); }}
                placeholder="Search order, customer, item, node, or release"
                sx={{ minWidth: { xs: '100%', md: 440 } }}
                InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon /></InputAdornment> }}
              />
            </Stack>

            {!filteredOrders.length && <Alert severity="info">No orders match the selected criteria.</Alert>}
            <Stack spacing={2}>
              {pagedOrders.map((order) => {
                const orderAccent = getOrderAccent(order.status);
                return (
                <Accordion
                  className="order-result-card"
                  key={order.orderNumber}
                  disableGutters
                  sx={{
                    overflow: 'hidden',
                    border: 1,
                    borderTop: '4px solid',
                    borderColor: (theme) => alpha(theme.palette.text.primary, 0.14),
                    borderTopColor: orderAccent,
                    borderRadius: '8px !important',
                    bgcolor: 'background.paper',
                    boxShadow: '0 7px 22px rgba(31,41,55,.07)',
                    transition: 'border-color 180ms ease, box-shadow 180ms ease, transform 180ms ease',
                    '&:before': { display: 'none' },
                    '&.Mui-expanded': {
                      m: 0,
                      borderColor: alpha(orderAccent, 0.48),
                      borderTopColor: orderAccent,
                      boxShadow: `0 18px 42px ${alpha(orderAccent, 0.15)}`
                    }
                  }}
                >
                  <AccordionSummary expandIcon={<ExpandMoreIcon />} sx={{ p: 0, borderBottom: '1px solid transparent', '&:hover': { bgcolor: alpha(orderAccent, 0.025) }, '&.Mui-expanded': { borderBottomColor: 'divider' }, '& .MuiAccordionSummary-content': { m: 0, minWidth: 0 }, '& .MuiAccordionSummary-expandIconWrapper': { color: orderAccent } }}>
                    <OrderHeader order={order} accent={orderAccent} />
                  </AccordionSummary>
                  <AccordionDetails sx={{ p: { xs: 1.5, md: 2.5 }, bgcolor: (theme) => alpha(theme.palette.background.default, 0.42) }}>
                    <OrderInformation order={order} />
                    <OrderLines order={order} />
                    <FulfillmentLines order={order} />
                  </AccordionDetails>
                </Accordion>
                );
              })}
            </Stack>

            {filteredOrders.length > 0 && (
              <Stack direction={{ xs: 'column', sm: 'row' }} justifyContent="space-between" alignItems="center" gap={2} sx={{ mt: 2.5, pt: 2, borderTop: 1, borderColor: 'divider' }}>
                <Typography variant="body2" color="text.secondary">
                  Showing {(activePage - 1) * pageSize + 1}-{Math.min(activePage * pageSize, filteredOrders.length)} of {filteredOrders.length} orders · 20 per page
                </Typography>
                <Pagination count={pageCount} page={activePage} onChange={(_, value) => setPage(value)} color="primary" shape="rounded" />
              </Stack>
            )}
          </GlassCard>
        </motion.div>
      )}

      <Snackbar open={exportNotice} autoHideDuration={3200} onClose={() => setExportNotice(false)} message={`Exported ${filteredOrders.length} orders to CSV`} />
    </Box>
  );
}

function OrderHeader({ order, accent }: { order: Order; accent: string }) {
  return (
    <Box sx={{ width: '100%', p: { xs: 1.1, md: 1.2 }, background: (theme) => theme.palette.mode === 'light' ? `linear-gradient(112deg, ${alpha(accent, 0.14)} 0%, rgba(232,235,239,.94) 34%, rgba(250,251,252,.96) 68%, ${alpha(theme.palette.secondary.main, 0.1)} 100%)` : `linear-gradient(112deg, ${alpha(accent, 0.18)} 0%, rgba(38,44,54,.95) 42%, rgba(24,29,37,.96) 100%)`, boxShadow: 'inset 0 1px 0 rgba(255,255,255,.42)' }}>
      <Stack direction={{ xs: 'column', lg: 'row' }} justifyContent="space-between" gap={1} alignItems={{ lg: 'center' }}>
        <Box sx={{ minWidth: 0 }}>
          <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap" useFlexGap>
            <ConfirmationNumberIcon fontSize="small" sx={{ color: accent }} />
            <Typography variant="h6">{order.orderNumber}</Typography>
            <StatusChip label={order.status} />
            <PaymentStatusChip status={order.paymentStatus} />
            {order.onHold && <Chip size="small" icon={<PauseCircleFilledIcon />} label="On Hold" color="warning" />}
          </Stack>
        </Box>
        <Grid container spacing={0.65} sx={{ maxWidth: { lg: 570 } }}>
          <HeaderMetric icon={<CalendarMonthIcon fontSize="small" />} label="Created" value={order.orderDate} accent={accent} />
          <HeaderMetric icon={<CreditCardIcon fontSize="small" />} label="Order Total" value={`$${order.totalAmount.toFixed(2)}`} accent={accent} />
        </Grid>
      </Stack>
    </Box>
  );
}

function HeaderMetric({ icon, label, value, accent }: { icon: ReactNode; label: string; value: string; accent: string }) {
  return (
    <Grid item xs={6}>
      <Stack direction="row" spacing={0.6} alignItems="center" sx={{ px: { xs: 0.55, sm: 0.75 }, py: 0.25, minHeight: 36, border: 1, borderColor: 'divider', borderRadius: 1.25, background: (theme) => theme.palette.mode === 'light' ? 'linear-gradient(180deg, rgba(255,255,255,.92), rgba(219,224,229,.88))' : 'linear-gradient(180deg, rgba(49,56,67,.86), rgba(28,33,42,.9))', boxShadow: 'inset 0 1px 0 rgba(255,255,255,.42), 0 1px 2px rgba(31,38,47,.08)' }}>
        <Box sx={{ color: accent, display: { xs: 'none', sm: 'flex' }, '& svg': { fontSize: 16 } }}>{icon}</Box>
        <Box sx={{ minWidth: 0 }}>
          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', fontSize: '0.64rem', lineHeight: 1 }}>
            <Box component="span" sx={{ display: { xs: 'none', sm: 'inline' } }}>{label}</Box>
            <Box component="span" sx={{ display: { xs: 'inline', sm: 'none' } }}>{label === 'Order Status' ? 'Status' : label === 'Order Total' ? 'Total' : label}</Box>
          </Typography>
          <Typography variant="body2" fontWeight={900} fontSize={{ xs: label === 'Created' ? '0.62rem' : '0.7rem', sm: '0.76rem' }} lineHeight={1.18} noWrap>{value}</Typography>
        </Box>
      </Stack>
    </Grid>
  );
}

function PaymentStatusChip({ status }: { status: string }) {
  const color = status === 'Captured' ? 'success' : status === 'Refunded' ? 'warning' : 'info';
  return <Chip size="small" icon={<CreditCardIcon />} label={status} color={color} variant="outlined" />;
}

function formatAddress(address: Order['shippingAddress']) {
  if (!address) return '';
  return [
    address.line1,
    address.line2,
    `${address.city}, ${address.state} ${address.postalCode}`,
    address.country
  ].filter(Boolean).join(', ');
}

function fallbackAddress(order: Order, type: 'shipping' | 'billing') {
  const numericSeed = Number(order.customerId.replace(/\D/g, '').slice(-4)) || 1420;
  const streetNumber = 100 + (numericSeed % 8900);
  const billingStreetNumber = streetNumber + 18;
  const cityByBanner: Record<string, [string, string, string]> = {
    'footlocker.com': ['New York', 'NY', '10001'],
    'Champs Sports': ['Bradenton', 'FL', '34205'],
    'Kids Foot Locker': ['Chicago', 'IL', '60605'],
    'Foot Locker CA': ['Toronto', 'ON', 'M5B 2H1']
  };
  const [city, state, postalCode] = cityByBanner[order.organization] ?? ['New York', 'NY', '10001'];
  const streetName = type === 'shipping' ? 'Fulfillment Ave' : 'Billing Center Dr';
  return `${type === 'shipping' ? streetNumber : billingStreetNumber} ${streetName}, ${city}, ${state} ${postalCode}, ${order.organization === 'Foot Locker CA' ? 'CA' : 'US'}`;
}

function OrderInformation({ order }: { order: Order }) {
  const [communicationOpen, setCommunicationOpen] = useState(false);
  const details: Array<{ label: string; value: string; icon: ReactNode; md?: number }> = [
    { label: 'Banner', value: order.organization, icon: <ConfirmationNumberIcon /> },
    { label: 'Order Type', value: order.orderType, icon: <ReceiptLongOutlinedIcon /> },
    { label: 'Fulfillment Type', value: order.fulfillmentType, icon: <WarehouseIcon /> },
    { label: 'Fulfillment Summary', value: order.fulfillmentTypeSummary, icon: <LocalShippingIcon />, md: 6 }
  ];
  if (order.onHold && order.holdReason) {
    details.push({ label: 'Hold Reason', value: order.holdReason, icon: <PauseCircleFilledIcon />, md: 6 });
  }
  if (order.paymentStatus === 'Refunded' && order.returnOrderId) {
    details.push({ label: 'Return Order ID', value: order.returnOrderId, icon: <AssignmentReturnIcon /> });
  }
  details.push(
    { label: 'Customer Name', value: order.customerName, icon: <PersonOutlineIcon /> },
    { label: 'Customer ID', value: order.customerId, icon: <PersonOutlineIcon /> },
    { label: 'Customer Email', value: order.customerEmail, icon: <EmailOutlinedIcon /> },
    { label: 'Shipping Address', value: formatAddress(order.shippingAddress) || fallbackAddress(order, 'shipping'), icon: <LocalShippingIcon />, md: 6 },
    { label: 'Billing Address', value: formatAddress(order.billingAddress) || fallbackAddress(order, 'billing'), icon: <CreditCardIcon />, md: 6 }
  );
  return (
    <Box
      className="order-information-panel"
      sx={{
        mb: 2.5,
        overflow: 'hidden',
        border: 1,
        borderLeft: '4px solid',
        borderColor: (theme) => alpha(theme.palette.secondary.main, 0.28),
        borderLeftColor: 'secondary.main',
        borderRadius: 2,
        color: 'text.primary',
        background: (theme) => `linear-gradient(115deg, ${alpha(theme.palette.info.main, 0.055)}, ${alpha(theme.palette.secondary.main, 0.075)} 56%, ${alpha(theme.palette.background.paper, 0.72)})`,
        boxShadow: '0 8px 24px rgba(31,41,55,.07)'
      }}
    >
      <Box sx={{ px: 2, py: 1.35, borderBottom: 1, borderColor: 'divider', bgcolor: (theme) => alpha(theme.palette.secondary.main, 0.065) }}>
        <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1} alignItems={{ xs: 'flex-start', sm: 'center' }} justifyContent="space-between">
          <Stack direction="row" spacing={1} alignItems="center">
            <ReceiptLongOutlinedIcon sx={{ color: 'secondary.main', fontSize: 20 }} />
            <Typography variant="subtitle1" fontWeight={900}>Additional Order Details</Typography>
          </Stack>
          <Button
            className="communication-notes-link"
            size="small"
            variant="text"
            startIcon={<ChatBubbleOutlineIcon />}
            onClick={() => setCommunicationOpen(true)}
            sx={{ px: 0.5, textDecoration: 'underline', textUnderlineOffset: 3 }}
          >
            Communication Notes ({order.communications.length})
          </Button>
        </Stack>
      </Box>
      <Grid container>
        {details.map(({ label, value, icon, md = 4 }) => (
          <Grid item xs={12} sm={6} md={md} key={label}>
            <Stack direction="row" spacing={1} alignItems="center" sx={{ px: 1.5, py: 0.85, minHeight: 54, borderRight: 1, borderBottom: 1, borderColor: 'divider' }}>
              <Box sx={{ width: 28, height: 28, borderRadius: 1.25, flex: '0 0 auto', display: 'grid', placeItems: 'center', color: 'primary.main', bgcolor: (theme) => alpha(theme.palette.primary.main, 0.085), '& svg': { fontSize: 16 } }}>{icon}</Box>
              <Box sx={{ minWidth: 0 }}>
                <Typography variant="caption" color="text.secondary" sx={{ display: 'block', lineHeight: 1.05 }}>{label}</Typography>
                <Typography variant="body2" fontWeight={800} sx={{ mt: 0.2, lineHeight: 1.2, overflowWrap: 'anywhere' }}>{value}</Typography>
              </Box>
            </Stack>
          </Grid>
        ))}
      </Grid>
      <Dialog open={communicationOpen} onClose={() => setCommunicationOpen(false)} maxWidth="lg" fullWidth aria-labelledby={`communication-title-${order.orderNumber}`}>
        <DialogTitle id={`communication-title-${order.orderNumber}`} sx={{ pr: 7 }}>
          <Stack direction="row" spacing={1.25} alignItems="center">
            <Box sx={{ width: 38, height: 38, borderRadius: 1.5, display: 'grid', placeItems: 'center', color: 'info.main', bgcolor: (theme) => alpha(theme.palette.info.main, 0.1) }}>
              <SupportAgentIcon />
            </Box>
            <Box>
              <Typography variant="h6">Customer Communication History</Typography>
              <Typography variant="body2" color="text.secondary">{order.orderNumber} · {order.customerName}</Typography>
            </Box>
          </Stack>
          <IconButton aria-label="Close communication notes" onClick={() => setCommunicationOpen(false)} sx={{ position: 'absolute', right: 14, top: 14 }}>
            <CloseIcon />
          </IconButton>
        </DialogTitle>
        <DialogContent dividers sx={{ p: 0 }}>
          <Box sx={{ overflowX: 'auto' }}>
            <Table size="small" sx={{ minWidth: 940 }}>
              <TableHead>
                <TableRow>
                  {['Date / Time', 'Channel', 'Direction', 'Helpdesk Agent', 'Case ID', 'Communication Summary'].map((label) => <TableCell key={label}>{label}</TableCell>)}
                </TableRow>
              </TableHead>
              <TableBody>
                {order.communications.map((communication) => (
                  <TableRow key={`${communication.caseId}-${communication.dateTime}`} hover>
                    <TableCell sx={{ whiteSpace: 'nowrap', fontWeight: 700 }}>{communication.dateTime}</TableCell>
                    <TableCell><Chip size="small" label={communication.channel} variant="outlined" /></TableCell>
                    <TableCell>
                      <Chip
                        size="small"
                        label={communication.direction}
                        color={communication.direction === 'Inbound' ? 'info' : communication.direction === 'Outbound' ? 'success' : 'default'}
                      />
                    </TableCell>
                    <TableCell sx={{ fontWeight: 700 }}>{communication.agent}</TableCell>
                    <TableCell sx={{ fontWeight: 800, color: 'info.main', whiteSpace: 'nowrap' }}>{communication.caseId}</TableCell>
                    <TableCell sx={{ minWidth: 340 }}>{communication.summary}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Box>
        </DialogContent>
      </Dialog>
    </Box>
  );
}

type ReleaseTableRow = { id: string; line: OrderLine; release?: Release };
type ReleaseSortKey = 'lineNumber' | 'sku' | 'productName' | 'lineStatus' | 'lineTotal' | 'releaseNumber' | 'releaseLineId' | 'releaseStatus' | 'quantity' | 'fulfilledQty' | 'cancelledQty' | 'assignedNode' | 'updatedDate' | 'fulfillmentMethod';
type SortDirection = 'asc' | 'desc';
type FulfillmentSortKey = 'releaseNumber' | 'releaseLineId' | 'nodeName' | 'nodeId' | 'type' | 'packageId' | 'packageDetailId' | 'shipmentId' | 'orderedQty' | 'shippedQty' | 'status' | 'shipVia' | 'trackingNumber';

function getReleaseSortValue(row: ReleaseTableRow, sortKey: ReleaseSortKey) {
  const values: Record<ReleaseSortKey, string | number> = {
    lineNumber: row.line.lineNumber,
    sku: row.line.sku,
    productName: row.line.productName,
    lineStatus: row.line.currentStatus,
    lineTotal: row.line.lineTotal,
    releaseNumber: row.release?.releaseNumber ?? '',
    releaseLineId: row.release?.releaseLineId ?? '',
    releaseStatus: row.release?.releaseStatus ?? '',
    quantity: row.release?.quantity ?? 0,
    fulfilledQty: row.release?.fulfilledQty ?? 0,
    cancelledQty: row.release?.cancelledQty ?? 0,
    assignedNode: row.release?.assignedNode ?? '',
    updatedDate: row.release?.updatedDate ?? '',
    fulfillmentMethod: row.release?.fulfillmentMethod ?? ''
  };
  return values[sortKey];
}

function getFulfillmentSortValue(row: Fulfillment, sortKey: FulfillmentSortKey) {
  const values: Record<FulfillmentSortKey, string | number> = {
    releaseNumber: row.releaseNumber,
    releaseLineId: row.releaseLineId,
    nodeName: row.nodeName,
    nodeId: row.nodeId,
    type: row.type,
    packageId: row.packageId,
    packageDetailId: row.packageDetailId,
    shipmentId: row.shipmentId,
    orderedQty: row.quantity,
    shippedQty: 0,
    status: row.status,
    shipVia: row.shipVia,
    trackingNumber: row.trackingNumber
  };
  return values[sortKey];
}

function getFulfillmentShippedQty(row: Fulfillment, releases: Release[]) {
  return releases.find((release) => release.releaseLineId === row.releaseLineId)?.fulfilledQty ?? (row.status === 'Shipped' || row.status === 'Delivered' || row.status === 'In Transit' ? row.quantity : 0);
}

function getFulfillmentTypeColor(type: Fulfillment['type']) {
  if (type === 'Warehouse') return '#0d6470';
  if (type === 'Supplier') return '#6d3fb8';
  if (type === 'Dropship') return '#b45309';
  return '#1769e0';
}

function getFulfillmentStatusStyle(status: string) {
  const normalizedStatus = status.toLowerCase();
  if (normalizedStatus.includes('cancel')) return { bg: '#fee2e2', fg: '#991b1b', border: '#ef4444' };
  if (normalizedStatus.includes('delivered')) return { bg: '#dcfce7', fg: '#166534', border: '#22c55e' };
  if (normalizedStatus.includes('transit') || normalizedStatus.includes('shipped')) return { bg: '#d1fae5', fg: '#047857', border: '#10b981' };
  if (normalizedStatus.includes('ready')) return { bg: '#ccfbf1', fg: '#0f766e', border: '#14b8a6' };
  if (normalizedStatus.includes('packed')) return { bg: '#ede9fe', fg: '#5b21b6', border: '#8b5cf6' };
  if (normalizedStatus.includes('picked') || normalizedStatus.includes('pick')) return { bg: '#e0f2fe', fg: '#075985', border: '#0ea5e9' };
  if (normalizedStatus.includes('manifest')) return { bg: '#dbeafe', fg: '#1d4ed8', border: '#3b82f6' };
  if (normalizedStatus.includes('label')) return { bg: '#fef3c7', fg: '#92400e', border: '#f59e0b' };
  if (normalizedStatus.includes('awaiting') || normalizedStatus.includes('backorder')) return { bg: '#ffedd5', fg: '#9a3412', border: '#f97316' };
  if (normalizedStatus.includes('return')) return { bg: '#f3e8ff', fg: '#7e22ce', border: '#a855f7' };
  if (normalizedStatus.includes('release') || normalizedStatus.includes('open') || normalizedStatus.includes('schedule')) return { bg: '#e0f2fe', fg: '#0369a1', border: '#38bdf8' };
  return { bg: '#f1f5f9', fg: '#334155', border: '#94a3b8' };
}

function OrderLines({ order }: { order: Order }) {
  const [allReleasesOpen, setAllReleasesOpen] = useState(false);
  const [releaseSearch, setReleaseSearch] = useState('');
  const [releasePage, setReleasePage] = useState(1);
  const [releaseSortKey, setReleaseSortKey] = useState<ReleaseSortKey>('lineNumber');
  const [releaseSortDirection, setReleaseSortDirection] = useState<SortDirection>('asc');
  const orderedUnits = order.lines.reduce((total, line) => total + line.orderedQty, 0);
  const fulfilledUnits = order.lines.reduce((total, line) => total + line.fulfilledQty, 0);
  const lineAmount = order.lines.reduce((total, line) => total + line.lineTotal, 0);
  const cancelledAmount = order.lines.reduce((total, line) => total + line.cancelledTotal, 0);
  const normalizedReleaseSearch = releaseSearch.trim().toLowerCase();
  const releaseRows = useMemo<ReleaseTableRow[]>(() => order.lines.flatMap((line) => {
    const lineReleases = order.releases.filter((release) => release.orderLineId === line.lineNumber);
    return lineReleases.length
      ? lineReleases.map((release) => ({ id: release.releaseLineId, line, release }))
      : [{ id: `line-${line.lineNumber}`, line }];
  }), [order.lines, order.releases]);
  const filteredReleaseRows = useMemo(() => {
    if (!normalizedReleaseSearch) return releaseRows;

    return releaseRows.filter(({ line, release }) => {
      const lineText = [
        line.lineNumber,
        line.sku,
        line.productName,
        line.currentStatus,
        line.orderedQty,
        line.fulfilledQty,
        line.cancelledQty,
        line.lineTotal,
        line.cancelledTotal,
        release?.releaseNumber ?? '',
        release?.releaseLineId ?? '',
        release?.orderLineId ?? '',
        release?.itemId ?? '',
        release?.releaseStatus ?? '',
        release?.fulfillmentMethod ?? '',
        release?.assignedNode ?? '',
        release?.updatedDate ?? '',
        release?.quantity ?? '',
        release?.fulfilledQty ?? '',
        release?.cancelledQty ?? ''
      ].join(' ').toLowerCase();
      return lineText.includes(normalizedReleaseSearch);
    });
  }, [normalizedReleaseSearch, releaseRows]);
  const sortedReleaseRows = useMemo(() => [...filteredReleaseRows].sort((left, right) => {
    const leftValue = getReleaseSortValue(left, releaseSortKey);
    const rightValue = getReleaseSortValue(right, releaseSortKey);
    const result = typeof leftValue === 'number' && typeof rightValue === 'number'
      ? leftValue - rightValue
      : String(leftValue).localeCompare(String(rightValue), undefined, { numeric: true, sensitivity: 'base' });
    return releaseSortDirection === 'asc' ? result : -result;
  }), [filteredReleaseRows, releaseSortDirection, releaseSortKey]);
  const filteredLineCount = new Set(filteredReleaseRows.map((row) => row.line.lineNumber)).size;
  const filteredReleaseCount = filteredReleaseRows.filter((row) => row.release).length;
  const releasePageCount = Math.max(1, Math.ceil(sortedReleaseRows.length / popupPageSize));
  const pagedReleaseRows = sortedReleaseRows.slice((releasePage - 1) * popupPageSize, releasePage * popupPageSize);

  const closeAllReleases = () => {
    setAllReleasesOpen(false);
    setReleaseSearch('');
    setReleasePage(1);
  };
  const handleReleaseSort = (sortKey: ReleaseSortKey) => {
    setReleasePage(1);
    setReleaseSortDirection((currentDirection) => releaseSortKey === sortKey && currentDirection === 'asc' ? 'desc' : 'asc');
    setReleaseSortKey(sortKey);
  };

  return (
    <Box sx={{ mb: 1.5 }}>
      <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 0.75 }}>
        <Box>
          <Typography variant="subtitle2" fontWeight={950}>Order Lines</Typography>
          <Typography variant="caption" color="text.secondary">Line-level merchandise and release allocation</Typography>
        </Box>
        <Chip size="small" label={`${order.releases.length} releases`} variant="outlined" />
      </Stack>
      <GlassCard sx={{ mb: 0.75, overflow: 'hidden', borderColor: (theme) => alpha(theme.palette.primary.main, 0.3), bgcolor: (theme) => alpha(theme.palette.primary.main, 0.045) }}>
        <ButtonBase aria-label="Open all order line releases" onClick={() => setAllReleasesOpen(true)} sx={{ width: '100%', p: { xs: 1, md: 1.1 }, textAlign: 'left' }}>
          <Box sx={{ width: '100%', display: 'grid', gridTemplateColumns: { xs: 'repeat(2, minmax(0, 1fr))', md: 'repeat(5, minmax(0, 1fr)) 28px' }, gap: { xs: 0.75, md: 1 }, alignItems: 'center' }}>
            <AggregateMetric label="Order Lines" value={String(order.lines.length)} />
            <AggregateMetric label="Ordered Units" value={String(orderedUnits)} />
            <AggregateMetric label="Fulfilled Units" value={String(fulfilledUnits)} />
            <AggregateMetric label="Line Amount" value={formatCurrency(lineAmount)} />
            <AggregateMetric label="Cancelled Amount" value={formatCurrency(cancelledAmount)} alert={cancelledAmount > 0} />
            <OpenInNewIcon color="primary" />
          </Box>
        </ButtonBase>
      </GlassCard>
      <Dialog
        open={allReleasesOpen}
        onClose={closeAllReleases}
        fullWidth
        maxWidth={false}
        aria-labelledby={`all-order-releases-${order.orderNumber}`}
        PaperProps={{
          sx: {
            m: { xs: 1, md: 1.5 },
            width: { xs: 'calc(100vw - 16px)', md: 'calc(100vw - 24px)' },
            maxWidth: '1760px',
            height: 'auto',
            maxHeight: { xs: 'calc(100vh - 24px)', md: 'calc(100vh - 36px)' },
            borderRadius: { xs: 2, md: 3 }
          }
        }}
      >
        <DialogTitle id={`all-order-releases-${order.orderNumber}`} sx={{ pr: 7 }}>
          <Typography variant="h6">Order Lines & Releases</Typography>
          <Typography variant="body2" color="text.secondary">{order.orderNumber} · {filteredLineCount} of {order.lines.length} lines · {filteredReleaseCount} of {order.releases.length} releases · {sortedReleaseRows.length} table rows</Typography>
          <IconButton aria-label="Close all order releases" onClick={closeAllReleases} sx={{ position: 'absolute', right: 14, top: 14 }}><CloseIcon /></IconButton>
        </DialogTitle>
        <DialogContent dividers sx={{ p: { xs: 1.5, md: 2 }, bgcolor: (theme) => alpha(theme.palette.background.default, 0.5), overflowY: 'auto' }}>
          <Box sx={{ position: 'sticky', top: 0, zIndex: 2, mb: 1.5, px: 1.5, py: 1.25, border: 1, borderColor: 'divider', borderRadius: 2, bgcolor: (theme) => alpha(theme.palette.background.paper, 0.95), backdropFilter: 'blur(14px)', boxShadow: '0 10px 24px rgba(15,23,42,.06)' }}>
            <Stack direction={{ xs: 'column', md: 'row' }} spacing={1.25} alignItems={{ xs: 'stretch', md: 'center' }}>
              <TextField
                fullWidth
                size="small"
                label="Search order lines and releases"
                value={releaseSearch}
                onChange={(event) => {
                  setReleaseSearch(event.target.value);
                  setReleasePage(1);
                }}
                placeholder="Search line ID, item, status, release, node, delivery method"
                InputProps={{
                  startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment>
                }}
              />
              <Chip label="Sortable table" color="primary" variant="outlined" sx={{ minWidth: 132, fontWeight: 900 }} />
            </Stack>
          </Box>
          <ReleaseLinesTable
            rows={pagedReleaseRows}
            sortKey={releaseSortKey}
            sortDirection={releaseSortDirection}
            onSort={handleReleaseSort}
          />
          {!filteredReleaseRows.length && <Alert severity="info" sx={{ mt: 1.25 }}>No order lines or releases match this popup search.</Alert>}
          {sortedReleaseRows.length > popupPageSize && (
            <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.25} alignItems={{ xs: 'flex-start', sm: 'center' }} justifyContent="space-between" sx={{ position: 'sticky', bottom: 0, mt: 1.5, px: 1.5, py: 1.25, border: 1, borderColor: 'divider', borderRadius: 2, bgcolor: (theme) => alpha(theme.palette.background.paper, 0.96), backdropFilter: 'blur(14px)', boxShadow: '0 -10px 24px rgba(15,23,42,.06)' }}>
              <Typography variant="body2" color="text.secondary">
                Showing {(releasePage - 1) * popupPageSize + 1}-{Math.min(releasePage * popupPageSize, sortedReleaseRows.length)} of {sortedReleaseRows.length} matching rows
              </Typography>
              <Pagination count={releasePageCount} page={releasePage} onChange={(_, value) => setReleasePage(value)} color="primary" size="small" />
            </Stack>
          )}
        </DialogContent>
      </Dialog>
    </Box>
  );
}

function AggregateMetric({ label, value, alert = false }: { label: string; value: string; alert?: boolean }) {
  return (
    <Box sx={{ minWidth: 0 }}>
      <Typography variant="caption" color="text.secondary">{label}</Typography>
      <Typography fontWeight={900} color={alert ? 'error.main' : 'text.primary'} noWrap>{value}</Typography>
    </Box>
  );
}

function OrderLineSummary({ line }: { line: OrderLine }) {
  return (
    <GlassCard sx={{ p: 1.4, borderLeft: '4px solid', borderLeftColor: 'primary.main', bgcolor: (theme) => alpha(theme.palette.primary.main, 0.03) }}>
      <Box sx={{ width: '100%', display: 'grid', gridTemplateColumns: { xs: '1fr', md: '80px minmax(105px, .75fr) minmax(200px, 1.75fr) minmax(115px, .8fr) 85px 105px' }, gap: { xs: 0.7, md: 1.5 }, alignItems: 'center' }}>
        <LineValue label="Line ID" value={line.lineNumber} strong />
        <LineValue label="Item ID" value={line.sku} strong />
        <LineValue label="Item Description" value={line.productName} />
        <Box><Typography variant="caption" color="text.secondary">Line Status</Typography><Box><StatusChip label={line.currentStatus} /></Box></Box>
        <LineValue label="Line Total" value={formatCurrency(line.lineTotal)} strong />
        <Box sx={{ minWidth: 0 }}>
          <Typography variant="caption" color="text.secondary">Cancelled Total</Typography>
          <Typography fontWeight={900} color={line.cancelledTotal > 0 ? 'error.main' : 'text.primary'} noWrap>{formatCurrency(line.cancelledTotal)}</Typography>
        </Box>
      </Box>
    </GlassCard>
  );
}

type ConfirmationTone = 'info' | 'warning' | 'error';
type ActionStatus = { message: string; severity: 'success' | 'error' | 'info' };

function ActionConfirmationDialog({
  open,
  title,
  eyebrow,
  description,
  confirmLabel,
  tone,
  icon,
  details,
  onClose,
  onConfirm
}: {
  open: boolean;
  title: string;
  eyebrow: string;
  description: string;
  confirmLabel: string;
  tone: ConfirmationTone;
  icon: ReactNode;
  details: Array<[string, string]>;
  onClose: () => void;
  onConfirm: () => void;
}) {
  return (
    <Dialog
      open={open}
      onClose={onClose}
      maxWidth="sm"
      fullWidth
      aria-labelledby="action-confirmation-title"
      sx={{ zIndex: (theme) => theme.zIndex.modal + 120 }}
      PaperProps={{
        sx: {
          overflow: 'hidden',
          borderRadius: 2,
          border: 1,
          borderColor: (theme) => alpha(theme.palette[tone].main, 0.34),
          bgcolor: 'background.paper',
          color: 'text.primary',
          boxShadow: (theme) => `0 28px 70px ${alpha(theme.palette.common.black, 0.28)}`
        }
      }}
    >
      <Box sx={{ px: 3, pt: 3, pb: 2.5, background: (theme) => theme.palette.mode === 'light' ? `linear-gradient(120deg, ${alpha(theme.palette[tone].main, 0.18)}, #ffffff 68%)` : `linear-gradient(120deg, ${alpha(theme.palette[tone].main, 0.24)}, #151b25 72%)` }}>
        <Stack direction="row" spacing={1.75} alignItems="flex-start">
          <Box sx={{ width: 48, height: 48, flex: '0 0 auto', borderRadius: 2, display: 'grid', placeItems: 'center', color: `${tone}.main`, bgcolor: (theme) => alpha(theme.palette[tone].main, 0.13), border: 1, borderColor: (theme) => alpha(theme.palette[tone].main, 0.25), '& svg': { fontSize: 26 } }}>
            {icon}
          </Box>
          <Box sx={{ minWidth: 0, pt: 0.2 }}>
            <Typography variant="overline" fontWeight={900} color={`${tone}.main`}>{eyebrow}</Typography>
            <DialogTitle id="action-confirmation-title" sx={{ p: 0, mt: 0.2, fontSize: '1.35rem', fontWeight: 900, color: 'text.primary' }}>{title}</DialogTitle>
            <Typography color="text.primary" sx={{ mt: 0.75, opacity: 0.78 }}>{description}</Typography>
          </Box>
        </Stack>
      </Box>
      <DialogContent sx={{ px: 3, py: 2.5 }}>
        <Grid container spacing={1}>
          {details.map(([label, value]) => (
            <Grid item xs={12} sm={6} key={label}>
              <Box sx={{ px: 1.5, py: 1.25, minHeight: 66, borderRadius: 1.5, bgcolor: (theme) => theme.palette.mode === 'light' ? alpha(theme.palette[tone].main, 0.065) : alpha(theme.palette[tone].main, 0.16), border: 1, borderColor: (theme) => alpha(theme.palette[tone].main, 0.24), color: 'text.primary' }}>
                <Typography variant="caption" color="text.secondary">{label}</Typography>
                <Typography fontWeight={900} sx={{ overflowWrap: 'anywhere' }}>{value}</Typography>
              </Box>
            </Grid>
          ))}
        </Grid>
        <Alert severity={tone} icon={<WarningAmberRoundedIcon />} variant="outlined" sx={{ mt: 2, bgcolor: (theme) => theme.palette.mode === 'light' ? alpha(theme.palette[tone].main, 0.045) : alpha(theme.palette[tone].main, 0.14), color: 'text.primary', '& .MuiAlert-icon': { color: `${tone}.main` } }}>
          Review these details before confirming. This operation will be recorded in the order activity history.
        </Alert>
      </DialogContent>
      <DialogActions sx={{ px: 3, py: 2, borderTop: 1, borderColor: 'divider', bgcolor: (theme) => alpha(theme.palette.background.default, 0.55) }}>
        <Button onClick={onClose} color="inherit">Go Back</Button>
        <Button variant="contained" color={tone} startIcon={icon} onClick={onConfirm} sx={{ minWidth: 180, boxShadow: (theme) => `0 7px 18px ${alpha(theme.palette[tone].main, 0.26)}` }}>
          {confirmLabel}
        </Button>
      </DialogActions>
    </Dialog>
  );
}

function ReleaseLinesTable({
  rows,
  sortKey,
  sortDirection,
  onSort
}: {
  rows: ReleaseTableRow[];
  sortKey: ReleaseSortKey;
  sortDirection: SortDirection;
  onSort: (sortKey: ReleaseSortKey) => void;
}) {
  const [actionAnchor, setActionAnchor] = useState<HTMLElement | null>(null);
  const [activeRelease, setActiveRelease] = useState<Release | null>(null);
  const [actionStatus, setActionStatus] = useState<ActionStatus | null>(null);
  const [actionReceiptOpen, setActionReceiptOpen] = useState(false);
  const [pendingAction, setPendingAction] = useState<null | {
    release: Release;
    kind: 'rerelease' | 'rerouteWithDn' | 'rerouteWithoutDn' | 'hardCancel';
    title: string;
    description: string;
    confirmLabel: string;
    tone: ConfirmationTone;
    icon: ReactNode;
    outcome: string;
  }>(null);

  const columns: Array<{ key: ReleaseSortKey; label: string; width?: number }> = [
    { key: 'lineNumber', label: 'Line', width: 58 },
    { key: 'sku', label: 'Item ID', width: 104 },
    { key: 'productName', label: 'Item Description', width: 210 },
    { key: 'lineStatus', label: 'Line Status', width: 106 },
    { key: 'lineTotal', label: 'Line Total', width: 92 },
    { key: 'releaseNumber', label: 'Release ID', width: 112 },
    { key: 'releaseLineId', label: 'Release Line ID', width: 118 },
    { key: 'releaseStatus', label: 'Release Status', width: 114 },
    { key: 'quantity', label: 'Qty', width: 54 },
    { key: 'fulfilledQty', label: 'Fulfilled', width: 76 },
    { key: 'cancelledQty', label: 'Cancelled', width: 78 },
    { key: 'assignedNode', label: 'Ship From', width: 104 },
    { key: 'updatedDate', label: 'Updated', width: 132 },
    { key: 'fulfillmentMethod', label: 'Method', width: 102 }
  ];

  const openReleaseActions = (event: ReactMouseEvent<HTMLButtonElement>, release: Release) => {
    setActionAnchor(event.currentTarget);
    setActiveRelease(release);
  };

  const closeReleaseActions = () => {
    setActionAnchor(null);
    setActiveRelease(null);
  };

  const requestReleaseAction = (kind: 'rerelease' | 'rerouteWithDn' | 'rerouteWithoutDn' | 'hardCancel') => {
    if (!activeRelease) return;
    const release = activeRelease;
    const action = kind === 'rerelease'
      ? {
          title: 'Re-release to fulfillment node?',
          description: 'This will create a new release attempt and resend the release payload to the assigned fulfillment node.',
          confirmLabel: 'Confirm Re-release',
          tone: 'info' as const,
          icon: <RestartAltIcon />,
          outcome: `re-release queued to ${release.assignedNode}.`
        }
      : kind === 'rerouteWithDn' ? {
          title: 'Re-route release with DN?',
          description: 'This will return the release to orchestration, create a delivery note, and select an eligible fulfillment node.',
          confirmLabel: 'Re-route With DN',
          tone: 'warning' as const,
          icon: <AltRouteIcon />,
          outcome: 're-route request with DN queued for orchestration.'
        } : kind === 'rerouteWithoutDn' ? {
          title: 'Re-route release without DN?',
          description: 'This will return the release to orchestration without creating a delivery note.',
          confirmLabel: 'Re-route Without DN',
          tone: 'warning' as const,
          icon: <AltRouteIcon />,
          outcome: 're-route request without DN queued for orchestration.'
        } : {
          title: 'Hard cancel this release?',
          description: 'This will permanently stop release processing and cannot be automatically reversed.',
          confirmLabel: 'Confirm Hard Cancel',
          tone: 'error' as const,
          icon: <BlockIcon />,
          outcome: 'hard cancellation request submitted.'
        };
    setPendingAction({ release, kind, ...action });
    setActionAnchor(null);
    setActiveRelease(null);
  };

  const confirmReleaseAction = async () => {
    if (!pendingAction) return;
    const action = pendingAction;
    let nextStatus: ActionStatus;
    try {
      const response = action.kind === 'rerelease'
        ? await omsApi.rereleaseToFulfillmentNode(action.release.releaseNumber)
        : action.kind === 'rerouteWithDn'
          ? await omsApi.rerouteRelease(action.release.releaseNumber, true)
          : action.kind === 'rerouteWithoutDn'
            ? await omsApi.rerouteRelease(action.release.releaseNumber, false)
            : await omsApi.hardCancelRelease(action.release.releaseNumber);
      nextStatus = {
        severity: 'success',
        message: `${response.releaseId}: ${response.status}. ${action.outcome}`
      };
    } catch (requestError) {
      nextStatus = {
        severity: 'error',
        message: requestError instanceof Error ? requestError.message : 'The release command could not be submitted.'
      };
    } finally {
      setPendingAction(null);
      setActionStatus(null);
      setActionReceiptOpen(false);
      window.setTimeout(() => {
        setActionStatus(nextStatus);
        setActionReceiptOpen(true);
      }, 120);
    }
  };

  return (
    <Box
      sx={{
        overflow: 'hidden',
        border: 1,
        borderColor: (theme) => alpha(theme.palette.primary.main, 0.26),
        borderRadius: 2.5,
        bgcolor: (theme) => theme.palette.mode === 'light' ? alpha('#ffffff', 0.94) : alpha(theme.palette.background.paper, 0.9),
        boxShadow: '0 18px 42px rgba(15,23,42,.13)',
        backdropFilter: 'blur(18px)'
      }}
    >
      <Box sx={{ overflowX: 'auto' }}>
        <Table
          size="small"
          sx={{
            minWidth: 1458,
            tableLayout: 'fixed',
            '& thead th': {
              background: (theme) => theme.palette.mode === 'light'
                ? 'linear-gradient(180deg, rgba(246,248,251,.98), rgba(222,229,238,.96))'
                : 'linear-gradient(180deg, rgba(38,45,55,.98), rgba(18,24,32,.98))',
              color: (theme) => theme.palette.mode === 'light' ? '#172033' : '#f7fafc',
              fontSize: '0.72rem',
              fontWeight: 950,
              lineHeight: 1.1,
              whiteSpace: 'nowrap',
              borderBottom: 1,
              borderBottomColor: (theme) => alpha(theme.palette.primary.main, 0.26),
              borderRight: 1,
              borderRightColor: (theme) => alpha(theme.palette.divider, 0.62),
              px: 0.8,
              py: 0.7
            },
            '& thead th:last-of-type': { borderRight: 0 },
            '& tbody tr': {
              transition: 'background-color .16s ease, box-shadow .16s ease',
              background: (theme) => theme.palette.mode === 'light'
                ? 'linear-gradient(90deg, rgba(255,255,255,.99), rgba(247,251,253,.97))'
                : alpha(theme.palette.background.paper, 0.74)
            },
            '& tbody tr:nth-of-type(even)': {
              background: (theme) => theme.palette.mode === 'light'
                ? 'linear-gradient(90deg, rgba(232,244,248,.74), rgba(241,248,250,.92))'
                : alpha(theme.palette.primary.main, 0.075)
            },
            '& tbody tr:nth-of-type(odd)': {
              background: (theme) => theme.palette.mode === 'light'
                ? 'linear-gradient(90deg, rgba(255,255,255,.99), rgba(248,252,253,.98))'
                : alpha(theme.palette.background.paper, 0.8)
            },
            '& tbody tr:hover': {
              background: (theme) => `${theme.palette.mode === 'light' ? 'linear-gradient(90deg, rgba(214,239,245,.96), rgba(238,248,251,.98))' : alpha(theme.palette.primary.main, 0.14)} !important`,
              boxShadow: 'inset 3px 0 0 rgba(17,124,139,.72)'
            },
            '& td': {
              px: 0.8,
              py: 0.65,
              verticalAlign: 'middle',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              borderBottomColor: (theme) => alpha(theme.palette.divider, 0.72),
              borderRight: 1,
              borderRightColor: (theme) => alpha(theme.palette.divider, 0.42)
            },
            '& td:last-of-type': { borderRight: 0 },
            '& .MuiChip-root': { height: 22, fontSize: '0.68rem', maxWidth: '100%', fontWeight: 850 },
            '& .MuiTableSortLabel-root': { maxWidth: '100%', color: 'inherit' },
            '& .MuiTableSortLabel-root:hover': { color: 'primary.main' },
            '& .MuiTableSortLabel-root.Mui-active': { color: 'primary.main' },
            '& .MuiTableSortLabel-icon': { color: 'primary.main !important', ml: 0.15 },
            '& .release-line-id': {
              display: 'inline-flex',
              alignItems: 'center',
              justifyContent: 'center',
              minWidth: 34,
              px: 0.6,
              py: 0.2,
              borderRadius: 1,
              color: '#0d6470',
              bgcolor: 'rgba(17,124,139,.1)',
              border: '1px solid rgba(17,124,139,.22)'
            }
          }}
        >
          <TableHead>
            <TableRow>
              {columns.map((column) => (
                <TableCell key={column.key} sortDirection={sortKey === column.key ? sortDirection : false} sx={{ width: column.width }}>
                  <TableSortLabel
                    active={sortKey === column.key}
                    direction={sortKey === column.key ? sortDirection : 'asc'}
                    onClick={() => onSort(column.key)}
                  >
                    {column.label}
                  </TableSortLabel>
                </TableCell>
              ))}
              <TableCell sx={{ width: 102, fontWeight: 950 }}>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.map(({ id, line, release }) => (
              <TableRow key={id} hover>
                <TableCell sx={{ fontWeight: 950 }} title={line.lineNumber}><Box component="span" className="release-line-id">{line.lineNumber}</Box></TableCell>
                <TableCell sx={{ fontWeight: 850 }} title={line.sku}>{line.sku}</TableCell>
                <TableCell title={line.productName}>
                  <Typography variant="body2" fontWeight={800} noWrap title={line.productName}>{line.productName}</Typography>
                  <Typography variant="caption" color="text.secondary" noWrap display="block">Ord {line.orderedQty} · Ful {line.fulfilledQty} · Cxl {line.cancelledQty}</Typography>
                </TableCell>
                <TableCell><StatusChip label={line.currentStatus} /></TableCell>
                <TableCell sx={{ fontWeight: 900 }}>{formatCurrency(line.lineTotal)}</TableCell>
                <TableCell sx={{ fontWeight: 950 }} title={release?.releaseNumber ?? 'Not released'}>{release?.releaseNumber ?? 'Not released'}</TableCell>
                <TableCell sx={{ fontWeight: 850 }} title={release?.releaseLineId ?? '-'}>{release?.releaseLineId ?? '-'}</TableCell>
                <TableCell>{release ? <StatusChip label={release.releaseStatus} /> : <Chip size="small" label="Pending" variant="outlined" />}</TableCell>
                <TableCell sx={{ fontWeight: 850 }}>{release?.quantity ?? '-'}</TableCell>
                <TableCell>{release?.fulfilledQty ?? '-'}</TableCell>
                <TableCell>{release?.cancelledQty ?? '-'}</TableCell>
                <TableCell sx={{ fontWeight: 850 }} title={release?.assignedNode ?? '-'}>{release?.assignedNode ?? '-'}</TableCell>
                <TableCell sx={{ whiteSpace: 'nowrap' }} title={release?.updatedDate ?? '-'}>{release?.updatedDate ?? '-'}</TableCell>
                <TableCell>{release ? <Chip size="small" label={release.fulfillmentMethod} variant="outlined" /> : '-'}</TableCell>
                <TableCell>
                  <Button
                    className="release-actions-button"
                    size="small"
                    variant="contained"
                    endIcon={<MoreVertIcon />}
                    disabled={!release}
                    onClick={(event) => release && openReleaseActions(event, release)}
                    sx={{
                      minWidth: 86,
                      px: 0.8,
                      fontSize: '0.7rem',
                      color: 'common.white',
                      background: 'linear-gradient(135deg, #0b5963, #168895 55%, #6fb5bd)',
                      border: '1px solid rgba(255,255,255,.42)',
                      boxShadow: '0 6px 16px rgba(17,124,139,.25)',
                      '&:hover': {
                        background: 'linear-gradient(135deg, #084951, #117c8b 55%, #55a5ae)',
                        boxShadow: '0 8px 20px rgba(17,124,139,.34)'
                      },
                      '&.Mui-disabled': {
                        color: 'rgba(15,23,42,.42)',
                        background: 'linear-gradient(135deg, rgba(226,232,240,.8), rgba(203,213,225,.72))',
                        borderColor: 'rgba(148,163,184,.34)'
                      }
                    }}
                  >
                    Actions
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Box>
      <Menu anchorEl={actionAnchor} open={Boolean(actionAnchor)} onClose={closeReleaseActions}>
        <MenuItem onClick={() => requestReleaseAction('rerelease')}>
          <ListItemIcon><RestartAltIcon fontSize="small" color="info" /></ListItemIcon>
          <ListItemText primary="Re-release to fulfillment node" />
        </MenuItem>
        <Divider />
        <MenuItem onClick={() => requestReleaseAction('rerouteWithDn')}>
          <ListItemIcon><AltRouteIcon fontSize="small" color="warning" /></ListItemIcon>
          <ListItemText primary="Re-route release with DN" />
        </MenuItem>
        <MenuItem onClick={() => requestReleaseAction('rerouteWithoutDn')}>
          <ListItemIcon><AltRouteIcon fontSize="small" color="warning" /></ListItemIcon>
          <ListItemText primary="Re-route release without DN" />
        </MenuItem>
        <Divider />
        <MenuItem onClick={() => requestReleaseAction('hardCancel')}>
          <ListItemIcon><BlockIcon fontSize="small" color="error" /></ListItemIcon>
          <ListItemText primary="Hard cancel release" />
        </MenuItem>
      </Menu>
      <ActionConfirmationDialog
        open={Boolean(pendingAction)}
        title={pendingAction?.title ?? ''}
        eyebrow="Release Command Confirmation"
        description={pendingAction?.description ?? ''}
        confirmLabel={pendingAction?.confirmLabel ?? 'Confirm'}
        tone={pendingAction?.tone ?? 'info'}
        icon={pendingAction?.icon ?? <RestartAltIcon />}
        details={pendingAction ? [
          ['Release ID', pendingAction.release.releaseNumber],
          ['Release Line ID', pendingAction.release.releaseLineId],
          ['Assigned Node', pendingAction.release.assignedNode],
          ['Current Status', pendingAction.release.releaseStatus]
        ] : []}
        onClose={() => setPendingAction(null)}
        onConfirm={confirmReleaseAction}
      />
      <Dialog
        open={Boolean(actionStatus) && actionReceiptOpen}
        onClose={() => setActionReceiptOpen(false)}
        maxWidth="sm"
        fullWidth
        sx={{ zIndex: (theme) => theme.zIndex.modal + 180 }}
        PaperProps={{
          sx: {
            overflow: 'hidden',
            borderRadius: 2.5,
            border: 1,
            borderColor: actionStatus?.severity === 'success' ? '#16a064' : actionStatus?.severity === 'error' ? '#d22f3a' : '#1769e0',
            boxShadow: '0 28px 80px rgba(15,23,42,.34)'
          }
        }}
      >
        <Box sx={{ px: 3, py: 2.5, background: actionStatus?.severity === 'success' ? 'linear-gradient(120deg, #e8fff3, #ffffff 72%)' : actionStatus?.severity === 'error' ? 'linear-gradient(120deg, #fff0f1, #ffffff 72%)' : 'linear-gradient(120deg, #eef7ff, #ffffff 72%)' }}>
          <Stack direction="row" spacing={1.75} alignItems="flex-start">
            <Box sx={{ width: 48, height: 48, flex: '0 0 auto', borderRadius: 2, display: 'grid', placeItems: 'center', color: actionStatus?.severity === 'success' ? '#087443' : actionStatus?.severity === 'error' ? '#9f1721' : '#0f4ea8', bgcolor: 'rgba(255,255,255,.72)', border: '1px solid rgba(17,24,39,.08)' }}>
              {actionStatus?.severity === 'error' ? <WarningAmberRoundedIcon /> : <RestartAltIcon />}
            </Box>
            <Box sx={{ minWidth: 0 }}>
              <Typography variant="overline" fontWeight={950} sx={{ color: actionStatus?.severity === 'success' ? '#087443' : actionStatus?.severity === 'error' ? '#9f1721' : '#0f4ea8' }}>
                Release Command
              </Typography>
              <Typography variant="h6" fontWeight={950} color="text.primary" sx={{ mt: 0.2 }}>
                {actionStatus?.severity === 'success' ? 'Release command submitted' : 'Release command needs attention'}
              </Typography>
              <Typography sx={{ mt: 0.75, color: '#111827', fontWeight: 850, lineHeight: 1.45 }}>
                {actionStatus?.message}
              </Typography>
            </Box>
          </Stack>
        </Box>
        <DialogActions sx={{ px: 3, py: 2, borderTop: 1, borderColor: 'divider', bgcolor: (theme) => alpha(theme.palette.background.default, 0.55) }}>
          <Button variant="contained" startIcon={<RestartAltIcon />} onClick={() => setActionReceiptOpen(false)} sx={{ minWidth: 150 }}>
            Done
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}

function LineValue({ label, value, strong = false }: { label: string; value: string; strong?: boolean }) {
  return <Box sx={{ minWidth: 0 }}><Typography variant="caption" color="text.secondary">{label}</Typography><Typography fontWeight={strong ? 900 : 700} noWrap title={value}>{value}</Typography></Box>;
}

function FulfillmentMetric({ label, value, accent, alert = false }: { label: string; value: string; accent: string; alert?: boolean }) {
  return (
    <Box
      sx={{
        minHeight: 48,
        px: 1.15,
        py: 0.75,
        borderRadius: 1.5,
        border: 1,
        borderColor: alpha(accent, alert ? 0.38 : 0.22),
        bgcolor: alpha(accent, alert ? 0.105 : 0.065),
        boxShadow: 'inset 0 1px 0 rgba(255,255,255,.34)'
      }}
    >
      <Typography variant="caption" color="text.secondary" sx={{ display: 'block', lineHeight: 1 }}>{label}</Typography>
      <Typography fontWeight={950} sx={{ color: alert ? 'error.main' : 'text.primary', lineHeight: 1.25 }}>{value}</Typography>
    </Box>
  );
}

function FulfillmentLines({ order }: { order: Order }) {
  const [syncStatus, setSyncStatus] = useState<ActionStatus | null>(null);
  const [syncReceiptOpen, setSyncReceiptOpen] = useState(false);
  const [syncTarget, setSyncTarget] = useState<Fulfillment | null>(null);
  const [allFulfillmentsOpen, setAllFulfillmentsOpen] = useState(false);
  const [fulfillmentSearch, setFulfillmentSearch] = useState('');
  const [fulfillmentPage, setFulfillmentPage] = useState(1);
  const [fulfillmentSortKey, setFulfillmentSortKey] = useState<FulfillmentSortKey>('nodeName');
  const [fulfillmentSortDirection, setFulfillmentSortDirection] = useState<SortDirection>('asc');
  const [fulfillmentMultiSort, setFulfillmentMultiSort] = useState(false);
  const locations = useMemo(() => {
    const grouped = new Map<string, { type: Fulfillment['type']; nodeId: string; nodeName: string; releases: Fulfillment[] }>();
    order.fulfillments.forEach((fulfillment) => {
      const key = `${fulfillment.type}-${fulfillment.nodeId}`;
      const current = grouped.get(key);
      if (current) current.releases.push(fulfillment);
      else grouped.set(key, { type: fulfillment.type, nodeId: fulfillment.nodeId, nodeName: fulfillment.nodeName, releases: [fulfillment] });
    });
    return Array.from(grouped.values());
  }, [order.fulfillments]);
  const fulfillmentQuantity = order.fulfillments.reduce((total, release) => total + release.quantity, 0);
  const activeShipments = order.fulfillments.filter((release) => release.trackingNumber !== 'Pending' && release.status !== 'Cancelled').length;
  const fulfillmentExceptions = order.fulfillments.filter((release) => release.status === 'Cancelled' || release.status.includes('Awaiting')).length;
  const normalizedFulfillmentSearch = fulfillmentSearch.trim().toLowerCase();
  const filteredFulfillmentRows = useMemo(() => {
    if (!normalizedFulfillmentSearch) return order.fulfillments;

    return order.fulfillments.filter((release) => [
        release.fulfillmentId,
        release.type,
        release.nodeId,
        release.nodeName,
        release.status,
        release.releaseNumber,
        release.releaseLineId,
        release.packageId,
        release.packageDetailId,
        release.shipmentId,
        release.quantity,
        release.shipVia,
        release.trackingNumber
      ].join(' ').toLowerCase().includes(normalizedFulfillmentSearch));
  }, [normalizedFulfillmentSearch, order.fulfillments]);
  const filteredFulfillmentCount = filteredFulfillmentRows.length;
  const filteredFulfillmentLocationCount = new Set(filteredFulfillmentRows.map((release) => `${release.type}-${release.nodeId}`)).size;
  const sortedFulfillmentRows = useMemo(() => {
    return [...filteredFulfillmentRows].sort((first, second) => {
      const compareValues = (sortKey: FulfillmentSortKey) => {
        const firstValue = sortKey === 'shippedQty' ? getFulfillmentShippedQty(first, order.releases) : getFulfillmentSortValue(first, sortKey);
        const secondValue = sortKey === 'shippedQty' ? getFulfillmentShippedQty(second, order.releases) : getFulfillmentSortValue(second, sortKey);
        return typeof firstValue === 'number' && typeof secondValue === 'number'
          ? firstValue - secondValue
          : String(firstValue).localeCompare(String(secondValue), undefined, { numeric: true, sensitivity: 'base' });
      };
      const result = fulfillmentMultiSort
        ? (compareValues('type') || compareValues('nodeName') || compareValues('status') || compareValues('releaseNumber'))
        : compareValues(fulfillmentSortKey);
      return fulfillmentSortDirection === 'asc' ? result : -result;
    });
  }, [filteredFulfillmentRows, fulfillmentMultiSort, fulfillmentSortDirection, fulfillmentSortKey, order.releases]);
  const fulfillmentPageCount = Math.max(1, Math.ceil(sortedFulfillmentRows.length / popupPageSize));
  const pagedFulfillmentRows = sortedFulfillmentRows.slice((fulfillmentPage - 1) * popupPageSize, fulfillmentPage * popupPageSize);

  const closeAllFulfillments = () => {
    setAllFulfillmentsOpen(false);
    setFulfillmentSearch('');
    setFulfillmentPage(1);
  };

  const goBackToFulfillmentPopup = () => {
    setSyncTarget(null);
    setAllFulfillmentsOpen(true);
  };

  const handleFulfillmentSort = (sortKey: FulfillmentSortKey) => {
    setFulfillmentMultiSort(false);
    if (fulfillmentSortKey === sortKey) {
      setFulfillmentSortDirection((current) => current === 'asc' ? 'desc' : 'asc');
    } else {
      setFulfillmentSortKey(sortKey);
      setFulfillmentSortDirection('asc');
    }
    setFulfillmentPage(1);
  };

  const confirmSync = async () => {
    if (!syncTarget) return;
    const target = syncTarget;
    let nextStatus: ActionStatus;
    try {
      const response = await omsApi.syncFulfillment(target.fulfillmentId);
      nextStatus = {
        severity: 'success',
        message: `${target.releaseNumber}: Fulfillment sync requested. Status sync queued for ${response.fulfillmentId}.`
      };
    } catch (requestError) {
      nextStatus = {
        severity: 'error',
        message: requestError instanceof Error ? requestError.message : 'The fulfillment sync could not be submitted.'
      };
    } finally {
      setSyncTarget(null);
      setSyncStatus(null);
      setSyncReceiptOpen(false);
      window.setTimeout(() => {
        setSyncStatus(nextStatus);
        setSyncReceiptOpen(true);
      }, 120);
    }
  };
  return (
    <Box>
      <Stack direction={{ xs: 'column', sm: 'row' }} justifyContent="space-between" alignItems={{ xs: 'flex-start', sm: 'center' }} gap={0.75} sx={{ mb: 0.75 }}>
        <Box>
          <Typography variant="subtitle2" fontWeight={950}>Fulfillment Node Status</Typography>
          <Typography variant="caption" color="text.secondary">Actual node-level execution status by warehouse, store, dropship, or supplier location</Typography>
        </Box>
        <Chip size="small" label={`${order.fulfillments.length} releases`} variant="outlined" />
      </Stack>
      <GlassCard sx={{ mb: 0.75, overflow: 'hidden', borderColor: (theme) => alpha(theme.palette.primary.main, 0.3), bgcolor: (theme) => alpha(theme.palette.primary.main, 0.045) }}>
        <ButtonBase aria-label="Open all fulfillment releases" onClick={() => setAllFulfillmentsOpen(true)} sx={{ width: '100%', p: { xs: 1, md: 1.1 }, textAlign: 'left' }}>
          <Box sx={{ width: '100%', display: 'grid', gridTemplateColumns: { xs: 'repeat(2, minmax(0, 1fr))', md: 'repeat(5, minmax(0, 1fr)) 28px' }, gap: { xs: 0.75, md: 1 }, alignItems: 'center' }}>
            <AggregateMetric label="Locations" value={String(locations.length)} />
            <AggregateMetric label="Node Records" value={String(order.fulfillments.length)} />
            <AggregateMetric label="Total Quantity" value={String(fulfillmentQuantity)} />
            <AggregateMetric label="Active Shipments" value={String(activeShipments)} />
            <AggregateMetric label="Exceptions" value={String(fulfillmentExceptions)} alert={fulfillmentExceptions > 0} />
            <OpenInNewIcon color="primary" />
          </Box>
        </ButtonBase>
      </GlassCard>
      <Dialog
        open={allFulfillmentsOpen}
        onClose={closeAllFulfillments}
        fullWidth
        maxWidth={false}
        aria-labelledby={`all-fulfillments-${order.orderNumber}`}
        PaperProps={{
          sx: {
            m: { xs: 1, md: 1.5 },
            width: { xs: 'calc(100vw - 16px)', md: 'calc(100vw - 24px)' },
            maxWidth: '1760px',
            height: 'auto',
            maxHeight: { xs: 'calc(100vh - 24px)', md: 'calc(100vh - 36px)' },
            overflow: 'hidden',
            borderRadius: 2.5,
            border: 1,
            borderColor: (theme) => alpha(theme.palette.primary.main, 0.28),
            background: (theme) => theme.palette.mode === 'light'
              ? `linear-gradient(145deg, ${alpha(theme.palette.background.default, 0.7)}, ${alpha(theme.palette.primary.main, 0.055)} 44%, ${alpha(theme.palette.background.paper, 0.98)} 100%)`
              : `linear-gradient(145deg, ${alpha(theme.palette.background.default, 0.84)}, ${alpha(theme.palette.primary.main, 0.12)} 48%, ${alpha(theme.palette.background.paper, 0.92)} 100%)`,
            boxShadow: '0 24px 74px rgba(15,23,42,.28)'
          }
        }}
      >
        <DialogTitle
          id={`all-fulfillments-${order.orderNumber}`}
          sx={{
            position: 'relative',
            pr: 7,
            px: { xs: 2, md: 3 },
            py: 2.15,
            bgcolor: 'background.paper',
            borderBottom: 1,
            borderColor: 'divider'
          }}
        >
          <Stack direction="row" spacing={1.5} alignItems="center">
            <Box sx={{ width: 42, height: 42, borderRadius: 1.75, display: 'grid', placeItems: 'center', color: 'primary.main', bgcolor: (theme) => alpha(theme.palette.primary.main, 0.1), border: 1, borderColor: (theme) => alpha(theme.palette.primary.main, 0.22) }}>
              <LocalShippingIcon />
            </Box>
            <Box sx={{ minWidth: 0 }}>
              <Typography variant="h6" sx={{ fontWeight: 950, letterSpacing: 0 }}>Fulfillment Node Status & Releases</Typography>
              <Typography variant="body2" color="text.secondary">{order.orderNumber} · {filteredFulfillmentLocationCount} of {locations.length} nodes · {filteredFulfillmentCount} of {order.fulfillments.length} node status records · {sortedFulfillmentRows.length} table rows</Typography>
            </Box>
          </Stack>
          <IconButton aria-label="Close all fulfillment releases" onClick={closeAllFulfillments} sx={{ position: 'absolute', right: 14, top: 14 }}><CloseIcon /></IconButton>
        </DialogTitle>
        <DialogContent dividers sx={{ p: { xs: 1.5, md: 2 }, bgcolor: 'transparent', overflowY: 'auto' }}>
          <Box sx={{ position: 'sticky', top: 0, zIndex: 2, mb: 1.5, px: 1.5, py: 1.25, border: 1, borderColor: 'divider', borderRadius: 2, bgcolor: (theme) => alpha(theme.palette.background.paper, 0.95), backdropFilter: 'blur(14px)', boxShadow: '0 10px 24px rgba(15,23,42,.06)' }}>
            <Stack direction={{ xs: 'column', md: 'row' }} spacing={1.25} alignItems={{ xs: 'stretch', md: 'center' }}>
              <TextField
                fullWidth
                size="small"
                label="Search fulfillment node status"
                value={fulfillmentSearch}
                onChange={(event) => {
                  setFulfillmentSearch(event.target.value);
                  setFulfillmentPage(1);
                }}
                placeholder="Search node, release, package, shipment, status, tracking"
                InputProps={{
                  startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment>,
                  sx: {
                    borderRadius: 1.75,
                    bgcolor: (theme) => theme.palette.mode === 'light' ? '#ffffff' : alpha(theme.palette.common.white, 0.06),
                    boxShadow: '0 8px 22px rgba(15,23,42,.06)'
                  }
                }}
              />
              <Button
                variant="outlined"
                startIcon={<TuneIcon />}
                onClick={() => {
                  if (fulfillmentSortKey === 'nodeName') {
                    setFulfillmentSortDirection((current) => current === 'asc' ? 'desc' : 'asc');
                  } else {
                    setFulfillmentSortKey('nodeName');
                    setFulfillmentSortDirection('asc');
                  }
                  setFulfillmentPage(1);
                }}
                sx={{ minWidth: 154, borderRadius: 1.75, fontWeight: 900, bgcolor: (theme) => alpha(theme.palette.primary.main, 0.045) }}
              >
                Sort by Location
              </Button>
              <Button
                variant={fulfillmentMultiSort ? 'contained' : 'outlined'}
                startIcon={<TuneIcon />}
                onClick={() => {
                  setFulfillmentMultiSort((current) => !current);
                  setFulfillmentPage(1);
                }}
                sx={{ minWidth: 132, borderRadius: 1.75, fontWeight: 900 }}
              >
                Multi-sort {fulfillmentMultiSort ? 'On' : 'Off'}
              </Button>
            </Stack>
          </Box>
          <Box>
            <FulfillmentLinesTable
              rows={pagedFulfillmentRows}
              sortKey={fulfillmentSortKey}
              sortDirection={fulfillmentSortDirection}
              onSort={handleFulfillmentSort}
              onSync={setSyncTarget}
              releases={order.releases}
              multiSort={fulfillmentMultiSort}
            />
          </Box>
          {!filteredFulfillmentRows.length && <Alert severity="info" sx={{ m: 2 }}>No fulfillment node status records match this popup search.</Alert>}
          {sortedFulfillmentRows.length > popupPageSize && (
            <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.25} alignItems={{ xs: 'flex-start', sm: 'center' }} justifyContent="space-between" sx={{ position: 'sticky', bottom: 0, mt: 1.5, px: 1.5, py: 1.25, border: 1, borderColor: 'divider', borderRadius: 2, bgcolor: (theme) => alpha(theme.palette.background.paper, 0.96), backdropFilter: 'blur(14px)', boxShadow: '0 -10px 24px rgba(15,23,42,.06)' }}>
              <Typography variant="body2" color="text.secondary">
                Showing {(fulfillmentPage - 1) * popupPageSize + 1}-{Math.min(fulfillmentPage * popupPageSize, sortedFulfillmentRows.length)} of {sortedFulfillmentRows.length} matching fulfillment node status records
              </Typography>
              <Pagination count={fulfillmentPageCount} page={fulfillmentPage} onChange={(_, value) => setFulfillmentPage(value)} color="primary" size="small" />
            </Stack>
          )}
        </DialogContent>
      </Dialog>
      <ActionConfirmationDialog
        open={Boolean(syncTarget)}
        title="Sync this release status?"
        eyebrow="Fulfillment Synchronization"
        description="The latest package and shipment status will be synchronized to this release line only."
        confirmLabel="Confirm Sync"
        tone="info"
        icon={<SyncIcon />}
        details={syncTarget ? [
          ['Release ID', syncTarget.releaseNumber],
          ['Release Line ID', syncTarget.releaseLineId],
          ['Fulfillment Location', `${syncTarget.nodeId} · ${syncTarget.nodeName}`],
          ['Current Status', syncTarget.status]
        ] : []}
        onClose={goBackToFulfillmentPopup}
        onConfirm={confirmSync}
      />
      <Dialog
        open={Boolean(syncStatus) && syncReceiptOpen}
        onClose={() => setSyncReceiptOpen(false)}
        maxWidth="sm"
        fullWidth
        sx={{ zIndex: (theme) => theme.zIndex.modal + 180 }}
        PaperProps={{
          sx: {
            overflow: 'hidden',
            borderRadius: 2.5,
            border: 1,
            borderColor: syncStatus?.severity === 'success' ? '#16a064' : syncStatus?.severity === 'error' ? '#d22f3a' : '#1769e0',
            boxShadow: '0 28px 80px rgba(15,23,42,.34)'
          }
        }}
      >
        <Box sx={{ px: 3, py: 2.5, background: syncStatus?.severity === 'success' ? 'linear-gradient(120deg, #e8fff3, #ffffff 72%)' : syncStatus?.severity === 'error' ? 'linear-gradient(120deg, #fff0f1, #ffffff 72%)' : 'linear-gradient(120deg, #eef7ff, #ffffff 72%)' }}>
          <Stack direction="row" spacing={1.75} alignItems="flex-start">
            <Box sx={{ width: 48, height: 48, flex: '0 0 auto', borderRadius: 2, display: 'grid', placeItems: 'center', color: syncStatus?.severity === 'success' ? '#087443' : syncStatus?.severity === 'error' ? '#9f1721' : '#0f4ea8', bgcolor: 'rgba(255,255,255,.72)', border: '1px solid rgba(17,24,39,.08)' }}>
              <SyncIcon />
            </Box>
            <Box sx={{ minWidth: 0 }}>
              <Typography variant="overline" fontWeight={950} sx={{ color: syncStatus?.severity === 'success' ? '#087443' : syncStatus?.severity === 'error' ? '#9f1721' : '#0f4ea8' }}>
                Fulfillment Synchronization
              </Typography>
              <Typography variant="h6" fontWeight={950} color="text.primary" sx={{ mt: 0.2 }}>
                {syncStatus?.severity === 'success' ? 'Sync request submitted' : 'Sync request needs attention'}
              </Typography>
              <Typography sx={{ mt: 0.75, color: '#111827', fontWeight: 850, lineHeight: 1.45 }}>
                {syncStatus?.message}
              </Typography>
            </Box>
          </Stack>
        </Box>
        <DialogActions sx={{ px: 3, py: 2, borderTop: 1, borderColor: 'divider', bgcolor: (theme) => alpha(theme.palette.background.default, 0.55) }}>
          <Button variant="contained" startIcon={<SyncIcon />} onClick={() => setSyncReceiptOpen(false)} sx={{ minWidth: 150 }}>
            Done
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}

function FulfillmentLinesTable({
  rows,
  sortKey,
  sortDirection,
  onSort,
  onSync,
  releases,
  multiSort
}: {
  rows: Fulfillment[];
  sortKey: FulfillmentSortKey;
  sortDirection: SortDirection;
  onSort: (sortKey: FulfillmentSortKey) => void;
  onSync: (fulfillment: Fulfillment) => void;
  releases: Release[];
  multiSort: boolean;
}) {
  const columns: Array<{ key: FulfillmentSortKey; label: string; width: number }> = [
    { key: 'releaseNumber', label: 'Release ID', width: 98 },
    { key: 'releaseLineId', label: 'Release Line', width: 104 },
    { key: 'type', label: 'Type', width: 82 },
    { key: 'nodeName', label: 'Fulfillment Location', width: 172 },
    { key: 'nodeId', label: 'Node ID', width: 88 },
    { key: 'packageId', label: 'Package ID', width: 100 },
    { key: 'packageDetailId', label: 'Package Detail', width: 112 },
    { key: 'shipmentId', label: 'Shipment ID', width: 102 },
    { key: 'orderedQty', label: 'Ordered Qty', width: 74 },
    { key: 'shippedQty', label: 'Shipped Qty', width: 74 },
    { key: 'status', label: 'Status', width: 112 },
    { key: 'shipVia', label: 'Ship Via', width: 112 },
    { key: 'trackingNumber', label: 'Tracking #', width: 120 }
  ];

  return (
    <Box
      sx={{
        overflow: 'hidden',
        border: 1,
        borderColor: (theme) => alpha(theme.palette.primary.main, 0.26),
        borderRadius: 2.5,
        bgcolor: (theme) => theme.palette.mode === 'light' ? alpha('#ffffff', 0.94) : alpha(theme.palette.background.paper, 0.9),
        boxShadow: '0 18px 42px rgba(15,23,42,.13)',
        backdropFilter: 'blur(18px)'
      }}
    >
      <Box sx={{ overflowX: 'auto' }}>
        <Table
          size="small"
          sx={{
            width: 'max(100%, 1280px)',
            minWidth: 1180,
            tableLayout: 'fixed',
            '& thead th': {
              background: (theme) => theme.palette.mode === 'light'
                ? 'linear-gradient(180deg, rgba(246,248,251,.98), rgba(222,229,238,.96))'
                : 'linear-gradient(180deg, rgba(38,45,55,.98), rgba(18,24,32,.98))',
              color: (theme) => theme.palette.mode === 'light' ? '#172033' : '#f7fafc',
              fontSize: '0.72rem',
              fontWeight: 950,
              lineHeight: 1.1,
              whiteSpace: 'normal',
              overflowWrap: 'anywhere',
              borderBottom: 1,
              borderBottomColor: (theme) => alpha(theme.palette.primary.main, 0.26),
              borderRight: 1,
              borderRightColor: (theme) => alpha(theme.palette.divider, 0.62),
              px: 0.65,
              py: 0.6
            },
            '& thead th:last-of-type': { borderRight: 0 },
            '& tbody tr': {
              transition: 'background-color .16s ease, box-shadow .16s ease',
              background: (theme) => theme.palette.mode === 'light'
                ? 'linear-gradient(90deg, rgba(255,255,255,.99), rgba(247,251,253,.97))'
                : alpha(theme.palette.background.paper, 0.74)
            },
            '& tbody tr:nth-of-type(even)': {
              background: (theme) => theme.palette.mode === 'light'
                ? 'linear-gradient(90deg, rgba(232,244,248,.74), rgba(241,248,250,.92))'
                : alpha(theme.palette.primary.main, 0.075)
            },
            '& tbody tr:nth-of-type(odd)': {
              background: (theme) => theme.palette.mode === 'light'
                ? 'linear-gradient(90deg, rgba(255,255,255,.99), rgba(248,252,253,.98))'
                : alpha(theme.palette.background.paper, 0.8)
            },
            '& tbody tr:hover': {
              background: (theme) => `${theme.palette.mode === 'light' ? 'linear-gradient(90deg, rgba(214,239,245,.96), rgba(238,248,251,.98))' : alpha(theme.palette.primary.main, 0.14)} !important`,
              boxShadow: 'inset 3px 0 0 rgba(17,124,139,.72)'
            },
            '& td': {
              px: 0.65,
              py: 0.58,
              verticalAlign: 'middle',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              overflowWrap: 'anywhere',
              wordBreak: 'break-word',
              borderBottomColor: (theme) => alpha(theme.palette.divider, 0.72),
              borderRight: 1,
              borderRightColor: (theme) => alpha(theme.palette.divider, 0.42)
            },
            '& td:last-of-type': { borderRight: 0 },
            '& .MuiChip-root': { height: 22, fontSize: '0.68rem', maxWidth: '100%', fontWeight: 850 },
            '& .MuiTableSortLabel-root': { maxWidth: '100%', color: 'inherit' },
            '& .MuiTableSortLabel-root:hover': { color: 'primary.main' },
            '& .MuiTableSortLabel-root.Mui-active': { color: 'primary.main' },
            '& .MuiTableSortLabel-icon': { color: 'primary.main !important', ml: 0.15 },
            '& .fulfillment-location-pill': {
              display: 'inline-flex',
              alignItems: 'center',
              maxWidth: '100%',
              gap: 0.55,
              px: 0.75,
              py: 0.35,
              borderRadius: 1.25,
              color: '#0d6470',
              bgcolor: 'rgba(17,124,139,.1)',
              border: '1px solid rgba(17,124,139,.22)'
            },
            '& .fulfillment-type-chip': {
              height: 22,
              minWidth: 62,
              borderRadius: 999,
              color: '#ffffff',
              fontSize: '0.62rem',
              fontWeight: 950
            }
          }}
        >
          <TableHead>
            <TableRow>
              {columns.map((column) => (
                <TableCell key={column.key} sortDirection={!multiSort && sortKey === column.key ? sortDirection : false} sx={{ width: column.width }}>
                  <TableSortLabel
                    active={!multiSort && sortKey === column.key}
                    direction={!multiSort && sortKey === column.key ? sortDirection : 'asc'}
                    onClick={() => onSort(column.key)}
                  >
                    {column.label}
                  </TableSortLabel>
                </TableCell>
              ))}
              <TableCell sx={{ width: 86, fontWeight: 950 }}>Sync</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.map((release) => {
              const accent = getFulfillmentTypeColor(release.type);
              const Icon = release.type === 'Warehouse' ? WarehouseIcon : release.type === 'Store' ? StorefrontIcon : LocalShippingIcon;
              const shippedQty = getFulfillmentShippedQty(release, releases);
              const statusStyle = getFulfillmentStatusStyle(release.status);
              return (
                <TableRow
                  key={release.fulfillmentId}
                  hover
                  sx={{
                    '& td:first-of-type': { boxShadow: `inset 4px 0 0 ${accent}` },
                    '&:nth-of-type(odd)': {
                      background: (theme) => theme.palette.mode === 'light'
                        ? `linear-gradient(90deg, ${alpha(accent, 0.045)}, rgba(255,255,255,.99) 24%, rgba(248,252,253,.98))`
                        : alpha(accent, 0.055)
                    },
                    '&:nth-of-type(even)': {
                      background: (theme) => theme.palette.mode === 'light'
                        ? `linear-gradient(90deg, ${alpha(accent, 0.09)}, rgba(232,244,248,.76) 30%, rgba(241,248,250,.92))`
                        : alpha(accent, 0.09)
                    }
                  }}
                >
                  <TableCell sx={{ fontWeight: 950, whiteSpace: 'nowrap' }} title={release.releaseNumber}>{release.releaseNumber}</TableCell>
                  <TableCell sx={{ fontWeight: 850, whiteSpace: 'normal' }} title={release.releaseLineId}>{release.releaseLineId}</TableCell>
                  <TableCell><Chip className="fulfillment-type-chip" label={release.type} sx={{ bgcolor: accent }} /></TableCell>
                  <TableCell title={`${release.nodeName} · ${release.nodeId}`}>
                    <Box component="span" className="fulfillment-location-pill" sx={{ minWidth: 0 }}>
                      <Icon sx={{ fontSize: 15, flex: '0 0 auto', color: accent }} />
                      <Typography component="span" variant="body2" fontWeight={900} sx={{ whiteSpace: 'normal', lineHeight: 1.15 }}>{release.nodeName}</Typography>
                    </Box>
                  </TableCell>
                  <TableCell sx={{ fontWeight: 850, whiteSpace: 'normal' }} title={release.nodeId}>{release.nodeId}</TableCell>
                  <TableCell sx={{ fontWeight: 850, whiteSpace: 'normal' }} title={release.packageId}>{release.packageId}</TableCell>
                  <TableCell sx={{ whiteSpace: 'normal' }} title={release.packageDetailId}>{release.packageDetailId}</TableCell>
                  <TableCell sx={{ whiteSpace: 'normal' }} title={release.shipmentId}>{release.shipmentId}</TableCell>
                  <TableCell sx={{ fontWeight: 900 }}>{release.quantity}</TableCell>
                  <TableCell sx={{ fontWeight: 900, color: shippedQty > 0 ? 'success.main' : 'text.secondary' }}>{shippedQty}</TableCell>
                  <TableCell>
                    <Chip
                      size="small"
                      label={release.status}
                      sx={{
                        color: statusStyle.fg,
                        bgcolor: statusStyle.bg,
                        border: `1px solid ${statusStyle.border}`,
                        fontWeight: 950,
                        height: 'auto',
                        minHeight: 22,
                        '& .MuiChip-label': { whiteSpace: 'normal', lineHeight: 1.1, py: 0.25 }
                      }}
                    />
                  </TableCell>
                  <TableCell sx={{ whiteSpace: 'normal' }} title={release.shipVia}>{release.shipVia}</TableCell>
                  <TableCell sx={{ fontWeight: 850, whiteSpace: 'normal' }} title={release.trackingNumber}>{release.trackingNumber}</TableCell>
                  <TableCell>
                    <Button
                      className="sync-release-button"
                      size="small"
                      variant="contained"
                      startIcon={<SyncIcon />}
                      onClick={() => onSync(release)}
                      sx={{
                        minWidth: 74,
                        px: 0.65,
                        fontSize: '0.68rem',
                        color: 'common.white',
                        background: 'linear-gradient(135deg, #0b5963, #168895 55%, #6fb5bd)',
                        border: '1px solid rgba(255,255,255,.42)',
                        boxShadow: '0 6px 16px rgba(17,124,139,.25)',
                        '&:hover': { background: 'linear-gradient(135deg, #084951, #117c8b 55%, #55a5ae)', boxShadow: '0 8px 20px rgba(17,124,139,.34)' }
                      }}
                    >
                      Sync
                    </Button>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </Box>
    </Box>
  );
}

function FulfillmentLocationSummary({ location }: { location: { type: Fulfillment['type']; nodeId: string; nodeName: string; releases: Fulfillment[] } }) {
  const Icon = location.type === 'Warehouse' ? WarehouseIcon : location.type === 'Store' ? StorefrontIcon : LocalShippingIcon;
  const totalQuantity = location.releases.reduce((total, release) => total + release.quantity, 0);
  const statuses = Array.from(new Set(location.releases.map((release) => release.status)));
  const statusSummary = statuses.length === 1 ? statuses[0] : `${statuses.length} statuses`;
  return (
    <GlassCard sx={{ p: 1.35, borderLeft: '4px solid', borderLeftColor: 'info.main', bgcolor: (theme) => alpha(theme.palette.info.main, 0.035) }}>
      <Box sx={{ width: '100%', display: 'grid', gridTemplateColumns: { xs: '1fr', md: 'minmax(230px, 1.8fr) 110px 110px 90px minmax(150px, 1fr)' }, gap: { xs: 0.75, md: 1.5 }, alignItems: 'center' }}>
        <Stack direction="row" spacing={1.1} alignItems="center" sx={{ minWidth: 0 }}>
          <Box sx={{ width: 36, height: 36, borderRadius: 1.5, display: 'grid', placeItems: 'center', flex: '0 0 auto', color: 'info.main', bgcolor: (theme) => alpha(theme.palette.info.main, 0.1) }}><Icon fontSize="small" /></Box>
          <LineValue label={location.nodeId} value={location.nodeName} strong />
        </Stack>
        <Box><Typography variant="caption" color="text.secondary">Type</Typography><Box><Chip size="small" label={location.type} variant="outlined" /></Box></Box>
        <LineValue label="Release Lines" value={String(location.releases.length)} strong />
        <LineValue label="Total Qty" value={String(totalQuantity)} strong />
        <Box><Typography variant="caption" color="text.secondary">Execution Status</Typography><Box><Chip size="small" label={statusSummary} color={statusSummary === 'Cancelled' ? 'error' : statusSummary === 'In Transit' || statusSummary === 'Ready for Pickup' ? 'success' : 'info'} /></Box></Box>
      </Box>
    </GlassCard>
  );
}

function FulfillmentLocationDialogRow({
  location,
  onSync
}: {
  location: { type: Fulfillment['type']; nodeId: string; nodeName: string; releases: Fulfillment[] };
  onSync: (fulfillment: Fulfillment) => void;
}) {
  const [detailsOpen, setDetailsOpen] = useState(false);
  const Icon = location.type === 'Warehouse' ? WarehouseIcon : location.type === 'Store' ? StorefrontIcon : LocalShippingIcon;
  const totalQuantity = location.releases.reduce((total, release) => total + release.quantity, 0);
  const statuses = Array.from(new Set(location.releases.map((release) => release.status)));
  const statusSummary = statuses.length === 1 ? statuses[0] : `${statuses.length} statuses`;

  return (
    <>
      <GlassCard
        sx={{
          borderLeft: '4px solid',
          borderLeftColor: 'info.main',
          bgcolor: (theme) => alpha(theme.palette.info.main, 0.035),
          borderColor: (theme) => alpha(theme.palette.info.main, 0.28),
          transition: 'background-color 180ms ease, border-color 180ms ease, box-shadow 180ms ease',
          '&:hover': { borderColor: 'warning.main', bgcolor: (theme) => alpha(theme.palette.warning.main, 0.08), boxShadow: (theme) => `0 8px 24px ${alpha(theme.palette.warning.main, 0.14)}` }
        }}
      >
        <ButtonBase aria-label={`Open fulfillment ${location.nodeId} details`} onClick={() => setDetailsOpen(true)} sx={{ width: '100%', p: 1.35, textAlign: 'left' }}>
          <Box sx={{ width: '100%', display: 'grid', gridTemplateColumns: { xs: '1fr', md: 'minmax(230px, 1.8fr) 110px 110px 90px minmax(150px, 1fr) 28px' }, gap: { xs: 0.75, md: 1.5 }, alignItems: 'center' }}>
            <Stack direction="row" spacing={1.1} alignItems="center" sx={{ minWidth: 0 }}>
              <Box className="fulfillment-type-icon" sx={{ width: 36, height: 36, borderRadius: 1.5, display: 'grid', placeItems: 'center', flex: '0 0 auto', color: 'info.main', bgcolor: (theme) => alpha(theme.palette.info.main, 0.1) }}><Icon fontSize="small" /></Box>
              <LineValue label={location.nodeId} value={location.nodeName} strong />
            </Stack>
            <Box><Typography variant="caption" color="text.secondary">Type</Typography><Box><Chip size="small" label={location.type} variant="outlined" /></Box></Box>
            <LineValue label="Release Lines" value={String(location.releases.length)} strong />
            <LineValue label="Total Qty" value={String(totalQuantity)} strong />
            <Box><Typography variant="caption" color="text.secondary">Execution Status</Typography><Box><Chip size="small" label={statusSummary} color={statusSummary === 'Cancelled' ? 'error' : statusSummary === 'In Transit' || statusSummary === 'Ready for Pickup' ? 'success' : 'info'} /></Box></Box>
            <OpenInNewIcon fontSize="small" color="info" />
          </Box>
        </ButtonBase>
      </GlassCard>
      <Dialog open={detailsOpen} onClose={() => setDetailsOpen(false)} fullWidth maxWidth="xl" aria-labelledby={`fulfillment-details-${location.nodeId}`}>
        <DialogTitle id={`fulfillment-details-${location.nodeId}`} sx={{ pr: 7 }}>
          <Stack direction="row" spacing={1.25} alignItems="center" flexWrap="wrap" useFlexGap>
            <Box sx={{ width: 38, height: 38, borderRadius: 1.5, display: 'grid', placeItems: 'center', color: 'info.main', bgcolor: (theme) => alpha(theme.palette.info.main, 0.1) }}><Icon /></Box>
            <Box>
              <Typography variant="h6">{location.nodeName}</Typography>
              <Typography variant="body2" color="text.secondary">{location.nodeId} · {location.type} · {location.releases.length} release lines</Typography>
            </Box>
            <Chip size="small" label={statusSummary} color={statusSummary === 'Cancelled' ? 'error' : statusSummary === 'In Transit' || statusSummary === 'Ready for Pickup' ? 'success' : 'info'} />
          </Stack>
          <IconButton aria-label="Close fulfillment details" onClick={() => setDetailsOpen(false)} sx={{ position: 'absolute', right: 14, top: 14 }}><CloseIcon /></IconButton>
        </DialogTitle>
        <DialogContent dividers sx={{ p: 0, bgcolor: (theme) => alpha(theme.palette.warning.main, 0.04) }}>
        <Box sx={{ px: 2, py: 1.15, borderBottom: 1, borderColor: 'divider', bgcolor: (theme) => alpha(theme.palette.warning.main, 0.075) }}>
          <Typography variant="overline" fontWeight={900} color="text.secondary">{location.releases.length} releases fulfilled by {location.nodeName}</Typography>
        </Box>
        <Box sx={{ overflowX: 'auto' }}>
          <Table size="small" sx={{ minWidth: 1260 }}>
            <TableHead>
              <TableRow>
                {['Release ID', 'Release Line ID', 'Package ID', 'Package Detail ID', 'Shipment ID', 'Qty', 'Status', 'Ship Via', 'Tracking Number', 'Sync'].map((label) => <TableCell key={label}>{label}</TableCell>)}
              </TableRow>
            </TableHead>
            <TableBody>
              {location.releases.map((release) => (
                <TableRow key={release.fulfillmentId} hover>
                  <TableCell sx={{ fontWeight: 900 }}>{release.releaseNumber}</TableCell>
                  <TableCell>{release.releaseLineId}</TableCell>
                  <TableCell>{release.packageId}</TableCell>
                  <TableCell>{release.packageDetailId}</TableCell>
                  <TableCell>{release.shipmentId}</TableCell>
                  <TableCell sx={{ fontWeight: 800 }}>{release.quantity}</TableCell>
                  <TableCell><Chip size="small" label={release.status} color={release.status === 'Cancelled' ? 'error' : release.status === 'In Transit' || release.status === 'Ready for Pickup' ? 'success' : 'info'} /></TableCell>
                  <TableCell>{release.shipVia}</TableCell>
                  <TableCell sx={{ fontWeight: 800 }}>{release.trackingNumber}</TableCell>
                  <TableCell>
                    <Button
                      className="sync-release-button"
                      size="small"
                      variant="contained"
                      startIcon={<SyncIcon />}
                      onClick={() => { setDetailsOpen(false); onSync(release); }}
                      sx={{ minWidth: 112, bgcolor: 'info.main', color: 'common.white', boxShadow: '0 5px 14px rgba(23,105,224,.2)', '&:hover': { bgcolor: 'info.dark' } }}
                    >
                      Sync Status
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Box>
        </DialogContent>
      </Dialog>
    </>
  );
}
