import { Box, Button, Chip, Stack, Table, TableBody, TableCell, TableHead, TableRow, Typography } from '@mui/material';
import PersonAddIcon from '@mui/icons-material/PersonAdd';
import EditIcon from '@mui/icons-material/Edit';
import BlockIcon from '@mui/icons-material/Block';
import AdminPanelSettingsIcon from '@mui/icons-material/AdminPanelSettings';
import GlassCard from '../components/GlassCard';
import PageHeader from '../components/PageHeader';
import { ApiErrorState, ApiLoading } from '../components/ApiFeedback';
import { useApiResource } from '../hooks/useApiResource';
import { omsApi } from '../services/omsApi';

export default function UserManagement() {
  const { data, error, reload } = useApiResource(omsApi.getUsers);

  if (!data) {
    return (
      <Box>
        <PageHeader title="User Management" subtitle="Manage OMS access, role assignments, permissions, and active status." badge="IAM" />
        {error ? <ApiErrorState message={error.message} onRetry={reload} /> : <ApiLoading rows={5} />}
      </Box>
    );
  }
  const users = data.items;

  return (
    <Box>
      <PageHeader title="User Management" subtitle="Manage OMS access, role assignments, permissions, and active status." badge="IAM" />
      <GlassCard sx={{ p: 2.5, mb: 2.5 }}>
        <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.5}>
          <Button startIcon={<PersonAddIcon />} variant="contained">Add User</Button>
          <Button startIcon={<EditIcon />} variant="outlined">Edit User</Button>
          <Button startIcon={<BlockIcon />} variant="outlined" color="error">Disable User</Button>
          <Button startIcon={<AdminPanelSettingsIcon />} variant="outlined">Role Assignment</Button>
        </Stack>
      </GlassCard>
      <GlassCard sx={{ p: 2, overflow: 'auto' }}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>User</TableCell>
              <TableCell>Role</TableCell>
              <TableCell>Permissions</TableCell>
              <TableCell>Active Status</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {users.map((user) => (
              <TableRow hover key={user.name}>
                <TableCell><Typography fontWeight={900}>{user.name}</Typography></TableCell>
                <TableCell>{user.role}</TableCell>
                <TableCell>{user.permissions}</TableCell>
                <TableCell><Chip size="small" label={user.status} color={user.status === 'Active' ? 'success' : 'default'} /></TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </GlassCard>
    </Box>
  );
}
