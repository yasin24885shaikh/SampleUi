import { createContext, useContext, useMemo, useState } from 'react';
import { ThemeProvider, alpha, createTheme } from '@mui/material/styles';
import type { PaletteMode } from '@mui/material';

type ThemeModeContextValue = {
  mode: PaletteMode;
  toggleMode: () => void;
};

const ThemeModeContext = createContext<ThemeModeContextValue | undefined>(undefined);

export function ThemeModeProvider({ children }: { children: React.ReactNode }) {
  const [mode, setMode] = useState<PaletteMode>('light');

  const theme = useMemo(
    () =>
      createTheme({
        palette: {
          mode,
          primary: { main: '#c91f27', dark: '#94151b', light: '#e34b51' },
          secondary: { main: '#536f78', dark: '#344b53', light: '#78939b' },
          success: { main: '#168a51' },
          warning: { main: '#b96b2d', dark: '#85461a', light: '#d99455' },
          info: { main: '#3e6f9c', dark: '#294d70', light: '#7098bb' },
          error: { main: '#c62828' },
          divider: mode === 'light' ? '#b8c0ca' : '#3c4552',
          background: {
            default: mode === 'light' ? '#e5e8ec' : '#101319',
            paper: mode === 'light' ? '#f5f7f9' : '#1a1f28'
          },
          text: {
            primary: mode === 'light' ? '#1c232d' : '#edf1f5',
            secondary: mode === 'light' ? '#59636f' : '#aeb7c4'
          }
        },
        typography: {
          fontFamily: '"Aptos", "SF Pro Text", "Segoe UI Variable Text", "Segoe UI", system-ui, sans-serif',
          fontSize: 14,
          h1: { fontFamily: '"Aptos Display", "SF Pro Display", "Segoe UI Variable Display", system-ui, sans-serif', fontWeight: 800, fontSize: '2.5rem', lineHeight: 1.12, letterSpacing: 0 },
          h2: { fontFamily: '"Aptos Display", "SF Pro Display", "Segoe UI Variable Display", system-ui, sans-serif', fontWeight: 800, fontSize: '2.125rem', lineHeight: 1.14, letterSpacing: 0 },
          h3: { fontFamily: '"Aptos Display", "SF Pro Display", "Segoe UI Variable Display", system-ui, sans-serif', fontWeight: 800, fontSize: '1.75rem', lineHeight: 1.18, letterSpacing: 0 },
          h4: { fontFamily: '"Aptos Display", "SF Pro Display", "Segoe UI Variable Display", system-ui, sans-serif', fontWeight: 800, fontSize: '2rem', lineHeight: 1.16, letterSpacing: 0 },
          h5: { fontFamily: '"Aptos Display", "SF Pro Display", "Segoe UI Variable Display", system-ui, sans-serif', fontWeight: 800, fontSize: '1.3rem', lineHeight: 1.24, letterSpacing: 0 },
          h6: { fontFamily: '"Aptos Display", "SF Pro Display", "Segoe UI Variable Display", system-ui, sans-serif', fontWeight: 800, fontSize: '1.05rem', lineHeight: 1.3, letterSpacing: 0 },
          subtitle1: { fontWeight: 750, fontSize: '0.95rem', lineHeight: 1.4, letterSpacing: 0 },
          subtitle2: { fontWeight: 750, fontSize: '0.84rem', lineHeight: 1.4, letterSpacing: 0 },
          body1: { fontSize: '0.875rem', lineHeight: 1.55, letterSpacing: 0 },
          body2: { fontSize: '0.8125rem', lineHeight: 1.5, letterSpacing: 0 },
          caption: { fontSize: '0.72rem', fontWeight: 600, lineHeight: 1.35, letterSpacing: 0 },
          overline: { fontSize: '0.69rem', fontWeight: 800, lineHeight: 1.45, letterSpacing: 0 },
          button: { textTransform: 'none', fontSize: '0.8125rem', fontWeight: 750, lineHeight: 1.4, letterSpacing: 0 }
        },
        shape: { borderRadius: 8 },
        components: {
          MuiCssBaseline: {
            styleOverrides: {
              body: {
                backgroundColor: mode === 'light' ? '#e5e8ec' : '#101319',
                backgroundImage: mode === 'light'
                  ? 'linear-gradient(135deg, rgba(255,255,255,.55) 0%, rgba(209,214,221,.34) 44%, rgba(244,246,248,.62) 100%)'
                  : 'linear-gradient(135deg, rgba(31,37,47,.72) 0%, rgba(12,15,20,.9) 48%, rgba(28,33,42,.72) 100%)',
                backgroundAttachment: 'fixed'
              }
            }
          },
          MuiPaper: {
            styleOverrides: {
              root: {
                backgroundImage: mode === 'light'
                  ? 'linear-gradient(145deg, rgba(255,255,255,.96), rgba(236,239,243,.96))'
                  : 'linear-gradient(145deg, rgba(31,37,47,.98), rgba(20,24,31,.98))'
              }
            }
          },
          MuiButton: {
            styleOverrides: {
              root: {
                borderRadius: 8,
                boxShadow: 'none',
                transition: 'transform 160ms ease, box-shadow 160ms ease, background 160ms ease'
              },
              containedPrimary: {
                color: '#fff',
                background: 'linear-gradient(180deg, #dd353c 0%, #b9161d 52%, #961218 100%)',
                border: '1px solid rgba(116,10,15,.58)',
                boxShadow: 'inset 0 1px 0 rgba(255,255,255,.28), 0 5px 12px rgba(148,21,27,.2)',
                '&:hover': {
                  background: 'linear-gradient(180deg, #e3444a 0%, #c51b22 52%, #a1141a 100%)',
                  boxShadow: 'inset 0 1px 0 rgba(255,255,255,.32), 0 7px 16px rgba(148,21,27,.28)'
                }
              },
              outlined: ({ theme }) => ({
                borderColor: alpha(theme.palette.text.primary, 0.24),
                background: theme.palette.mode === 'light'
                  ? 'linear-gradient(180deg, rgba(255,255,255,.88), rgba(226,230,235,.72))'
                  : 'linear-gradient(180deg, rgba(52,60,72,.72), rgba(31,36,45,.72))',
                boxShadow: 'inset 0 1px 0 rgba(255,255,255,.18)'
              })
            }
          },
          MuiOutlinedInput: {
            styleOverrides: {
              root: ({ theme }) => ({
                background: theme.palette.mode === 'light'
                  ? 'linear-gradient(180deg, rgba(255,255,255,.96), rgba(237,240,243,.9))'
                  : 'linear-gradient(180deg, rgba(40,47,58,.9), rgba(25,30,38,.92))',
                boxShadow: theme.palette.mode === 'light'
                  ? 'inset 0 1px 1px rgba(255,255,255,.9), 0 1px 2px rgba(42,50,60,.07)'
                  : 'inset 0 1px 0 rgba(255,255,255,.05)',
                '& .MuiOutlinedInput-notchedOutline': {
                  borderColor: alpha(theme.palette.text.primary, 0.22)
                },
                '&:hover .MuiOutlinedInput-notchedOutline': {
                  borderColor: alpha(theme.palette.text.primary, 0.38)
                }
              })
            }
          },
          MuiInputBase: {
            styleOverrides: {
              root: {
                fontSize: '0.875rem',
                fontFeatureSettings: '"tnum" 1, "ss01" 1'
              }
            }
          },
          MuiInputLabel: {
            styleOverrides: {
              root: {
                fontSize: '0.8125rem',
                fontWeight: 650,
                letterSpacing: 0
              }
            }
          },
          MuiChip: {
            styleOverrides: {
              label: {
                fontSize: '0.75rem',
                fontWeight: 750,
                letterSpacing: 0
              }
            }
          },
          MuiTableCell: {
            styleOverrides: {
              root: {
                fontSize: '0.8125rem',
                lineHeight: 1.45,
                fontFeatureSettings: '"tnum" 1'
              },
              head: {
                fontSize: '0.72rem',
                fontWeight: 800,
                letterSpacing: 0,
                background: mode === 'light'
                  ? 'linear-gradient(180deg, #f7f8fa 0%, #dfe3e8 100%)'
                  : 'linear-gradient(180deg, #303744 0%, #222832 100%)',
                borderBottom: `1px solid ${mode === 'light' ? '#aeb6c0' : '#46505e'}`,
                boxShadow: 'inset 0 1px 0 rgba(255,255,255,.28)'
              }
            }
          },
          MuiMenuItem: {
            styleOverrides: {
              root: {
                fontSize: '0.84rem',
                fontWeight: 550
              }
            }
          },
          MuiCard: {
            styleOverrides: {
              root: ({ theme }) => ({
                border: `1px solid ${alpha(theme.palette.text.primary, theme.palette.mode === 'light' ? 0.2 : 0.28)}`,
                boxShadow:
                  theme.palette.mode === 'light'
                    ? 'inset 0 1px 0 rgba(255,255,255,.9), 0 12px 28px rgba(48, 56, 66, 0.11), 0 2px 5px rgba(48,56,66,.08)'
                    : 'inset 0 1px 0 rgba(255,255,255,.06), 0 16px 38px rgba(0, 0, 0, 0.38)'
              })
            }
          }
        }
      }),
    [mode]
  );

  const value = useMemo(
    () => ({
      mode,
      toggleMode: () => setMode((current) => (current === 'light' ? 'dark' : 'light'))
    }),
    [mode]
  );

  return (
    <ThemeModeContext.Provider value={value}>
      <ThemeProvider theme={theme}>{children}</ThemeProvider>
    </ThemeModeContext.Provider>
  );
}

export function useThemeMode() {
  const context = useContext(ThemeModeContext);
  if (!context) {
    throw new Error('useThemeMode must be used within ThemeModeProvider');
  }
  return context;
}
