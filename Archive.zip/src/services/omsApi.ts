import { apiClient, apiConfiguration, type QueryValue } from './apiClient';
import {
  activities, alerts, bannerPerformance, dailyOrderVolume, dashboardKpis, exceptionTrend,
  fulfillmentMix, inventoryRows, inventoryTrend, nodePerformance, orders, ordersByStatus,
  productCatalog, returnTrend, serviceLevelTrend, users, type Order
} from './mockData';

export type InventoryItem = (typeof inventoryRows)[number];
export type Product = (typeof productCatalog)[number];
export type OmsUser = (typeof users)[number];

export type CollectionResponse<T> = { items: T[]; total: number; page: number; pageSize: number };
export type DashboardResponse = {
  kpis: typeof dashboardKpis;
  ordersByStatus: typeof ordersByStatus;
  fulfillmentMix: typeof fulfillmentMix;
  inventoryTrend: typeof inventoryTrend;
  dailyOrderVolume: typeof dailyOrderVolume;
  serviceLevelTrend: typeof serviceLevelTrend;
  exceptionTrend: typeof exceptionTrend;
  bannerPerformance: typeof bannerPerformance;
  nodePerformance: typeof nodePerformance;
  returnTrend: typeof returnTrend;
  activities: typeof activities;
  alerts: typeof alerts;
  refreshedAt: string;
};
export type InventoryResponse = CollectionResponse<InventoryItem> & { trend: typeof inventoryTrend };
export type SkuDocumentationResponse = { product: Product; sections: Array<{ title: string; lines: string[] }> };
export type Notification = { id: string; category: string; severity: string; title: string; message: string; time: string };
export type NotificationResponse = { items: Notification[]; total: number };
export type OrderQuery = {
  page?: number;
  pageSize?: number;
  orderNumbers?: string[];
  sku?: string;
  statuses?: string[];
  orderDateFrom?: string;
  orderDateTo?: string;
  fulfillmentType?: string;
  banner?: string;
  search?: string;
};

const dashboardMock: DashboardResponse = {
  kpis: dashboardKpis, ordersByStatus, fulfillmentMix, inventoryTrend, dailyOrderVolume,
  serviceLevelTrend, exceptionTrend, bannerPerformance, nodePerformance, returnTrend,
  activities, alerts, refreshedAt: '2026-06-24T10:42:00-05:00'
};

const notificationsMock: Notification[] = [
  { id: 'inventory', category: 'Inventory', severity: 'Critical', title: 'Inventory threshold breached', message: 'BB550VTA is unavailable at PHX-DC-02 and 18 orders are at allocation risk.', time: '4 min ago' },
  { id: 'release', category: 'Release', severity: 'Action', title: 'Warehouse release exception', message: 'REL-900211 has remained in Awaiting Inventory beyond the fulfillment SLA.', time: '12 min ago' },
  { id: 'supplier', category: 'Integration', severity: 'Warning', title: 'Supplier ASN feed delayed', message: 'ADI-US acknowledgements are running 22 minutes behind the expected cadence.', time: '28 min ago' },
  { id: 'payment', category: 'Payment', severity: 'Review', title: 'Payment authorization review', message: 'Six high-value launch orders require renewed authorization before release.', time: '41 min ago' },
  { id: 'return', category: 'Return', severity: 'Update', title: 'Return backlog improving', message: 'Open return inspections declined 14% after the latest processing cycle.', time: '1 hr ago' },
  { id: 'sync', category: 'Integration', severity: 'Resolved', title: 'Store inventory sync complete', message: 'Inventory positions were refreshed successfully across 1,284 stores.', time: '2 hr ago' },
  { id: 'carrier', category: 'Shipment', severity: 'Advisory', title: 'Carrier weather advisory', message: 'UPS Ground shipments from the Midwest may experience a one-day delay.', time: '3 hr ago' }
];

const skuDocumentationMock: SkuDocumentationResponse = {
  product: productCatalog[0],
  sections: [
    { title: 'SKU Details', lines: ['Category: Running', 'Colorway: White / Metallic Silver', 'Size Curve: Men 7-14', 'Lifecycle: Active'] },
    { title: 'Vendor Information', lines: ['Vendor: Nike', 'Vendor SKU: FV5029-141', 'Country of Origin: Vietnam', 'Compliance: Approved'] },
    { title: 'Packaging Details', lines: ['Box Type: Standard footwear', 'Each Weight: 2.4 lb', 'Case Pack: 12', 'Hazmat: No'] },
    { title: 'Shipping Constraints', lines: ['Ship Methods: Ground, 2-Day, Pickup', 'Launch Hold: No', 'Store Eligible: Yes', 'Supplier Direct: Eligible'] }
  ]
};

function mockResponse<T>(payload: T, signal?: AbortSignal, delay = 320): Promise<T> {
  return new Promise((resolve, reject) => {
    const timeoutId = window.setTimeout(() => resolve(payload), delay);
    signal?.addEventListener('abort', () => {
      window.clearTimeout(timeoutId);
      reject(new DOMException('Request aborted', 'AbortError'));
    }, { once: true });
  });
}

function collection<T>(items: T[], page = 1, pageSize = items.length): CollectionResponse<T> {
  return { items, total: items.length, page, pageSize };
}

function queryFromOrderSearch(query: OrderQuery): Record<string, QueryValue | QueryValue[]> {
  return {
    page: query.page, pageSize: query.pageSize, orderNumber: query.orderNumbers, sku: query.sku,
    status: query.statuses, orderDateFrom: query.orderDateFrom, orderDateTo: query.orderDateTo,
    fulfillmentType: query.fulfillmentType, banner: query.banner, search: query.search
  };
}

export const omsApi = {
  getDashboard: (signal?: AbortSignal) => apiConfiguration.useMockApi
    ? mockResponse(dashboardMock, signal) : apiClient.get<DashboardResponse>('/dashboard', { signal }),
  getOrders: (signal?: AbortSignal, query: OrderQuery = {}) => apiConfiguration.useMockApi
    ? mockResponse(collection(orders, query.page, query.pageSize), signal)
    : apiClient.get<CollectionResponse<Order>>('/orders', { signal, query: queryFromOrderSearch(query) }),
  getInventory: (signal?: AbortSignal) => apiConfiguration.useMockApi
    ? mockResponse({ ...collection(inventoryRows), trend: inventoryTrend }, signal)
    : apiClient.get<InventoryResponse>('/inventory', { signal }),
  getProducts: (signal?: AbortSignal) => apiConfiguration.useMockApi
    ? mockResponse(collection(productCatalog), signal)
    : apiClient.get<CollectionResponse<Product>>('/products', { signal }),
  getSkuDocumentation: (sku: string, signal?: AbortSignal) => apiConfiguration.useMockApi
    ? mockResponse(skuDocumentationMock, signal)
    : apiClient.get<SkuDocumentationResponse>(`/products/${encodeURIComponent(sku)}/documentation`, { signal }),
  getUsers: (signal?: AbortSignal) => apiConfiguration.useMockApi
    ? mockResponse(collection(users), signal)
    : apiClient.get<CollectionResponse<OmsUser>>('/users', { signal }),
  getNotifications: (signal?: AbortSignal) => apiConfiguration.useMockApi
    ? mockResponse({ items: notificationsMock, total: notificationsMock.length }, signal)
    : apiClient.get<NotificationResponse>('/notifications', { signal }),
  rereleaseToFulfillmentNode: (releaseId: string) => apiConfiguration.useMockApi
    ? mockResponse({ releaseId, status: 'Fulfillment node re-release requested' })
    : apiClient.post<{ releaseId: string; status: string }>(`/releases/${encodeURIComponent(releaseId)}/rerelease`),
  rerouteRelease: (releaseId: string, createDeliveryNote: boolean) => apiConfiguration.useMockApi
    ? mockResponse({ releaseId, status: 'Reroute requested', createDeliveryNote })
    : apiClient.post<{ releaseId: string; status: string; createDeliveryNote: boolean }>(`/releases/${encodeURIComponent(releaseId)}/reroute`, { createDeliveryNote }),
  hardCancelRelease: (releaseId: string) => apiConfiguration.useMockApi
    ? mockResponse({ releaseId, status: 'Hard cancellation requested' })
    : apiClient.post<{ releaseId: string; status: string }>(`/releases/${encodeURIComponent(releaseId)}/hard-cancel`),
  syncFulfillment: (fulfillmentId: string) => apiConfiguration.useMockApi
    ? mockResponse({ fulfillmentId, status: 'Synchronization requested' })
    : apiClient.post<{ fulfillmentId: string; status: string }>(`/fulfillments/${encodeURIComponent(fulfillmentId)}/sync`)
};
