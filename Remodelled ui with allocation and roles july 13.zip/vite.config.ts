import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, '.', '');
  const omsTarget = env.VITE_OMS_API_TARGET || 'http://localhost:8080';
  const userTarget = env.VITE_USER_API_TARGET || 'http://localhost:8081';
  const aiTarget = env.VITE_AI_API_TARGET || 'http://localhost:8090';

  return {
    plugins: [react()],
    server: {
      port: 5173,
      proxy: {
        '/api/oms': {
          target: omsTarget,
          changeOrigin: true,
          secure: false,
          rewrite: (path) => path.replace(/^\/api\/oms/, '/api')
        },
        '/api/users': {
          target: userTarget,
          changeOrigin: true,
          secure: false,
          rewrite: (path) => path.replace(/^\/api\/users/, '/api')
        },
        '/api/ai': {
          target: aiTarget,
          changeOrigin: true,
          secure: false,
          rewrite: (path) => path.replace(/^\/api\/ai/, '/api')
        },
        '/api': {
          target: omsTarget,
          changeOrigin: true,
          secure: false
        }
      }
    }
  };
});
