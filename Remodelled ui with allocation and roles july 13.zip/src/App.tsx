import { Navigate, Route, Routes, useLocation } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import MainLayout from './layouts/MainLayout';
import Dashboard from './pages/Dashboard';
import OrderTracking from './pages/OrderTracking';
import OrderStatusAnalytics from './pages/OrderStatusAnalytics';
import OrderAiTrace from './pages/OrderAiTrace';
import AllocationOrderTrace from './pages/AllocationOrderTrace';
import InventoryManagement from './pages/InventoryManagement';
import SkuDocumentation from './pages/SkuDocumentation';
import CommonProducts from './pages/CommonProducts';
import UserManagement from './pages/UserManagement';
import CustomUtilities from './pages/CustomUtilities';
import Settings from './pages/Settings';

const pageMotion = {
  initial: { opacity: 0, y: 14 },
  animate: { opacity: 1, y: 0 },
  exit: { opacity: 0, y: -10 },
  transition: { duration: 0.28 }
};

export default function App() {
  const location = useLocation();

  return (
    <MainLayout>
      <AnimatePresence mode="wait">
        <motion.div key={location.pathname} {...pageMotion}>
          <Routes location={location}>
            <Route path="/" element={<Navigate to="/dashboard" replace />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/order-tracking" element={<OrderTracking />} />
            <Route path="/order-status-analytics" element={<OrderStatusAnalytics />} />
            <Route path="/order-ai-trace" element={<OrderAiTrace />} />
            <Route path="/allocation-order-trace" element={<AllocationOrderTrace />} />
            <Route path="/inventory" element={<InventoryManagement />} />
            <Route path="/skudoc" element={<SkuDocumentation />} />
            <Route path="/common-products" element={<CommonProducts />} />
            <Route path="/users" element={<UserManagement />} />
            <Route path="/custom-utilities" element={<CustomUtilities />} />
            <Route path="/settings" element={<Settings />} />
          </Routes>
        </motion.div>
      </AnimatePresence>
    </MainLayout>
  );
}
