import { useMemo, useState } from 'react';
import {
  Alert,
  Box,
  Button,
  Chip,
  Dialog,
  DialogContent,
  InputAdornment,
  LinearProgress,
  Pagination,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  TableSortLabel,
  TextField,
  Typography
} from '@mui/material';
import Grid from '@mui/material/GridLegacy';
import { alpha } from '@mui/material/styles';
import AccountTreeIcon from '@mui/icons-material/AccountTree';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import ErrorOutlineIcon from '@mui/icons-material/ErrorOutline';
import SearchIcon from '@mui/icons-material/Search';
import SyncIcon from '@mui/icons-material/Sync';
import WarehouseIcon from '@mui/icons-material/Warehouse';
import GlassCard from '../components/GlassCard';
import PageHeader from '../components/PageHeader';

type SummaryRow = {
  node: string;
  allocationOrders: number;
  allocationQty: number;
  maoOrders: number;
  maoQty: number;
  maoCancelledOrders: number;
  maoCancelledQty: number;
  whseOrders: number;
  whseQty: number;
};

type MismatchRow = {
  soOrder: string;
  store: string;
  fulfillmentWhse: string;
  allocationStatus: string;
  allocationQty: number;
  maoStatus: string;
  maoQty: number;
  whseStatus: string;
  whseQty: number;
  variance: number;
  mismatch: string;
  lastEvent: string;
};

const summaryRows: SummaryRow[] = [
  { node: 'JC', allocationOrders: 2934, allocationQty: 3762, maoOrders: 2921, maoQty: 3744, maoCancelledOrders: 9, maoCancelledQty: 12, whseOrders: 2908, whseQty: 3725 },
  { node: 'Camp Hill', allocationOrders: 2418, allocationQty: 3015, maoOrders: 2406, maoQty: 2998, maoCancelledOrders: 5, maoCancelledQty: 7, whseOrders: 2399, whseQty: 2986 },
  { node: 'Reno', allocationOrders: 2187, allocationQty: 2741, maoOrders: 2179, maoQty: 2729, maoCancelledOrders: 7, maoCancelledQty: 9, whseOrders: 2168, whseQty: 2711 },
  { node: 'Milton', allocationOrders: 1964, allocationQty: 2488, maoOrders: 1952, maoQty: 2472, maoCancelledOrders: 5, maoCancelledQty: 6, whseOrders: 1944, whseQty: 2457 }
];

const mismatchRows: MismatchRow[] = [
  { soOrder: 'SO-61820471', store: 'Store 1093', fulfillmentWhse: 'JC', allocationStatus: 'Submitted', allocationQty: 2, maoStatus: 'Created', maoQty: 2, whseStatus: 'Received', whseQty: 1, variance: 1, mismatch: 'Warehouse quantity short', lastEvent: '2026-07-12 14:22 CT' },
  { soOrder: 'SO-61820508', store: 'Store 1842', fulfillmentWhse: 'JC', allocationStatus: 'Submitted', allocationQty: 3, maoStatus: 'Created', maoQty: 2, whseStatus: 'Received', whseQty: 2, variance: 1, mismatch: 'MAO store SO quantity mismatch', lastEvent: '2026-07-12 13:58 CT' },
  { soOrder: 'SO-61820641', store: 'Store 4501', fulfillmentWhse: 'Camp Hill', allocationStatus: 'Submitted', allocationQty: 1, maoStatus: 'Missing', maoQty: 0, whseStatus: 'Not received', whseQty: 0, variance: 1, mismatch: 'Store SO not created in MAO', lastEvent: '2026-07-12 13:41 CT' },
  { soOrder: 'SO-61820713', store: 'Store 2031', fulfillmentWhse: 'Reno', allocationStatus: 'Submitted', allocationQty: 4, maoStatus: 'Created', maoQty: 4, whseStatus: 'Not received', whseQty: 0, variance: 4, mismatch: 'Warehouse ingestion missing', lastEvent: '2026-07-12 12:55 CT' },
  { soOrder: 'SO-61820789', store: 'Store 1178', fulfillmentWhse: 'Milton', allocationStatus: 'Submitted', allocationQty: 2, maoStatus: 'Created', maoQty: 3, whseStatus: 'Received', whseQty: 3, variance: -1, mismatch: 'MAO quantity exceeds allocation', lastEvent: '2026-07-12 12:31 CT' },
  { soOrder: 'SO-61820802', store: 'Store 2044', fulfillmentWhse: 'Camp Hill', allocationStatus: 'Submitted', allocationQty: 1, maoStatus: 'Created', maoQty: 1, whseStatus: 'Pending', whseQty: 0, variance: 1, mismatch: 'Warehouse acknowledgement pending', lastEvent: '2026-07-12 11:47 CT' },
  { soOrder: 'SO-61820917', store: 'Store 1266', fulfillmentWhse: 'Camp Hill', allocationStatus: 'Submitted', allocationQty: 5, maoStatus: 'Created', maoQty: 5, whseStatus: 'Received', whseQty: 4, variance: 1, mismatch: 'Warehouse quantity short', lastEvent: '2026-07-12 09:52 CT' },
  { soOrder: 'SO-61821003', store: 'Store 4170', fulfillmentWhse: 'Reno', allocationStatus: 'Submitted', allocationQty: 2, maoStatus: 'Created', maoQty: 2, whseStatus: 'Rejected', whseQty: 0, variance: 2, mismatch: 'Warehouse payload rejected', lastEvent: '2026-07-12 09:18 CT' }
];

type SortKey = keyof MismatchRow;

const number = new Intl.NumberFormat('en-US');

export default function AllocationOrderTrace() {
  const [fromDate, setFromDate] = useState('2026-07-12');
  const [toDate, setToDate] = useState('2026-07-13');
  const [submittedRange, setSubmittedRange] = useState<{ from: string; to: string } | null>(null);
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [globalSearch, setGlobalSearch] = useState('');
  const [columnSearch, setColumnSearch] = useState<Record<string, string>>({});
  const [sortKey, setSortKey] = useState<SortKey>('lastEvent');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
  const [page, setPage] = useState(1);
  const pageSize = 15;
  const inclusiveRangeDays = fromDate && toDate
    ? Math.floor((Date.parse(`${toDate}T00:00:00Z`) - Date.parse(`${fromDate}T00:00:00Z`)) / 86_400_000) + 1
    : 0;
  const dateError = fromDate && toDate
    ? fromDate > toDate
      ? 'From date must be before or equal to the to date.'
      : inclusiveRangeDays > 2
        ? 'Date range cannot exceed 2 calendar days. Select a shorter range.'
        : ''
    : '';

  const totals = useMemo(() => summaryRows.reduce((total, row) => ({
    allocationOrders: total.allocationOrders + row.allocationOrders,
    allocationQty: total.allocationQty + row.allocationQty,
    maoOrders: total.maoOrders + row.maoOrders,
    maoQty: total.maoQty + row.maoQty,
    maoCancelledOrders: total.maoCancelledOrders + row.maoCancelledOrders,
    maoCancelledQty: total.maoCancelledQty + row.maoCancelledQty,
    whseOrders: total.whseOrders + row.whseOrders,
    whseQty: total.whseQty + row.whseQty
  }), { allocationOrders: 0, allocationQty: 0, maoOrders: 0, maoQty: 0, maoCancelledOrders: 0, maoCancelledQty: 0, whseOrders: 0, whseQty: 0 }), []);

  const filteredMismatches = useMemo(() => {
    const global = globalSearch.trim().toLowerCase();
    return mismatchRows
      .filter((row) => {
        const record = Object.values(row).join(' ').toLowerCase();
        if (global && !record.includes(global)) return false;
        return Object.entries(columnSearch).every(([key, value]) => !value.trim() || String(row[key as SortKey]).toLowerCase().includes(value.trim().toLowerCase()));
      })
      .sort((a, b) => {
        const left = a[sortKey];
        const right = b[sortKey];
        const comparison = typeof left === 'number' && typeof right === 'number' ? left - right : String(left).localeCompare(String(right));
        return sortDirection === 'asc' ? comparison : -comparison;
      });
  }, [columnSearch, globalSearch, sortDirection, sortKey]);
  const pageCount = Math.max(1, Math.ceil(filteredMismatches.length / pageSize));
  const safePage = Math.min(page, pageCount);
  const paginatedMismatches = filteredMismatches.slice((safePage - 1) * pageSize, safePage * pageSize);

  const submitTrace = () => {
    if (!fromDate || !toDate || dateError) return;
    setLoading(true);
    setProgress(10);
    const timer = window.setInterval(() => setProgress((current) => Math.min(current + 16, 92)), 170);
    window.setTimeout(() => {
      window.clearInterval(timer);
      setProgress(100);
      setSubmittedRange({ from: fromDate, to: toDate });
      window.setTimeout(() => {
        setLoading(false);
        setProgress(0);
      }, 320);
    }, 1250);
  };

  const changeSort = (key: SortKey) => {
    setPage(1);
    if (sortKey === key) setSortDirection((current) => current === 'asc' ? 'desc' : 'asc');
    else {
      setSortKey(key);
      setSortDirection('asc');
    }
  };

  return (
    <Box>
      <PageHeader title="Allocation Order Trace" subtitle="Trace allocation orders created for destination stores and fulfilled from JC, Camp Hill, Reno, or Milton warehouses." badge="STORE ALLOCATION" />

      <GlassCard sx={{ p: { xs: 1.5, md: 2 }, mb: 2 }}>
        <Stack direction={{ xs: 'column', md: 'row' }} spacing={1.25} alignItems={{ xs: 'stretch', md: 'center' }}>
          <TextField size="small" type="date" label="From date" value={fromDate} onChange={(event) => setFromDate(event.target.value)} InputLabelProps={{ shrink: true }} inputProps={{ max: toDate }} sx={{ minWidth: 190 }} />
          <TextField size="small" type="date" label="To date" value={toDate} onChange={(event) => setToDate(event.target.value)} InputLabelProps={{ shrink: true }} inputProps={{ min: fromDate }} sx={{ minWidth: 190 }} />
          <Button variant="contained" startIcon={<AccountTreeIcon />} onClick={submitTrace} disabled={!fromDate || !toDate || Boolean(dateError)} sx={{ minHeight: 40, px: 2.5 }}>Run Allocation Trace</Button>
          <Typography variant="caption" color="text.secondary" sx={{ ml: { md: 'auto !important' } }}>Dates use Central Time · Maximum range: 2 calendar days</Typography>
        </Stack>
        {dateError && <Alert severity="error" sx={{ mt: 1.25 }}>{dateError}</Alert>}
      </GlassCard>

      {!submittedRange && (
        <GlassCard sx={{ p: 3, textAlign: 'center' }}>
          <CalendarMonthIcon color="primary" sx={{ fontSize: 42 }} />
          <Typography variant="h6" fontWeight={950} sx={{ mt: 1 }}>Select a date range to begin</Typography>
          <Typography color="text.secondary">The trace compares store SO order counts and quantities across Allocation, MAO, and the fulfilling warehouse.</Typography>
        </GlassCard>
      )}

      {submittedRange && (
        <Stack spacing={2}>
          <GlassCard sx={{ overflow: 'hidden' }}>
            <SectionHeader number="01" title="Reconciliation Summary" subtitle={`${submittedRange.from} through ${submittedRange.to} · Store allocations grouped by fulfilling warehouse`} />
            <Box sx={{ p: { xs: 1.4, md: 2 } }}>
              <Grid container spacing={1.25} sx={{ mb: 1.75 }}>
                <SummaryKpi label="Store allocations submitted" orders={totals.allocationOrders} quantity={totals.allocationQty} tone="primary" />
                <SummaryKpi label="MAO store SO created" orders={totals.maoOrders} quantity={totals.maoQty} tone="success" />
                <SummaryKpi label="Cancelled in MAO" orders={totals.maoCancelledOrders} quantity={totals.maoCancelledQty} tone="warning" />
                <SummaryKpi label="WHSE fulfillment received" orders={totals.whseOrders} quantity={totals.whseQty} tone="info" />
                <SummaryKpi label="Actual mismatches" orders={mismatchRows.length} quantity={mismatchRows.reduce((sum, row) => sum + Math.abs(row.variance), 0)} tone="error" mismatch />
              </Grid>
              <Alert severity="info" sx={{ mb: 1.5 }}>
                MAO-cancelled store SOs are intentionally stopped before warehouse release. They remain visible in the summary but are excluded from the actionable warehouse mismatch count.
              </Alert>
              <Box sx={{ overflowX: 'auto', border: 1, borderColor: 'divider', borderRadius: 1.75 }}>
                <Table size="small" sx={{ minWidth: 960 }}>
                  <TableHead>
                    <TableRow>
                      <TableCell rowSpan={2}>Fulfilling warehouse</TableCell>
                      <TableCell colSpan={2} align="center">Allocation → Store</TableCell>
                      <TableCell colSpan={2} align="center">MAO Store SO</TableCell>
                      <TableCell colSpan={2} align="center">Cancelled in MAO</TableCell>
                      <TableCell colSpan={2} align="center">WHSE fulfillment</TableCell>
                      <TableCell rowSpan={2} align="right">Actionable gap</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell align="right">SO orders</TableCell><TableCell align="right">Quantity</TableCell>
                      <TableCell align="right">SO orders</TableCell><TableCell align="right">Quantity</TableCell>
                      <TableCell align="right">SO orders</TableCell><TableCell align="right">Quantity</TableCell>
                      <TableCell align="right">SO orders</TableCell><TableCell align="right">Quantity</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {summaryRows.map((row) => (
                      <TableRow key={row.node} hover>
                        <TableCell><Stack direction="row" spacing={1} alignItems="center"><WarehouseIcon color="action" fontSize="small" /><Typography fontWeight={900}>{row.node}</Typography></Stack></TableCell>
                        <TableCell align="right">{number.format(row.allocationOrders)}</TableCell><TableCell align="right">{number.format(row.allocationQty)}</TableCell>
                        <TableCell align="right">{number.format(row.maoOrders)}</TableCell><TableCell align="right">{number.format(row.maoQty)}</TableCell>
                        <TableCell align="right"><Chip size="small" color="warning" variant="outlined" label={number.format(row.maoCancelledOrders)} /></TableCell><TableCell align="right">{number.format(row.maoCancelledQty)}</TableCell>
                        <TableCell align="right">{number.format(row.whseOrders)}</TableCell><TableCell align="right">{number.format(row.whseQty)}</TableCell>
                        <TableCell align="right"><Chip size="small" color="error" variant="outlined" label={`-${number.format(Math.max(row.maoOrders - row.maoCancelledOrders - row.whseOrders, 0))}`} /></TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </Box>
            </Box>
          </GlassCard>

          <GlassCard sx={{ overflow: 'hidden' }}>
            <SectionHeader number="02" title="Actual Mismatches" subtitle="Store SO-level exceptions with Allocation, MAO, and fulfilling-warehouse details side by side" />
            <Box sx={{ p: { xs: 1.4, md: 2 } }}>
              <Alert severity="info" icon={<SyncIcon />} sx={{ mb: 1.5 }}>
                <Typography fontWeight={900}>How actual mismatches are fetched</Typography>
                <Typography variant="body2">The trace joins each store allocation to its MAO SO by SO order number, identifies the assigned fulfillment warehouse, and compares that warehouse's acknowledgement and quantity. Only missing records or unequal quantities appear below.</Typography>
              </Alert>
              <Stack direction={{ xs: 'column', md: 'row' }} spacing={1.2} alignItems={{ xs: 'stretch', md: 'center' }} justifyContent="space-between" sx={{ mb: 1.25 }}>
                <TextField size="small" label="Global search" placeholder="Search any mismatch detail" value={globalSearch} onChange={(event) => { setGlobalSearch(event.target.value); setPage(1); }} sx={{ minWidth: { md: 360 } }} InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment> }} />
                <Stack direction="row" spacing={1} alignItems="center"><Chip color="error" label={`${filteredMismatches.length} mismatches`} /><Typography variant="caption" color="text.secondary">Click any column heading to sort</Typography></Stack>
              </Stack>
              <Box sx={{ overflowX: 'auto', border: 1, borderColor: 'divider', borderRadius: 1.75 }}>
                <Table size="small" sx={{ minWidth: 1540 }}>
                  <TableHead>
                    <TableRow>
                      <SortableHead label="SO order" field="soOrder" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="Destination store" field="store" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="Fulfilling WHSE" field="fulfillmentWhse" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="Allocation status" field="allocationStatus" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="Alloc qty" field="allocationQty" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="MAO status" field="maoStatus" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="MAO qty" field="maoQty" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="WHSE / Store status" field="whseStatus" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="Node qty" field="whseQty" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="Variance" field="variance" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="Mismatch reason" field="mismatch" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="Last event" field="lastEvent" active={sortKey} direction={sortDirection} onSort={changeSort} />
                    </TableRow>
                    <TableRow>
                      {(['soOrder', 'store', 'fulfillmentWhse', 'allocationStatus', 'allocationQty', 'maoStatus', 'maoQty', 'whseStatus', 'whseQty', 'variance', 'mismatch', 'lastEvent'] as SortKey[]).map((field) => (
                        <TableCell key={field} sx={{ py: 0.7 }}><TextField variant="standard" size="small" placeholder="Filter" value={columnSearch[field] ?? ''} onChange={(event) => { setColumnSearch((current) => ({ ...current, [field]: event.target.value })); setPage(1); }} InputProps={{ disableUnderline: true }} sx={{ minWidth: field === 'mismatch' ? 170 : 90, '& input': { fontSize: '.75rem', py: 0.4 } }} /></TableCell>
                      ))}
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {paginatedMismatches.map((row) => (
                      <TableRow key={row.soOrder} hover>
                        <TableCell><Typography fontWeight={950} color="primary.main">{row.soOrder}</Typography></TableCell>
                        <TableCell><Typography fontWeight={850}>{row.store}</Typography></TableCell>
                        <TableCell><Stack direction="row" spacing={0.7} alignItems="center"><WarehouseIcon fontSize="small" color="action" /><Typography fontWeight={850}>{row.fulfillmentWhse}</Typography></Stack></TableCell>
                        <TableCell><Status value={row.allocationStatus} /></TableCell><TableCell align="right">{row.allocationQty}</TableCell>
                        <TableCell><Status value={row.maoStatus} /></TableCell><TableCell align="right">{row.maoQty}</TableCell>
                        <TableCell><Status value={row.whseStatus} /></TableCell><TableCell align="right">{row.whseQty}</TableCell>
                        <TableCell align="right"><Chip size="small" color="error" label={row.variance > 0 ? `+${row.variance}` : row.variance} /></TableCell>
                        <TableCell><Stack direction="row" spacing={0.7} alignItems="center"><ErrorOutlineIcon color="error" fontSize="small" /><Typography variant="body2" fontWeight={800}>{row.mismatch}</Typography></Stack></TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.lastEvent}</TableCell>
                      </TableRow>
                    ))}
                    {!filteredMismatches.length && <TableRow><TableCell colSpan={12}><Alert severity="success">No mismatches match the current search and column filters.</Alert></TableCell></TableRow>}
                  </TableBody>
                </Table>
              </Box>
              {filteredMismatches.length > 0 && (
                <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1} justifyContent="space-between" alignItems="center" sx={{ mt: 1.4 }}>
                  <Typography variant="body2" color="text.secondary">
                    Showing {number.format((safePage - 1) * pageSize + 1)}–{number.format(Math.min(safePage * pageSize, filteredMismatches.length))} of {number.format(filteredMismatches.length)} orders · 15 per page
                  </Typography>
                  <Pagination page={safePage} count={pageCount} onChange={(_, value) => setPage(value)} color="primary" size="small" showFirstButton showLastButton />
                </Stack>
              )}
            </Box>
          </GlassCard>
        </Stack>
      )}

      <Dialog open={loading} maxWidth="xs" fullWidth PaperProps={{ sx: { borderRadius: 2.25 } }}>
        <DialogContent sx={{ p: 2.4 }}>
          <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 1.2 }}>
            <Box><Typography variant="overline" color="primary.main" fontWeight={950}>Live reconciliation</Typography><Typography variant="h6" fontWeight={950}>{progress === 100 ? 'Trace ready' : 'Fetching order layers'}</Typography></Box>
            <Typography fontWeight={950} color="primary.main">{progress}%</Typography>
          </Stack>
          <LinearProgress variant="determinate" value={progress} sx={{ height: 8, borderRadius: 999, '& .MuiLinearProgress-bar': { borderRadius: 999 } }} />
          <Stack spacing={0.8} sx={{ mt: 1.5 }}>
            <ProgressStep done={progress >= 25} label="Allocation submissions loaded" />
            <ProgressStep done={progress >= 55} label="MAO SO orders correlated" />
            <ProgressStep done={progress >= 85} label="Store and warehouse actuals compared" />
          </Stack>
        </DialogContent>
      </Dialog>
    </Box>
  );
}

function SectionHeader({ number: sectionNumber, title, subtitle }: { number: string; title: string; subtitle: string }) {
  return <Box sx={{ px: 2, py: 1.45, borderBottom: 1, borderColor: 'divider', bgcolor: (theme) => alpha(theme.palette.primary.main, 0.045) }}><Stack direction="row" spacing={1.2} alignItems="center"><Box sx={{ width: 36, height: 36, borderRadius: 1.3, display: 'grid', placeItems: 'center', bgcolor: 'primary.main', color: 'primary.contrastText', fontWeight: 950 }}>{sectionNumber}</Box><Box><Typography variant="h6" fontWeight={950}>{title}</Typography><Typography variant="body2" color="text.secondary">{subtitle}</Typography></Box></Stack></Box>;
}

function SummaryKpi({ label, orders, quantity, tone, mismatch = false }: { label: string; orders: number; quantity: number; tone: 'primary' | 'success' | 'info' | 'warning' | 'error'; mismatch?: boolean }) {
  return <Grid item xs={12} sm={6} lg={3}><Box sx={{ p: 1.4, height: '100%', border: 1, borderColor: (theme) => alpha(theme.palette[tone].main, 0.25), borderRadius: 1.6, bgcolor: (theme) => alpha(theme.palette[tone].main, 0.055) }}><Typography variant="overline" color={`${tone}.main`} fontWeight={950}>{label}</Typography><Typography variant="h5" fontWeight={950}>{number.format(orders)}</Typography><Typography variant="body2" color="text.secondary">{mismatch ? `${number.format(quantity)} quantity variance` : `${number.format(quantity)} units · SO order level`}</Typography></Box></Grid>;
}

function SortableHead({ label, field, active, direction, onSort }: { label: string; field: SortKey; active: SortKey; direction: 'asc' | 'desc'; onSort: (field: SortKey) => void }) {
  return <TableCell sortDirection={active === field ? direction : false} sx={{ whiteSpace: 'nowrap' }}><TableSortLabel active={active === field} direction={active === field ? direction : 'asc'} onClick={() => onSort(field)}>{label}</TableSortLabel></TableCell>;
}

function Status({ value }: { value: string }) {
  const good = ['Submitted', 'Created', 'Received'].includes(value);
  const pending = value === 'Pending';
  return <Chip size="small" variant={good ? 'outlined' : 'filled'} color={good ? 'success' : pending ? 'warning' : 'error'} label={value} />;
}

function ProgressStep({ done, label }: { done: boolean; label: string }) {
  return <Stack direction="row" spacing={0.8} alignItems="center"><CheckCircleIcon color={done ? 'success' : 'disabled'} fontSize="small" /><Typography variant="body2" fontWeight={done ? 850 : 650} color={done ? 'text.primary' : 'text.secondary'}>{label}</Typography></Stack>;
}
