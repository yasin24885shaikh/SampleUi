import { Box, Button, Divider, FormControlLabel, MenuItem, Stack, Switch, TextField, Typography } from '@mui/material';
import Grid from '@mui/material/GridLegacy';
import SaveIcon from '@mui/icons-material/Save';
import GlassCard from '../components/GlassCard';
import PageHeader from '../components/PageHeader';
import { apiConfiguration } from '../services/apiClient';

export default function Settings() {
  return (
    <Box>
      <PageHeader title="Settings" subtitle="Configure the OMS user experience, notifications, search defaults, and environment controls." badge="Configuration" />
      <Grid container spacing={2.5}>
        <SettingsPanel title="Theme Settings">
          <FormControlLabel control={<Switch defaultChecked />} label="Use system theme by default" />
          <FormControlLabel control={<Switch />} label="Dense data views" />
        </SettingsPanel>
        <SettingsPanel title="Notification Settings">
          <FormControlLabel control={<Switch defaultChecked />} label="Inventory shortage alerts" />
          <FormControlLabel control={<Switch defaultChecked />} label="Order exception alerts" />
          <FormControlLabel control={<Switch />} label="Release SLA digest" />
        </SettingsPanel>
        <SettingsPanel title="Search Preferences">
          <TextField label="Default Result Limit" defaultValue="250" fullWidth />
          <TextField select label="Default Fulfillment Type" defaultValue="DC" fullWidth>
            <MenuItem value="DC">DC</MenuItem>
            <MenuItem value="Store">Store</MenuItem>
            <MenuItem value="Supplier">Supplier</MenuItem>
          </TextField>
        </SettingsPanel>
        <SettingsPanel title="Environment Configuration">
          <TextField select label="Environment" defaultValue="DEV" fullWidth>
            <MenuItem value="DEV">DEV</MenuItem>
            <MenuItem value="UAT">UAT</MenuItem>
            <MenuItem value="PROD">PROD</MenuItem>
          </TextField>
          <TextField label="REST API Base URL" value={apiConfiguration.baseUrl} fullWidth InputProps={{ readOnly: true }} />
          <TextField label="Active Data Provider" value={apiConfiguration.useMockApi ? 'Mock REST Adapter' : 'Live REST Backend'} fullWidth InputProps={{ readOnly: true }} />
        </SettingsPanel>
        <Grid item xs={12}>
          <GlassCard sx={{ p: 2.5 }}>
            <Stack direction={{ xs: 'column', sm: 'row' }} justifyContent="space-between" gap={2}>
              <Box>
                <Typography variant="h6">User Preferences</Typography>
                <Typography color="text.secondary">Persist dashboard, search, and notification preferences for Erica Stone.</Typography>
              </Box>
              <Button startIcon={<SaveIcon />} variant="contained">Save Preferences</Button>
            </Stack>
          </GlassCard>
        </Grid>
      </Grid>
    </Box>
  );
}

function SettingsPanel({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <Grid item xs={12} md={6}>
      <GlassCard sx={{ p: 2.5, height: '100%' }}>
        <Typography variant="h6">{title}</Typography>
        <Divider sx={{ my: 2 }} />
        <Stack spacing={1.5}>{children}</Stack>
      </GlassCard>
    </Grid>
  );
}
