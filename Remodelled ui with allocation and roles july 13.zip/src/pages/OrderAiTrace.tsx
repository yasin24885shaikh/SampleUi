import { useMemo, useState, type ReactNode } from 'react';
import { Alert, Box, Button, Chip, Dialog, DialogActions, DialogContent, DialogTitle, Divider, InputAdornment, LinearProgress, Pagination, Stack, TextField, Typography } from '@mui/material';
import Grid from '@mui/material/GridLegacy';
import { alpha } from '@mui/material/styles';
import AltRouteIcon from '@mui/icons-material/AltRoute';
import AutoAwesomeIcon from '@mui/icons-material/AutoAwesome';
import BlockIcon from '@mui/icons-material/Block';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import CreditCardIcon from '@mui/icons-material/CreditCard';
import LocalShippingIcon from '@mui/icons-material/LocalShipping';
import PersonOutlineIcon from '@mui/icons-material/PersonOutline';
import ReceiptLongIcon from '@mui/icons-material/ReceiptLong';
import RestartAltIcon from '@mui/icons-material/RestartAlt';
import SearchIcon from '@mui/icons-material/Search';
import StorefrontIcon from '@mui/icons-material/Storefront';
import SyncIcon from '@mui/icons-material/Sync';
import WarningAmberIcon from '@mui/icons-material/WarningAmber';
import WarehouseIcon from '@mui/icons-material/Warehouse';
import { motion } from 'framer-motion';
import GlassCard from '../components/GlassCard';
import PageHeader from '../components/PageHeader';
import { omsApi } from '../services/omsApi';

type OrderTraceStep = {
  label: string;
  time: string;
  state: 'passed' | 'stuck' | 'pending';
  detail: string;
};

type ReleaseTrace = {
  releaseId: string;
  releaseLineId: string;
  orderLineId: string;
  itemId: string;
  itemDescription: string;
  quantity: number;
  fulfillmentNode: string;
  nodeType: 'Warehouse' | 'Store';
  status: 'Healthy' | 'Stuck' | 'Pending';
  recommendation: string;
  steps: OrderTraceStep[];
};

type ReleaseFixKind = 'sync' | 'rerelease' | 'reroute' | 'hardCancel';
type ReleaseFixAction = {
  kind: ReleaseFixKind;
  label: string;
  title: string;
  description: string;
  confirmLabel: string;
  tone: 'info' | 'warning' | 'error';
  icon: ReactNode;
};

const orderTraceSteps: OrderTraceStep[] = [
  { label: 'Submitted', time: '2026-06-30 08:04 CT', state: 'passed', detail: 'Order accepted from digital channel and persisted in OMS.' },
  { label: 'Open', time: '2026-06-30 08:09 CT', state: 'passed', detail: 'Payment authorization, fraud, and address checks completed.' },
  { label: 'Backorder Evaluation', time: '2026-06-30 08:14 CT', state: 'passed', detail: 'AI confirmed two lines had available supply and one line required alternate sourcing.' },
  { label: 'Allocated', time: '2026-06-30 08:21 CT', state: 'passed', detail: 'Inventory reserved across Camp Hill WHSE and Store Fulfillment.' },
  { label: 'Released', time: '2026-06-30 08:27 CT', state: 'passed', detail: 'Order released. Fulfillment execution now continues independently by release line below.' }
];

const orderSummary = [
  { label: 'Customer', value: 'Maya Johnson', icon: <PersonOutlineIcon /> },
  { label: 'Created', value: '2026-06-30 08:04 CT', icon: <CalendarMonthIcon /> },
  { label: 'Payment', value: 'Authorized', icon: <CreditCardIcon /> },
  { label: 'Order Total', value: '$349.96', icon: <ReceiptLongIcon /> },
  { label: 'Lines', value: '6 lines / 7 units', icon: <ReceiptLongIcon /> },
  { label: 'Fulfillment Split', value: 'Camp Hill, Milton, Reno + Store', icon: <LocalShippingIcon /> }
];

const releaseTraces: ReleaseTrace[] = [
  {
    releaseId: 'REL-960204',
    releaseLineId: '1',
    orderLineId: '1.1',
    itemId: 'FV5029-141',
    itemDescription: 'Nike Air Max DN Black White',
    quantity: 1,
    fulfillmentNode: 'Camp Hill WHSE',
    nodeType: 'Warehouse',
    status: 'Stuck',
    recommendation: 'Republish release payload to Camp Hill WHSE and run acknowledgement sync.',
    steps: [
      { label: 'Release Created', time: '08:27 CT', state: 'passed', detail: 'Release line created from allocated inventory.' },
      { label: 'Sent to Node', time: '08:28 CT', state: 'passed', detail: 'Payload sent to Camp Hill warehouse queue.' },
      { label: 'Node Acknowledgement', time: '08:29 CT', state: 'stuck', detail: 'No acknowledgement received after retry exhaustion.' },
      { label: 'Pick Wave', time: 'Pending', state: 'pending', detail: 'Pick wave waits for warehouse acknowledgement.' },
      { label: 'Shipment', time: 'Pending', state: 'pending', detail: 'Shipment cannot be created until warehouse processing starts.' }
    ]
  },
  {
    releaseId: 'REL-960205',
    releaseLineId: '2',
    orderLineId: '2.1',
    itemId: 'HF2903-100',
    itemDescription: 'Jordan Retro 4 White Cement',
    quantity: 2,
    fulfillmentNode: 'Store 1093',
    nodeType: 'Store',
    status: 'Healthy',
    recommendation: 'No action needed. Continue monitoring store pick completion.',
    steps: [
      { label: 'Release Created', time: '08:27 CT', state: 'passed', detail: 'Release line created for store fulfillment.' },
      { label: 'Sent to Store', time: '08:30 CT', state: 'passed', detail: 'Store system acknowledged the release.' },
      { label: 'Pick Started', time: '08:44 CT', state: 'passed', detail: 'Store associate started pick task.' },
      { label: 'Packed', time: '09:02 CT', state: 'passed', detail: 'Package staged for handoff.' },
      { label: 'Fulfilled', time: '09:18 CT', state: 'passed', detail: 'Fulfillment confirmation posted back to OMS.' }
    ]
  },
  {
    releaseId: 'REL-960207',
    releaseLineId: '3',
    orderLineId: '4.1',
    itemId: 'JI2734',
    itemDescription: 'adidas Adizero EVO SL Core Black',
    quantity: 1,
    fulfillmentNode: 'Milton WHSE',
    nodeType: 'Warehouse',
    status: 'Healthy',
    recommendation: 'No action needed. Warehouse acknowledgement and pick wave are complete.',
    steps: [
      { label: 'Release Created', time: '08:28 CT', state: 'passed', detail: 'Release line created from allocated inventory.' },
      { label: 'Sent to Node', time: '08:30 CT', state: 'passed', detail: 'Payload acknowledged by Milton WHSE.' },
      { label: 'Pick Wave', time: '08:48 CT', state: 'passed', detail: 'Release assigned to outbound wave.' },
      { label: 'Packed', time: '09:11 CT', state: 'passed', detail: 'Package packed and staged for carrier handoff.' },
      { label: 'Fulfilled', time: '09:22 CT', state: 'passed', detail: 'Shipment confirmation posted back to OMS.' }
    ]
  },
  {
    releaseId: 'REL-960208',
    releaseLineId: '4',
    orderLineId: '5.1',
    itemId: '396403-01',
    itemDescription: 'PUMA Palermo Leather White Green',
    quantity: 1,
    fulfillmentNode: 'Reno WHSE',
    nodeType: 'Warehouse',
    status: 'Pending',
    recommendation: 'Monitor carrier manifest. Escalate if shipment event is not posted within 20 minutes.',
    steps: [
      { label: 'Release Created', time: '08:31 CT', state: 'passed', detail: 'Release line created from allocated inventory.' },
      { label: 'Sent to Node', time: '08:33 CT', state: 'passed', detail: 'Payload acknowledged by Reno WHSE.' },
      { label: 'Pick / Pack', time: '09:03 CT', state: 'passed', detail: 'Warehouse packed item successfully.' },
      { label: 'Manifest', time: 'In Progress', state: 'pending', detail: 'Carrier manifest event is pending.' },
      { label: 'Fulfilled', time: 'Pending', state: 'pending', detail: 'Waiting for carrier shipment confirmation.' }
    ]
  },
  {
    releaseId: 'REL-960209',
    releaseLineId: '5',
    orderLineId: '6.1',
    itemId: 'A12363C',
    itemDescription: 'Converse Weapon Ox Egret',
    quantity: 1,
    fulfillmentNode: 'Store 2044',
    nodeType: 'Store',
    status: 'Stuck',
    recommendation: 'Sync store pick status and reroute to warehouse if store does not confirm pick within 10 minutes.',
    steps: [
      { label: 'Release Created', time: '08:35 CT', state: 'passed', detail: 'Release line created for store fulfillment.' },
      { label: 'Sent to Store', time: '08:38 CT', state: 'passed', detail: 'Store system accepted release payload.' },
      { label: 'Pick Started', time: '08:57 CT', state: 'stuck', detail: 'Pick task opened but no associate confirmation after SLA threshold.' },
      { label: 'Packed', time: 'Pending', state: 'pending', detail: 'Pack step waits for pick confirmation.' },
      { label: 'Fulfilled', time: 'Pending', state: 'pending', detail: 'Fulfillment event cannot post until pack completes.' }
    ]
  },
  {
    releaseId: 'REL-960206',
    releaseLineId: '6',
    orderLineId: '3.1',
    itemId: 'U740WM2',
    itemDescription: 'New Balance 740 White Midnight',
    quantity: 1,
    fulfillmentNode: 'Camp Hill WHSE',
    nodeType: 'Warehouse',
    status: 'Pending',
    recommendation: 'Monitor for pick wave assignment. Escalate if not picked within 30 minutes.',
    steps: [
      { label: 'Release Created', time: '08:27 CT', state: 'passed', detail: 'Release line created from allocated inventory.' },
      { label: 'Sent to Node', time: '08:29 CT', state: 'passed', detail: 'Payload acknowledged by Camp Hill WHSE.' },
      { label: 'Pick Wave', time: '09:06 CT', state: 'passed', detail: 'Release assigned to outbound wave.' },
      { label: 'Pick / Pack', time: 'In Progress', state: 'pending', detail: 'Warehouse pick task is in progress.' },
      { label: 'Fulfilled', time: 'Pending', state: 'pending', detail: 'Shipment confirmation pending warehouse pack completion.' }
    ]
  }
];

const releaseFixActions: ReleaseFixAction[] = [
  {
    kind: 'sync',
    label: 'Sync Status',
    title: 'Sync release status?',
    description: 'Pull latest fulfillment, pick, package, and shipment signals for this release line.',
    confirmLabel: 'Confirm Sync',
    tone: 'info',
    icon: <SyncIcon />
  },
  {
    kind: 'rerelease',
    label: 'Re-release',
    title: 'Re-release to fulfillment node?',
    description: 'Republish the release payload to the assigned fulfillment node and request acknowledgement.',
    confirmLabel: 'Confirm Re-release',
    tone: 'warning',
    icon: <RestartAltIcon />
  },
  {
    kind: 'reroute',
    label: 'Re-route',
    title: 'Re-route this release?',
    description: 'Queue a reroute request with delivery-note handling so fulfillment can move to an alternate node.',
    confirmLabel: 'Confirm Re-route',
    tone: 'warning',
    icon: <AltRouteIcon />
  },
  {
    kind: 'hardCancel',
    label: 'Hard Cancel',
    title: 'Hard cancel this release?',
    description: 'Cancel the release line when the fulfillment issue is unrecoverable.',
    confirmLabel: 'Confirm Hard Cancel',
    tone: 'error',
    icon: <BlockIcon />
  }
];

export default function OrderAiTrace() {
  const [orderNumber, setOrderNumber] = useState('');
  const [traceStarted, setTraceStarted] = useState(false);
  const [releaseSearch, setReleaseSearch] = useState('');
  const [releasePage, setReleasePage] = useState(1);
  const releasePageSize = 4;
  const filteredReleases = useMemo(() => {
    const query = releaseSearch.trim().toLowerCase();
    if (!query) return releaseTraces;
    return releaseTraces.filter((release) => [
      release.releaseId,
      release.releaseLineId,
      release.orderLineId,
      release.itemId,
      release.itemDescription,
      release.fulfillmentNode,
      release.nodeType,
      release.status,
      release.recommendation,
      ...release.steps.map((step) => `${step.label} ${step.time} ${step.state} ${step.detail}`)
    ].join(' ').toLowerCase().includes(query));
  }, [releaseSearch]);
  const releasePageCount = Math.max(1, Math.ceil(filteredReleases.length / releasePageSize));
  const activeReleasePage = Math.min(releasePage, releasePageCount);
  const pagedReleases = filteredReleases.slice((activeReleasePage - 1) * releasePageSize, activeReleasePage * releasePageSize);
  const stuckReleaseCount = releaseTraces.filter((release) => release.status === 'Stuck').length;

  return (
    <Box
      sx={{
        minWidth: 0,
        '& .MuiTypography-body2': { fontSize: 'clamp(.8rem, .74rem + .14vw, .9rem)' },
        '& .MuiTypography-caption': { fontSize: 'clamp(.68rem, .63rem + .1vw, .76rem)' },
        '& .MuiButton-root': { fontSize: 'clamp(.76rem, .7rem + .12vw, .86rem)' },
        '@media (max-width:1180px)': {
          '& .MuiCard-root, & .MuiPaper-root': { borderRadius: 1.5 },
          '& .MuiButton-root': { minHeight: 30, px: 1 },
          '& .MuiChip-root': { height: 21 }
        }
      }}
    >
      <PageHeader
        title="Order AI Trace"
        subtitle="Trace a single order across OMS lifecycle milestones and identify the exact stuck point with AI root-cause guidance."
        badge="Order Diagnostics"
      />

      <GlassCard sx={{ p: { xs: 1.5, md: 2 }, mb: 2 }}>
        <Stack direction={{ xs: 'column', lg: 'row' }} spacing={1.4} alignItems={{ lg: 'center' }} justifyContent="space-between">
          <Stack direction="row" spacing={1.1} alignItems="center">
            <Box sx={{ width: 46, height: 46, borderRadius: 2, display: 'grid', placeItems: 'center', color: 'primary.main', bgcolor: (theme) => alpha(theme.palette.primary.main, 0.1) }}>
              <AutoAwesomeIcon />
            </Box>
            <Box>
              <Typography variant="h6" fontWeight={950}>Single Order AI Trace</Typography>
              <Typography variant="body2" color="text.secondary">Enter an order number to animate the path it passed and expose where the order is stuck.</Typography>
            </Box>
          </Stack>
          <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1} alignItems={{ xs: 'stretch', sm: 'center' }} sx={{ width: { xs: '100%', lg: 'auto' } }}>
            <TextField
              size="small"
              label="Order Number"
              value={orderNumber}
              onChange={(event) => {
                setOrderNumber(event.target.value);
                setTraceStarted(false);
              }}
              placeholder="FL-10048291"
              sx={{ minWidth: { sm: 240 } }}
            />
            <Button
              variant="contained"
              startIcon={<AutoAwesomeIcon />}
              disabled={!orderNumber.trim()}
              onClick={() => setTraceStarted(true)}
              sx={{ minWidth: { xs: '100%', sm: 150 }, fontWeight: 950 }}
            >
              Trace Order
            </Button>
          </Stack>
        </Stack>
      </GlassCard>

      {!traceStarted && (
        <Alert severity="info" icon={<AutoAwesomeIcon />}>Enter an order number and click Trace Order to run order-level AI diagnostics.</Alert>
      )}

      {traceStarted && (
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}>
          <GlassCard sx={{ p: { xs: 1.5, md: 2 }, mb: 2 }}>
            <Stack direction={{ xs: 'column', md: 'row' }} spacing={1} justifyContent="space-between" alignItems={{ md: 'center' }} sx={{ mb: 1.4 }}>
              <Box>
                <Typography variant="h6" fontWeight={950}>{orderNumber.trim()}</Typography>
                <Typography variant="body2" color="text.secondary">Order-level trace with line and fulfillment context.</Typography>
              </Box>
              <Chip icon={<WarningAmberIcon />} label={`${stuckReleaseCount} release lines need attention`} color="error" variant="outlined" />
            </Stack>
            <Grid container spacing={1}>
              {orderSummary.map((item) => (
                <Grid item xs={12} sm={6} lg={4} key={item.label}>
                  <Box sx={{ p: 1.1, border: 1, borderColor: 'divider', borderRadius: 1.5, bgcolor: (theme) => alpha(theme.palette.background.paper, 0.65) }}>
                    <Stack direction="row" spacing={1} alignItems="center">
                      <Box sx={{ color: 'primary.main', display: 'flex', '& svg': { fontSize: 19 } }}>{item.icon}</Box>
                      <Box>
                        <Typography variant="caption" color="text.secondary">{item.label}</Typography>
                        <Typography variant="body2" fontWeight={900}>{item.value}</Typography>
                      </Box>
                    </Stack>
                  </Box>
                </Grid>
              ))}
            </Grid>
          </GlassCard>

          <GlassCard sx={{ p: { xs: 1.5, md: 2 } }}>
            <Typography variant="h6" fontWeight={950} sx={{ mb: 1.2 }}>Animated Order Lifecycle</Typography>
            {orderTraceSteps.map((step, index) => (
              <motion.div key={step.label} initial={{ opacity: 0, x: -16 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: index * 0.11, duration: 0.32 }}>
                <Stack direction="row" spacing={1.2} alignItems="stretch" sx={{ pb: index === orderTraceSteps.length - 1 ? 0 : 1.1 }}>
                  <Box sx={{ width: 34, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                    <Box sx={{ width: 27, height: 27, borderRadius: '50%', display: 'grid', placeItems: 'center', color: 'common.white', fontWeight: 950, bgcolor: step.state === 'passed' ? 'success.main' : step.state === 'stuck' ? 'error.main' : 'grey.500' }}>
                      {step.state === 'passed' ? '✓' : step.state === 'stuck' ? '!' : '·'}
                    </Box>
                    {index < orderTraceSteps.length - 1 && <Box sx={{ width: 2, flex: 1, minHeight: 48, bgcolor: step.state === 'passed' ? 'success.light' : step.state === 'stuck' ? 'error.light' : 'divider', mt: 0.6 }} />}
                  </Box>
                  <Box sx={{ flex: 1, p: 1.15, border: 1, borderLeft: '4px solid', borderColor: 'divider', borderLeftColor: step.state === 'passed' ? 'success.main' : step.state === 'stuck' ? 'error.main' : 'grey.400', borderRadius: 1.75, bgcolor: (theme) => alpha(step.state === 'passed' ? theme.palette.success.main : step.state === 'stuck' ? theme.palette.error.main : theme.palette.grey[500], step.state === 'pending' ? 0.04 : 0.065) }}>
                    <Stack direction={{ xs: 'column', sm: 'row' }} spacing={0.8} justifyContent="space-between">
                      <Typography fontWeight={950}>{step.label}</Typography>
                      <Chip size="small" label={step.time} variant="outlined" />
                    </Stack>
                    <Typography variant="body2" color="text.secondary" sx={{ mt: 0.4 }}>{step.detail}</Typography>
                    {step.state === 'stuck' && (
                      <Alert severity="error" sx={{ mt: 1 }}>
                        AI recommendation: republish the Camp Hill release payload, run fulfillment acknowledgement sync, and reroute the order if no node acknowledgement is received within 15 minutes.
                      </Alert>
                    )}
                    <LinearProgress variant="determinate" value={step.state === 'passed' ? 100 : step.state === 'stuck' ? 62 : 12} sx={{ mt: 1, height: 6, borderRadius: 999 }} color={step.state === 'stuck' ? 'error' : step.state === 'passed' ? 'success' : 'inherit'} />
                  </Box>
                </Stack>
              </motion.div>
            ))}
          </GlassCard>

          <GlassCard sx={{ p: { xs: 1.5, md: 2 }, mt: 2 }}>
            <Stack direction={{ xs: 'column', md: 'row' }} spacing={1} justifyContent="space-between" alignItems={{ md: 'center' }} sx={{ mb: 1.4 }}>
              <Box>
                <Typography variant="h6" fontWeight={950}>Individual Release Traces</Typography>
                <Typography variant="body2" color="text.secondary">Each release line is tracked independently after the order reaches Released status.</Typography>
              </Box>
              <Chip label={`${filteredReleases.length} matching release lines`} color="primary" variant="outlined" />
            </Stack>
            <Stack direction={{ xs: 'column', md: 'row' }} spacing={1} justifyContent="space-between" alignItems={{ md: 'center' }} sx={{ mb: 1.25 }}>
              <TextField
                fullWidth
                size="small"
                label="Global search releases"
                value={releaseSearch}
                onChange={(event) => {
                  setReleaseSearch(event.target.value);
                  setReleasePage(1);
                }}
                placeholder="Search release, line, item, node, status, reason, recommendation"
                InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment> }}
              />
              <Chip label={`${releasePageSize} per page`} variant="outlined" sx={{ minWidth: 96 }} />
            </Stack>
            <Grid container spacing={1.25}>
              {pagedReleases.map((release, releaseIndex) => (
                <Grid item xs={12} md={6} xl={4} key={release.releaseLineId}>
                  <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: releaseIndex * 0.12, duration: 0.3 }}>
                    <ReleaseTraceCard release={release} />
                  </motion.div>
                </Grid>
              ))}
            </Grid>
            {!filteredReleases.length && (
              <Alert severity="info" sx={{ mt: 1.25 }}>No release traces match this search.</Alert>
            )}
            {filteredReleases.length > releasePageSize && (
              <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1} alignItems={{ xs: 'flex-start', sm: 'center' }} justifyContent="space-between" sx={{ mt: 1.5, pt: 1.25, borderTop: 1, borderColor: 'divider' }}>
                <Typography variant="body2" color="text.secondary">
                  Showing {(activeReleasePage - 1) * releasePageSize + 1}-{Math.min(activeReleasePage * releasePageSize, filteredReleases.length)} of {filteredReleases.length} releases
                </Typography>
                <Pagination count={releasePageCount} page={activeReleasePage} onChange={(_, value) => setReleasePage(value)} color="primary" shape="rounded" size="small" />
              </Stack>
            )}
          </GlassCard>
        </motion.div>
      )}
    </Box>
  );
}

function ReleaseTraceCard({ release }: { release: ReleaseTrace }) {
  const Icon = release.nodeType === 'Warehouse' ? WarehouseIcon : StorefrontIcon;
  const statusColor = release.status === 'Stuck' ? 'error' : release.status === 'Healthy' ? 'success' : 'warning';
  const [pendingAction, setPendingAction] = useState<ReleaseFixAction | null>(null);
  const [actionResult, setActionResult] = useState<{ severity: 'success' | 'error'; message: string } | null>(null);
  const [actionLoading, setActionLoading] = useState(false);

  const confirmReleaseFix = async () => {
    if (!pendingAction) return;
    const action = pendingAction;
    setActionLoading(true);
    try {
      if (action.kind === 'sync') {
        await omsApi.syncFulfillment(release.releaseLineId);
      } else if (action.kind === 'rerelease') {
        await omsApi.rereleaseToFulfillmentNode(release.releaseId);
      } else if (action.kind === 'reroute') {
        await omsApi.rerouteRelease(release.releaseId, true);
      } else {
        await omsApi.hardCancelRelease(release.releaseId);
      }
      setActionResult({
        severity: 'success',
        message: `${release.releaseId} / ${release.releaseLineId}: ${action.label} request was queued successfully for ${release.fulfillmentNode}.`
      });
      setPendingAction(null);
    } catch (requestError) {
      setActionResult({
        severity: 'error',
        message: requestError instanceof Error ? requestError.message : `${action.label} could not be queued for this release.`
      });
    } finally {
      setActionLoading(false);
    }
  };

  return (
    <Box sx={{ height: '100%', p: 1.25, border: 1, borderTop: '4px solid', borderColor: 'divider', borderTopColor: release.status === 'Stuck' ? 'error.main' : release.status === 'Healthy' ? 'success.main' : 'warning.main', borderRadius: 2, bgcolor: (theme) => alpha(theme.palette.background.paper, 0.72) }}>
      <Stack direction="row" spacing={1} justifyContent="space-between" alignItems="flex-start">
        <Stack direction="row" spacing={1} alignItems="center" sx={{ minWidth: 0 }}>
          <Box sx={{ width: 38, height: 38, borderRadius: 1.6, display: 'grid', placeItems: 'center', color: `${statusColor}.main`, bgcolor: (theme) => alpha(theme.palette[statusColor].main, 0.12), flex: '0 0 auto' }}>
            <Icon fontSize="small" />
          </Box>
          <Box sx={{ minWidth: 0 }}>
            <Typography fontWeight={950}>{release.releaseId}</Typography>
            <Typography variant="caption" color="text.secondary">{release.releaseLineId} · Line {release.orderLineId}</Typography>
          </Box>
        </Stack>
        <Chip size="small" label={release.status} color={statusColor} variant="outlined" />
      </Stack>
      <Box sx={{ mt: 1, p: 1, borderRadius: 1.4, bgcolor: (theme) => alpha(theme.palette.background.default, 0.55) }}>
        <Typography variant="caption" color="text.secondary">Item</Typography>
        <Typography variant="body2" fontWeight={900}>{release.itemId}</Typography>
        <Typography variant="caption" color="text.secondary">{release.itemDescription} · Qty {release.quantity}</Typography>
        <Divider sx={{ my: 0.85 }} />
        <Typography variant="caption" color="text.secondary">Fulfillment Node</Typography>
        <Typography variant="body2" fontWeight={900}>{release.fulfillmentNode}</Typography>
      </Box>

      <Stack spacing={0.75} sx={{ mt: 1.15 }}>
        {release.steps.map((step, index) => (
          <Stack key={`${release.releaseLineId}-${step.label}`} direction="row" spacing={0.85} alignItems="stretch">
            <Box sx={{ width: 22, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
              <Box sx={{ width: 19, height: 19, borderRadius: '50%', display: 'grid', placeItems: 'center', color: 'common.white', fontSize: 12, fontWeight: 950, bgcolor: step.state === 'passed' ? 'success.main' : step.state === 'stuck' ? 'error.main' : 'grey.500' }}>
                {step.state === 'passed' ? '✓' : step.state === 'stuck' ? '!' : '·'}
              </Box>
              {index < release.steps.length - 1 && <Box sx={{ width: 2, flex: 1, minHeight: 26, bgcolor: step.state === 'passed' ? 'success.light' : step.state === 'stuck' ? 'error.light' : 'divider', mt: 0.35 }} />}
            </Box>
            <Box sx={{ flex: 1, pb: index === release.steps.length - 1 ? 0 : 0.6 }}>
              <Stack direction="row" justifyContent="space-between" spacing={0.8}>
                <Typography variant="caption" fontWeight={950}>{step.label}</Typography>
                <Typography variant="caption" color="text.secondary">{step.time}</Typography>
              </Stack>
              <Typography variant="caption" color="text.secondary" sx={{ display: 'block', lineHeight: 1.25 }}>{step.detail}</Typography>
            </Box>
          </Stack>
        ))}
      </Stack>

      <Alert severity={release.status === 'Stuck' ? 'error' : release.status === 'Healthy' ? 'success' : 'warning'} sx={{ mt: 1.1 }}>
        {release.recommendation}
      </Alert>
      {release.status === 'Healthy' ? (
        <Box
          sx={{
            mt: 1,
            p: 0.9,
            border: 1,
            borderColor: (theme) => alpha(theme.palette.success.main, 0.24),
            borderRadius: 1.5,
            bgcolor: (theme) => alpha(theme.palette.success.main, 0.055)
          }}
        >
          <Stack direction="row" spacing={0.75} alignItems="center">
            <AutoAwesomeIcon color="success" fontSize="small" />
            <Box>
              <Typography variant="caption" fontWeight={950} color="success.dark">No release action needed</Typography>
              <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>AI trace is healthy and fulfillment milestones are complete.</Typography>
            </Box>
          </Stack>
        </Box>
      ) : (
        <Box
          sx={{
            mt: 1,
            p: 0.9,
            border: 1,
            borderColor: (theme) => alpha(theme.palette.primary.main, 0.18),
            borderRadius: 1.5,
            bgcolor: (theme) => alpha(theme.palette.primary.main, 0.04)
          }}
        >
          <Stack direction="row" spacing={0.75} alignItems="center" sx={{ mb: 0.75 }}>
            <AutoAwesomeIcon color="primary" fontSize="small" />
            <Typography variant="caption" fontWeight={950} color="text.secondary">Release Fix Actions</Typography>
          </Stack>
          <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr 1fr', sm: 'repeat(4, minmax(0, 1fr))', md: '1fr 1fr', xl: 'repeat(4, minmax(0, 1fr))' }, gap: 0.65 }}>
            {releaseFixActions.map((action) => {
              const actionAccent = action.kind === 'sync' ? '#315f78' : action.kind === 'rerelease' ? '#4f6572' : action.kind === 'reroute' ? '#7a5a24' : '#8a3a3a';
              return (
                <Button
                  key={action.kind}
                  size="small"
                  variant="outlined"
                  startIcon={action.icon}
                  onClick={() => setPendingAction(action)}
                  sx={{
                    minHeight: 30,
                    px: 0.75,
                    borderRadius: 1.4,
                    fontSize: '0.72rem',
                    fontWeight: 950,
                    lineHeight: 1.1,
                    whiteSpace: 'normal',
                    color: actionAccent,
                    borderColor: alpha(actionAccent, 0.32),
                    bgcolor: alpha(actionAccent, 0.07),
                    boxShadow: 'inset 0 1px 0 rgba(255,255,255,.52)',
                    '&:hover': {
                      color: actionAccent,
                      borderColor: alpha(actionAccent, 0.46),
                      bgcolor: alpha(actionAccent, 0.12),
                      boxShadow: `0 6px 14px ${alpha(actionAccent, 0.12)}`
                    },
                    '& .MuiButton-startIcon': { mr: 0.45, '& svg': { fontSize: 16 } }
                  }}
                >
                  {action.label}
                </Button>
              );
            })}
          </Box>
        </Box>
      )}

      <Dialog open={Boolean(pendingAction)} onClose={() => !actionLoading && setPendingAction(null)} maxWidth="xs" fullWidth PaperProps={{ sx: { m: { xs: 1.5, sm: 2.5 }, width: { xs: 'calc(100vw - 28px)', sm: 520 }, borderRadius: 2.25 } }}>
        <DialogTitle>
          <Stack direction="row" spacing={1.2} alignItems="center">
            <Box
              sx={{
                width: 42,
                height: 42,
                borderRadius: 1.75,
                display: 'grid',
                placeItems: 'center',
                color: pendingAction?.tone === 'error' ? 'error.main' : pendingAction?.tone === 'warning' ? 'warning.main' : 'primary.main',
                bgcolor: (theme) => alpha(pendingAction?.tone === 'error' ? theme.palette.error.main : pendingAction?.tone === 'warning' ? theme.palette.warning.main : theme.palette.primary.main, 0.1)
              }}
            >
              {pendingAction?.icon}
            </Box>
            <Box sx={{ minWidth: 0 }}>
              <Typography variant="h6" fontWeight={950}>{pendingAction?.title}</Typography>
              <Typography variant="body2" color="text.secondary">{release.releaseId} · {release.releaseLineId}</Typography>
            </Box>
          </Stack>
        </DialogTitle>
        <DialogContent dividers>
          <Typography fontWeight={850}>{pendingAction?.description}</Typography>
          <Grid container spacing={1} sx={{ mt: 1 }}>
            {[
              ['Order Line', release.orderLineId],
              ['Item', release.itemId],
              ['Node', release.fulfillmentNode],
              ['Current Status', release.status]
            ].map(([label, value]) => (
              <Grid item xs={12} sm={6} key={label}>
                <Box sx={{ p: 1, border: 1, borderColor: 'divider', borderRadius: 1.4, bgcolor: (theme) => alpha(theme.palette.background.default, 0.55) }}>
                  <Typography variant="caption" color="text.secondary">{label}</Typography>
                  <Typography variant="body2" fontWeight={900}>{value}</Typography>
                </Box>
              </Grid>
            ))}
          </Grid>
          <Alert severity={pendingAction?.tone ?? 'info'} sx={{ mt: 1.25 }}>
            This will call the backend release action API and queue the fix for operations tracking.
          </Alert>
        </DialogContent>
        <DialogActions sx={{ px: 3, py: 2 }}>
          <Button onClick={() => setPendingAction(null)} color="inherit" disabled={actionLoading}>Close</Button>
          <Button variant="contained" startIcon={pendingAction?.icon} onClick={confirmReleaseFix} disabled={actionLoading}>
            {actionLoading ? 'Queuing...' : pendingAction?.confirmLabel}
          </Button>
        </DialogActions>
      </Dialog>

      <Dialog open={Boolean(actionResult)} onClose={() => setActionResult(null)} maxWidth={false} fullWidth PaperProps={{ sx: { m: { xs: 1.5, sm: 2.5 }, width: { xs: 'calc(100vw - 32px)', sm: 420 }, borderRadius: 2.25, overflow: 'hidden' } }}>
        <DialogTitle sx={{ px: 2.25, py: 2 }}>
          <Stack direction="row" spacing={1.2} alignItems="center">
            <Box sx={{ width: 38, height: 38, borderRadius: 1.6, display: 'grid', placeItems: 'center', color: actionResult?.severity === 'success' ? 'success.main' : 'error.main', bgcolor: (theme) => alpha(actionResult?.severity === 'success' ? theme.palette.success.main : theme.palette.error.main, 0.1) }}>
              {actionResult?.severity === 'success' ? <SyncIcon /> : <WarningAmberIcon />}
            </Box>
            <Box>
              <Typography variant="h6" fontWeight={950}>{actionResult?.severity === 'success' ? 'Release fix queued' : 'Release action failed'}</Typography>
              <Typography variant="body2" color="text.secondary">Backend action response</Typography>
            </Box>
          </Stack>
        </DialogTitle>
        <DialogContent dividers sx={{ px: 2.25, py: 1.75 }}>
          <Typography sx={{ color: '#111827', fontWeight: 850 }}>{actionResult?.message}</Typography>
        </DialogContent>
        <DialogActions sx={{ px: 2.25, py: 1.5 }}>
          <Button variant="contained" onClick={() => setActionResult(null)}>Done</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
