import {
  Box,
  Button,
  MenuItem,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  TextField,
  Typography
} from '@mui/material';
import Grid from '@mui/material/GridLegacy';
import SearchIcon from '@mui/icons-material/Search';
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import GlassCard from '../components/GlassCard';
import PageHeader from '../components/PageHeader';
import { ApiErrorState, ApiLoading } from '../components/ApiFeedback';
import { useApiResource } from '../hooks/useApiResource';
import { omsApi } from '../services/omsApi';

export default function InventoryManagement() {
  const { data, error, reload } = useApiResource(omsApi.getInventory);

  if (!data) {
    return (
      <Box>
        <PageHeader title="Inventory Management" subtitle="Enterprise inventory visibility by SKU, category, and fulfillment node." badge="ATP Snapshot" />
        {error ? <ApiErrorState message={error.message} onRetry={reload} /> : <ApiLoading rows={6} />}
      </Box>
    );
  }
  const inventoryRows = data.items;
  const inventoryTrend = data.trend;

  return (
    <Box>
      <PageHeader title="Inventory Management" subtitle="Enterprise inventory visibility by SKU, category, and fulfillment node." badge="ATP Snapshot" />
      <Grid container spacing={2.5}>
        <Grid item xs={12}>
          <GlassCard sx={{ p: 2.5 }}>
            <Stack direction={{ xs: 'column', md: 'row' }} spacing={2}>
              <TextField label="SKU" placeholder="FV5029-141" fullWidth />
              <TextField label="Product Name" fullWidth />
              <TextField label="Category" select defaultValue="" fullWidth>
                <MenuItem value="">All Categories</MenuItem>
                <MenuItem value="Running">Running</MenuItem>
                <MenuItem value="Lifestyle">Lifestyle</MenuItem>
                <MenuItem value="Launch">Launch</MenuItem>
              </TextField>
              <TextField label="Fulfillment Node" fullWidth />
              <Button startIcon={<SearchIcon />} variant="contained" sx={{ minWidth: 130 }}>Search</Button>
              <Button startIcon={<FileDownloadIcon />} variant="outlined" sx={{ minWidth: 130 }}>Export</Button>
            </Stack>
          </GlassCard>
        </Grid>
        <Grid item xs={12} lg={8}>
          <GlassCard sx={{ p: 2, height: 440, overflow: 'auto' }}>
            <Table stickyHeader>
              <TableHead>
                <TableRow>
                  <TableCell>SKU</TableCell>
                  <TableCell>Product Name</TableCell>
                  <TableCell align="right">Available Inventory</TableCell>
                  <TableCell align="right">Reserved Inventory</TableCell>
                  <TableCell align="right">Safety Stock</TableCell>
                  <TableCell>Fulfillment Nodes</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {inventoryRows.map((row) => (
                  <TableRow key={row.sku} hover>
                    <TableCell sx={{ fontWeight: 800 }}>{row.sku}</TableCell>
                    <TableCell>{row.productName}</TableCell>
                    <TableCell align="right">{row.available.toLocaleString()}</TableCell>
                    <TableCell align="right">{row.reserved.toLocaleString()}</TableCell>
                    <TableCell align="right">{row.safety.toLocaleString()}</TableCell>
                    <TableCell>{row.nodes}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </GlassCard>
        </Grid>
        <Grid item xs={12} lg={4}>
          <GlassCard sx={{ p: 2.5, height: 440 }}>
            <Typography variant="h6" sx={{ mb: 2 }}>Inventory Trend</Typography>
            <ResponsiveContainer width="100%" height={330}>
              <AreaChart data={inventoryTrend}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="day" />
                <YAxis />
                <Tooltip />
                <Area type="monotone" dataKey="available" stroke="#117c8b" fill="#117c8b" fillOpacity={0.2} strokeWidth={3} />
              </AreaChart>
            </ResponsiveContainer>
          </GlassCard>
        </Grid>
      </Grid>
    </Box>
  );
}
