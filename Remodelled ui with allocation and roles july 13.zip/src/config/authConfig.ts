export const authConfig = {
  enabled: import.meta.env.VITE_AUTH_ENABLED === 'true',
  tenantId: import.meta.env.VITE_AZURE_TENANT_ID || '',
  clientId: import.meta.env.VITE_AZURE_CLIENT_ID || '',
  authority: import.meta.env.VITE_AZURE_AUTHORITY || (
    import.meta.env.VITE_AZURE_TENANT_ID
      ? `https://login.microsoftonline.com/${import.meta.env.VITE_AZURE_TENANT_ID}`
      : 'https://login.microsoftonline.com/common'
  ),
  redirectUri: import.meta.env.VITE_AZURE_REDIRECT_URI || window.location.origin,
  postLogoutRedirectUri: import.meta.env.VITE_AZURE_POST_LOGOUT_REDIRECT_URI || window.location.origin,
  apiScope: import.meta.env.VITE_AZURE_API_SCOPE || '',
  appName: import.meta.env.VITE_APP_NAME || 'cr-global-app-ops-ui',
  appVersion: import.meta.env.VITE_APP_VERSION || '1.0.0',
  environment: import.meta.env.VITE_APP_ENV || 'DEV'
};

export type AuthConfig = typeof authConfig;
