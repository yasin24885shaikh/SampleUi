import { useEffect, useMemo, useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import {
  AppBar,
  Avatar,
  Badge,
  Box,
  Button,
  Chip,
  Divider,
  Drawer,
  IconButton,
  List,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Menu,
  MenuItem,
  Stack,
  Toolbar,
  Tooltip,
  Typography,
  alpha,
  useMediaQuery
} from '@mui/material';
import { useTheme } from '@mui/material/styles';
import DashboardIcon from '@mui/icons-material/Dashboard';
import Inventory2Icon from '@mui/icons-material/Inventory2';
import ManageSearchIcon from '@mui/icons-material/ManageSearch';
import PsychologyIcon from '@mui/icons-material/Psychology';
import DescriptionIcon from '@mui/icons-material/Description';
import CategoryIcon from '@mui/icons-material/Category';
import PeopleIcon from '@mui/icons-material/People';
import SettingsIcon from '@mui/icons-material/Settings';
import AppsIcon from '@mui/icons-material/Apps';
import MenuIcon from '@mui/icons-material/Menu';
import NotificationsIcon from '@mui/icons-material/Notifications';
import LightModeIcon from '@mui/icons-material/LightMode';
import DarkModeIcon from '@mui/icons-material/DarkMode';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import KeyboardDoubleArrowLeftIcon from '@mui/icons-material/KeyboardDoubleArrowLeft';
import KeyboardDoubleArrowRightIcon from '@mui/icons-material/KeyboardDoubleArrowRight';
import CloseIcon from '@mui/icons-material/Close';
import DoneAllIcon from '@mui/icons-material/DoneAll';
import LocalShippingIcon from '@mui/icons-material/LocalShipping';
import CreditCardIcon from '@mui/icons-material/CreditCard';
import SyncProblemIcon from '@mui/icons-material/SyncProblem';
import AssignmentReturnIcon from '@mui/icons-material/AssignmentReturn';
import AccountTreeIcon from '@mui/icons-material/AccountTree';
import { motion } from 'framer-motion';
import { footLockerLogo, footLockerMark } from '../assets/footlocker';
import { useAuth } from '../contexts/AuthContext';
import { useThemeMode } from '../contexts/ThemeModeContext';
import { useApiResource } from '../hooks/useApiResource';
import { omsApi } from '../services/omsApi';

const expandedWidth = 252;
const collapsedWidth = 76;

type AppRole = 'OMS Administrator' | 'OMS Ops L2' | 'OMS Ops L1' | 'Business Read' | 'Business Write';

const allRoles: AppRole[] = ['OMS Administrator', 'OMS Ops L2', 'OMS Ops L1', 'Business Read', 'Business Write'];
const operationsRoles: AppRole[] = ['OMS Administrator', 'OMS Ops L2', 'OMS Ops L1'];
const writeRoles: AppRole[] = ['OMS Administrator', 'OMS Ops L2', 'OMS Ops L1', 'Business Write'];
const roleAliases: Record<string, AppRole> = {
  'OMS Admin': 'OMS Administrator',
  'OMS Administrator': 'OMS Administrator',
  'OMS Ops L2': 'OMS Ops L2',
  'OMS Ops L1': 'OMS Ops L1',
  'Business Read': 'Business Read',
  'Business Write': 'Business Write'
};

const navItems = [
  { label: 'Dashboard', path: '/dashboard', icon: <DashboardIcon />, roles: allRoles },
  { label: 'Order Live Tracking', path: '/order-tracking', icon: <ManageSearchIcon />, roles: allRoles },
  { label: 'Order Status AI Analytics', path: '/order-status-analytics', icon: <PsychologyIcon />, roles: allRoles },
  { label: 'Order AI Trace', path: '/order-ai-trace', icon: <LocalShippingIcon />, roles: writeRoles },
  { label: 'Allocation Order Trace', path: '/allocation-order-trace', icon: <AccountTreeIcon />, roles: operationsRoles },
  { label: 'Inventory Management', path: '/inventory', icon: <Inventory2Icon />, roles: operationsRoles, hidden: true },
  { label: 'SKU Documentation (SKUDOC)', path: '/skudoc', icon: <DescriptionIcon />, roles: operationsRoles, hidden: true },
  { label: 'Common Products', path: '/common-products', icon: <CategoryIcon />, roles: allRoles, hidden: true },
  { label: 'User Management', path: '/users', icon: <PeopleIcon />, roles: ['OMS Administrator'] as AppRole[] },
  { label: 'Custom Utilities', path: '/custom-utilities', icon: <AppsIcon />, roles: operationsRoles },
  { label: 'Settings', path: '/settings', icon: <SettingsIcon />, roles: ['OMS Administrator'] as AppRole[] }
];

export default function MainLayout({ children }: { children: React.ReactNode }) {
  const theme = useTheme();
  const { mode, toggleMode } = useThemeMode();
  const { authEnabled, user, signIn, signOut } = useAuth();
  const isDesktop = useMediaQuery(theme.breakpoints.up('lg'));
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [profileAnchor, setProfileAnchor] = useState<null | HTMLElement>(null);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [readNotifications, setReadNotifications] = useState<string[]>([]);
  const { data: notificationResponse } = useApiResource(omsApi.getNotifications);
  const notificationItems = notificationResponse?.items ?? [];
  const location = useLocation();
  const currentRole = user?.role ? roleAliases[user.role] : undefined;
  const visibleNavItems = useMemo(
    () => navItems.filter((item) => !item.hidden && Boolean(currentRole && item.roles.includes(currentRole))),
    [currentRole]
  );

  const drawerWidth = collapsed && isDesktop ? collapsedWidth : expandedWidth;
  const currentTitle = useMemo(
    () => navItems.find((item) => item.path === location.pathname)?.label ?? 'Dashboard',
    [location.pathname]
  );
  const unreadCount = notificationItems.length - readNotifications.length;

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'auto' });
  }, [location.pathname]);

  const drawer = (
    <Box
      sx={{
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        background:
          theme.palette.mode === 'light'
            ? 'linear-gradient(145deg, #10141b 0%, #303640 38%, #171c24 68%, #32181b 100%)'
            : 'linear-gradient(145deg, #080b10 0%, #252b34 42%, #11151c 70%, #2a1114 100%)',
        boxShadow: 'inset -1px 0 0 rgba(255,255,255,.08), inset 0 1px 0 rgba(255,255,255,.05)',
        color: '#fff'
      }}
    >
      <Stack direction="row" alignItems="center" justifyContent={collapsed && isDesktop ? 'center' : 'flex-start'} spacing={1.1} sx={{ px: 2, height: 72 }}>
        <Box
          component="img"
          src={footLockerLogo}
          alt="Foot Locker"
          sx={{
            width: collapsed && isDesktop ? 44 : 48,
            height: collapsed && isDesktop ? 44 : 48,
            objectFit: 'contain',
            borderRadius: 2,
            bgcolor: '#ffffff',
            p: 0.25,
            filter: 'drop-shadow(0 10px 18px rgba(0,0,0,.24))',
            transition: 'width .25s ease, height .25s ease'
          }}
        />
        {(!collapsed || !isDesktop) && (
          <Box sx={{ minWidth: 0 }}>
            <Typography sx={{ fontSize: 18, fontWeight: 950, lineHeight: 1, color: '#ffffff' }}>Foot Locker</Typography>
            <Typography sx={{ mt: 0.4, fontSize: 11, fontWeight: 850, letterSpacing: 1.1, color: 'rgba(255,255,255,.66)' }}>GLOBAL APP OPS</Typography>
          </Box>
        )}
      </Stack>
      <Divider sx={{ borderColor: 'rgba(255,255,255,0.12)' }} />
      <List sx={{ px: 1.25, py: 2, flex: 1 }}>
        {visibleNavItems.map((item) => (
          <Tooltip key={item.path} title={collapsed && isDesktop ? item.label : ''} placement="right">
            <ListItemButton
              component={NavLink}
              to={item.path}
              onClick={() => {
                setMobileOpen(false);
                if (isDesktop) setCollapsed(true);
              }}
              sx={{
                minHeight: 48,
                borderRadius: 2,
                mb: 0.7,
                color: 'rgba(255,255,255,0.76)',
                '&.active': {
                  color: '#fff',
                  background: 'linear-gradient(180deg, #e03a40 0%, #bd181f 54%, #971319 100%)',
                  border: '1px solid rgba(255,255,255,.12)',
                  boxShadow: 'inset 0 1px 0 rgba(255,255,255,.26), 0 10px 22px rgba(130,12,18,.34)'
                },
                '&:hover': { bgcolor: 'rgba(255,255,255,0.11)', color: '#fff' }
              }}
            >
              <ListItemIcon sx={{ minWidth: 44, color: 'inherit' }}>{item.icon}</ListItemIcon>
              {(!collapsed || !isDesktop) && <ListItemText primary={item.label} primaryTypographyProps={{ fontSize: 15, fontWeight: 700 }} />}
            </ListItemButton>
          </Tooltip>
        ))}
      </List>
      <Box sx={{ p: 2, color: 'rgba(255,255,255,0.68)' }}>
        {collapsed && isDesktop ? (
          <Tooltip title="Expand menu" placement="right">
            <IconButton
              aria-label="Expand left menu"
              onClick={() => setCollapsed(false)}
              sx={{
                width: 42,
                height: 42,
                color: '#fff',
                bgcolor: 'rgba(255,255,255,.1)',
                border: '1px solid rgba(255,255,255,.18)',
                '&:hover': {
                  bgcolor: 'rgba(255,255,255,.18)'
                }
              }}
            >
              <KeyboardDoubleArrowRightIcon />
            </IconButton>
          </Tooltip>
        ) : (
          <Stack direction="row" spacing={1} alignItems="center" justifyContent="space-between">
            <Typography variant="caption">
              Enterprise OMS Control Center
            </Typography>
            {isDesktop && (
              <Tooltip title="Collapse menu" placement="top">
                <IconButton
                  aria-label="Collapse left menu"
                  onClick={() => setCollapsed(true)}
                  sx={{
                    width: 34,
                    height: 34,
                    color: '#fff',
                    bgcolor: 'rgba(255,255,255,.1)',
                    border: '1px solid rgba(255,255,255,.18)',
                    '&:hover': {
                      bgcolor: 'rgba(255,255,255,.18)'
                    }
                  }}
                >
                  <KeyboardDoubleArrowLeftIcon fontSize="small" />
                </IconButton>
              </Tooltip>
            )}
          </Stack>
        )}
      </Box>
    </Box>
  );

  return (
    <Box sx={{ minHeight: '100vh', width: '100%', maxWidth: '100vw', overflowX: 'clip', bgcolor: 'background.default' }}>
      <AppBar
        position="fixed"
        elevation={0}
        sx={{
          width: { lg: `calc(100% - ${drawerWidth}px)` },
          ml: { lg: `${drawerWidth}px` },
          borderBottom: `1px solid ${theme.palette.divider}`,
          background: theme.palette.mode === 'light'
            ? 'linear-gradient(180deg, rgba(255,255,255,.94) 0%, rgba(221,225,230,.92) 100%)'
            : 'linear-gradient(180deg, rgba(39,45,55,.94) 0%, rgba(21,25,32,.94) 100%)',
          color: 'text.primary',
          '&:before': {
            content: '""',
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            height: 3,
            background: 'linear-gradient(90deg, #d71920 0%, #f04449 34%, #111827 34%, #111827 66%, #d71920 66%, #9f1117 100%)'
          },
          backdropFilter: 'blur(18px)',
          boxShadow: 'inset 0 1px 0 rgba(255,255,255,.32), 0 5px 18px rgba(31,38,47,.12)',
          transition: theme.transitions.create(['width', 'margin-left'])
        }}
      >
        <Toolbar sx={{ gap: { xs: 0.8, md: 1.1 }, minHeight: { xs: 60, md: 64 }, minWidth: 0 }}>
          <IconButton onClick={() => (isDesktop ? setCollapsed((value) => !value) : setMobileOpen(true))}>
            <MenuIcon />
          </IconButton>
          <Box
            component="img"
            src={footLockerMark}
            alt="Foot Locker"
            sx={{
              width: 34,
              height: 34,
              objectFit: 'contain',
              borderRadius: 1.5,
              bgcolor: '#ffffff',
              p: 0.2,
              display: { xs: 'none', md: 'block', lg: collapsed ? 'block' : 'none' },
              filter: 'drop-shadow(0 6px 12px rgba(215,25,32,.18))'
            }}
          />
          <Box sx={{ minWidth: 0, flex: 1 }}>
            <Stack direction="row" alignItems="center" spacing={1} sx={{ minWidth: 0 }}>
              <Typography variant="h6" noWrap>
                Retail Order Management System
              </Typography>
              <Chip
                size="small"
                label="Foot Locker"
                sx={{
                  display: { xs: 'none', sm: 'inline-flex' },
                  height: 22,
                  fontWeight: 950,
                  color: '#fff',
                  bgcolor: '#d71920',
                  border: '1px solid rgba(255,255,255,.28)',
                  boxShadow: '0 5px 14px rgba(215,25,32,.22)'
                }}
              />
            </Stack>
            <Typography variant="caption" color="text.secondary" noWrap>
              {currentTitle} / Foot Locker global app operations
            </Typography>
          </Box>
          <Tooltip title="Notifications">
            <IconButton aria-label="Notifications" onClick={() => setNotificationsOpen(true)}>
              <Badge badgeContent={unreadCount} color="primary">
                <NotificationsIcon />
              </Badge>
            </IconButton>
          </Tooltip>
          <Tooltip title={mode === 'light' ? 'Switch to dark theme' : 'Switch to light theme'}>
            <IconButton onClick={toggleMode}>{mode === 'light' ? <DarkModeIcon /> : <LightModeIcon />}</IconButton>
          </Tooltip>
          <Stack
            component="button"
            onClick={(event) => setProfileAnchor(event.currentTarget)}
            direction="row"
            spacing={1}
            alignItems="center"
            sx={{
              minWidth: 0,
              border: 0,
              bgcolor: 'transparent',
              color: 'text.primary',
              cursor: 'pointer',
              display: { xs: 'none', sm: 'flex' }
            }}
          >
            <Avatar sx={{ width: 30, height: 30, bgcolor: 'primary.main', fontWeight: 800, fontSize: '0.82rem' }}>{user?.initials ?? 'FL'}</Avatar>
            <Box sx={{ textAlign: 'left' }}>
              <Typography variant="body2" fontWeight={800}>{user?.name ?? 'Azure SSO'}</Typography>
              <Typography variant="caption" color="text.secondary">{user?.role ?? 'Sign in required'}</Typography>
            </Box>
            <KeyboardArrowDownIcon fontSize="small" />
          </Stack>
          <Menu anchorEl={profileAnchor} open={Boolean(profileAnchor)} onClose={() => setProfileAnchor(null)}>
            <MenuItem>Profile</MenuItem>
            <MenuItem>Support Center</MenuItem>
            {authEnabled && !user && <MenuItem onClick={() => { setProfileAnchor(null); signIn(); }}>Sign in with Azure</MenuItem>}
            <MenuItem onClick={() => { setProfileAnchor(null); signOut(); }}>{authEnabled ? 'Sign out' : 'Reset dev session'}</MenuItem>
          </Menu>
        </Toolbar>
      </AppBar>

      <Drawer
        anchor="right"
        open={notificationsOpen}
        onClose={() => setNotificationsOpen(false)}
          PaperProps={{
            sx: {
              width: { xs: '100%', sm: 430 },
              maxWidth: '100vw',
              minWidth: 0,
              bgcolor: (currentTheme) => currentTheme.palette.mode === 'light' ? '#f4f6f9' : '#111821',
            borderLeft: 1,
            borderColor: 'divider'
          }
        }}
      >
        <Stack sx={{ height: '100%' }}>
          <Box sx={{ px: 2.5, py: 2.25, borderBottom: 1, borderColor: 'divider', bgcolor: (currentTheme) => alpha(currentTheme.palette.primary.main, 0.045) }}>
            <Stack direction="row" alignItems="center" justifyContent="space-between" spacing={1}>
              <Box>
                <Stack direction="row" spacing={1} alignItems="center">
                  <Typography variant="h6" fontWeight={900}>Notifications</Typography>
                  {unreadCount > 0 && <Chip size="small" label={`${unreadCount} unread`} color="primary" />}
                </Stack>
                <Typography variant="body2" color="text.secondary">Order and fulfillment events requiring awareness</Typography>
              </Box>
              <IconButton aria-label="Close notifications" onClick={() => setNotificationsOpen(false)}><CloseIcon /></IconButton>
            </Stack>
            <Button
              size="small"
              startIcon={<DoneAllIcon />}
              disabled={unreadCount === 0}
              onClick={() => setReadNotifications(notificationItems.map((item) => item.id))}
              sx={{ mt: 1.5 }}
            >
              Mark all as read
            </Button>
          </Box>

          <List disablePadding sx={{ flex: 1, overflowY: 'auto', p: 1.5 }}>
            {notificationItems.map((notification) => {
              const isRead = readNotifications.includes(notification.id);
              const color = notification.severity === 'Critical' ? 'error' : notification.severity === 'Resolved' ? 'success' : notification.severity === 'Warning' || notification.severity === 'Action' ? 'warning' : 'info';
              const Icon = notification.category === 'Inventory'
                ? Inventory2Icon
                : notification.category === 'Payment'
                  ? CreditCardIcon
                  : notification.category === 'Return'
                    ? AssignmentReturnIcon
                    : notification.category === 'Integration'
                      ? SyncProblemIcon
                      : LocalShippingIcon;
              return (
                <ListItemButton
                  key={notification.id}
                  alignItems="flex-start"
                  onClick={() => setReadNotifications((current) => current.includes(notification.id) ? current : [...current, notification.id])}
                  sx={{
                    px: 1.5,
                    py: 1.45,
                    gap: 1.5,
                    mb: 1.15,
                    border: 1,
                    borderColor: (currentTheme) => isRead ? alpha(currentTheme.palette.divider, 0.9) : alpha(currentTheme.palette.primary.main, 0.28),
                    borderRadius: 2,
                    color: 'text.primary',
                    bgcolor: (currentTheme) => isRead
                      ? currentTheme.palette.background.paper
                      : currentTheme.palette.mode === 'light'
                        ? '#fff7e8'
                        : alpha(currentTheme.palette.primary.main, 0.18),
                    boxShadow: (currentTheme) => isRead ? 'none' : `0 8px 20px ${alpha(currentTheme.palette.primary.main, 0.12)}`,
                    '&:hover': {
                      bgcolor: (currentTheme) => currentTheme.palette.mode === 'light' ? '#fff1d6' : alpha(currentTheme.palette.primary.main, 0.24)
                    }
                  }}
                >
                  <Box sx={{ width: 38, height: 38, flex: '0 0 auto', display: 'grid', placeItems: 'center', borderRadius: 1.5, color: `${color}.main`, bgcolor: (currentTheme) => alpha(currentTheme.palette[color].main, 0.1) }}>
                    <Icon fontSize="small" />
                  </Box>
                  <ListItemText
                    sx={{ m: 0 }}
                    secondaryTypographyProps={{ component: 'div' }}
                    primary={
                      <Stack direction="row" justifyContent="space-between" alignItems="flex-start" spacing={1}>
                        <Typography fontWeight={isRead ? 750 : 900} color="text.primary">{notification.title}</Typography>
                        {!isRead && <Chip size="small" label="New" color="primary" variant="outlined" />}
                      </Stack>
                    }
                    secondary={
                      <Box sx={{ mt: 0.5 }}>
                        <Typography variant="body2" color="text.secondary">{notification.message}</Typography>
                        <Stack direction="row" spacing={1} alignItems="center" sx={{ mt: 1 }}>
                          <Chip size="small" label={notification.severity} color={color} variant="outlined" />
                          <Typography variant="caption" color="text.secondary">{notification.time}</Typography>
                        </Stack>
                      </Box>
                    }
                  />
                </ListItemButton>
              );
            })}
          </List>

          <Box sx={{ p: 2, borderTop: 1, borderColor: 'divider' }}>
            <Button component={NavLink} to="/settings" fullWidth variant="outlined" onClick={() => setNotificationsOpen(false)}>
              Notification Settings
            </Button>
          </Box>
        </Stack>
      </Drawer>

      <Box component="nav">
        <Drawer
          variant={isDesktop ? 'permanent' : 'temporary'}
          open={isDesktop || mobileOpen}
          onClose={() => setMobileOpen(false)}
          PaperProps={{ sx: { width: drawerWidth, overflowX: 'hidden', transition: theme.transitions.create('width') } }}
        >
          <motion.div animate={{ width: drawerWidth }} transition={{ duration: 0.22 }}>
            {drawer}
          </motion.div>
        </Drawer>
      </Box>

      <Box
        component="main"
        sx={{
          ml: { lg: `${drawerWidth}px` },
          pt: { xs: '74px', md: '80px' },
          px: { xs: 1, sm: 1.5, md: 1.75, xl: 2.5 },
          pb: 8,
          minHeight: '100vh',
          minWidth: 0,
          width: { xs: '100%', lg: `calc(100% - ${drawerWidth}px)` },
          maxWidth: '100vw',
          overflowX: 'clip',
          transition: theme.transitions.create('margin-left')
        }}
      >
        {children}
      </Box>
      <Box
        component="footer"
        sx={{
          position: 'fixed',
          bottom: 0,
          right: 0,
          left: { xs: 0, lg: `${drawerWidth}px` },
          px: { xs: 1.25, sm: 2, md: 2.5 },
          py: { xs: 0.75, md: 1 },
          display: 'flex',
          flexWrap: 'wrap',
          justifyContent: 'space-between',
          gap: { xs: 0.5, sm: 2 },
          background: theme.palette.mode === 'light'
            ? 'linear-gradient(180deg, rgba(250,251,252,.92), rgba(221,225,230,.94))'
            : 'linear-gradient(180deg, rgba(34,40,49,.94), rgba(20,24,31,.96))',
          borderTop: `1px solid ${theme.palette.divider}`,
          backdropFilter: 'blur(16px)',
          boxShadow: 'inset 0 1px 0 rgba(255,255,255,.24)',
          transition: theme.transitions.create('left'),
          zIndex: theme.zIndex.appBar - 1
        }}
      >
        <Stack direction="row" spacing={1} alignItems="center" sx={{ minWidth: 0 }}>
          <Box component="img" src={footLockerMark} alt="Foot Locker" sx={{ width: 20, height: 20, objectFit: 'contain', borderRadius: 0.75, bgcolor: '#fff' }} />
          <Typography variant="caption" color="text.secondary" noWrap>Copyright Foot Locker</Typography>
        </Stack>
        <Typography variant="caption" color="text.secondary" sx={{ whiteSpace: 'nowrap' }}>Version 2.8.4 / Environment DEV</Typography>
      </Box>
    </Box>
  );
}
