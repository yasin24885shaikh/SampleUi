import { Box, Stack, Typography } from '@mui/material';
import { motion } from 'framer-motion';
import TrendingUpIcon from '@mui/icons-material/TrendingUp';
import TrendingDownIcon from '@mui/icons-material/TrendingDown';
import { alpha } from '@mui/material/styles';
import GlassCard from './GlassCard';

type KpiCardProps = {
  label: string;
  value: string;
  delta: string;
  tone?: string;
};

export default function KpiCard({ label, value, delta, tone = '#d71920' }: KpiCardProps) {
  const trendingDown = delta.trim().startsWith('-');
  const needsAttention = (label === 'Open Orders' && !trendingDown) || (label === 'Cancelled Orders' && !trendingDown);
  const TrendIcon = trendingDown ? TrendingDownIcon : TrendingUpIcon;

  return (
    <motion.div whileHover={{ y: -4 }} transition={{ duration: 0.18 }} style={{ height: '100%' }}>
      <GlassCard sx={{ p: 2, minHeight: 136, height: '100%', overflow: 'hidden', position: 'relative', borderTop: `3px solid ${tone}` }}>
        <Stack spacing={1.15}>
          <Stack direction="row" justifyContent="space-between" alignItems="center" spacing={1}>
            <Typography color="text.secondary" fontWeight={800} variant="body2" title={label} sx={{ minHeight: 34, display: 'flex', alignItems: 'center', lineHeight: 1.2 }}>
              {label}
            </Typography>
            <Box sx={{ width: 30, height: 30, flex: '0 0 auto', borderRadius: 1.5, display: 'grid', placeItems: 'center', color: tone, bgcolor: alpha(tone, 0.1) }}>
              <TrendIcon sx={{ fontSize: 18 }} />
            </Box>
          </Stack>
          <Typography variant="h4" fontWeight={900}>{value}</Typography>
          <Typography variant="body2" fontWeight={800} color={needsAttention ? 'error.main' : 'success.main'}>
            {delta}
          </Typography>
        </Stack>
      </GlassCard>
    </motion.div>
  );
}
