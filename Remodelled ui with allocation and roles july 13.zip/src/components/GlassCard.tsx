import { Card, CardProps } from '@mui/material';
import { alpha, useTheme } from '@mui/material/styles';

export default function GlassCard({ sx, ...props }: CardProps) {
  const theme = useTheme();

  return (
    <Card
      {...props}
      sx={{
        backdropFilter: 'blur(18px)',
        background:
          theme.palette.mode === 'light'
            ? 'linear-gradient(145deg, rgba(255,255,255,.94) 0%, rgba(232,236,240,.9) 54%, rgba(249,250,251,.92) 100%)'
            : 'linear-gradient(145deg, rgba(38,44,54,.9) 0%, rgba(23,28,36,.9) 56%, rgba(31,36,45,.88) 100%)',
        boxShadow:
          theme.palette.mode === 'light'
            ? `inset 0 1px 0 ${alpha('#ffffff', 0.95)}, 0 12px 30px ${alpha('#303842', 0.12)}, 0 2px 5px ${alpha('#303842', 0.08)}`
            : `inset 0 1px 0 ${alpha('#ffffff', 0.06)}, 0 16px 34px ${alpha('#000000', 0.36)}`,
        ...sx
      }}
    />
  );
}
