import { Alert, Box, Button, Skeleton, Stack } from '@mui/material';
import RefreshIcon from '@mui/icons-material/Refresh';
import GlassCard from './GlassCard';

export function ApiLoading({ rows = 4 }: { rows?: number }) {
  return (
    <GlassCard sx={{ p: 2.5 }}>
      <Stack spacing={1.25}>
        <Skeleton variant="rounded" width="32%" height={26} />
        {Array.from({ length: rows }, (_, index) => (
          <Skeleton key={index} variant="rounded" width={`${96 - index * 4}%`} height={46} />
        ))}
      </Stack>
    </GlassCard>
  );
}

export function ApiErrorState({ message, onRetry }: { message?: string; onRetry: () => void }) {
  return (
    <Box sx={{ mb: 2 }}>
      <Alert severity="error" action={<Button color="inherit" size="small" startIcon={<RefreshIcon />} onClick={onRetry}>Retry</Button>}>
        {message || 'The OMS service could not be reached.'}
      </Alert>
    </Box>
  );
}
