import { Chip, ChipProps } from '@mui/material';
import { statusColor } from '../utils/status';

export default function StatusChip({ label, ...props }: { label: string } & Omit<ChipProps, 'label'>) {
  return <Chip size="small" label={label} color={statusColor[label] ?? 'default'} variant="filled" {...props} />;
}
