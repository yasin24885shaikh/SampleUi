import { apiClient, apiConfiguration } from './apiClient';
import {
  activities, alerts, bannerPerformance, dailyOrderVolume, dashboardKpis, exceptionTrend,
  fulfillmentMix, inventoryRows, inventoryTrend, nodePerformance, orders, ordersByStatus,
  productCatalog, returnTrend, serviceLevelTrend, users, type Order
} from './mockData';

export type InventoryItem = (typeof inventoryRows)[number];
export type Product = (typeof productCatalog)[number];
export type OmsUser = (typeof users)[number];
export type AddUserRequest = {
  userId: string;
  firstName: string;
  lastName: string;
  role: string;
  permissions: string;
  status: string;
  reason: string;
};
export type UpdateUserAccessRequest = {
  role?: string;
  permissions?: string;
  reason?: string;
};
export type UpdateUserStatusRequest = {
  status: string;
  reason?: string;
};
export type UpdateStoreConfigurationRequest = {
  region: string;
  shipStatus?: string;
  pickStatus?: string;
};

export type CollectionResponse<T> = { items: T[]; total: number; page: number; pageSize: number };
export type DashboardResponse = {
  kpis: typeof dashboardKpis;
  ordersByStatus: typeof ordersByStatus;
  fulfillmentMix: typeof fulfillmentMix;
  inventoryTrend: typeof inventoryTrend;
  dailyOrderVolume: typeof dailyOrderVolume;
  serviceLevelTrend: typeof serviceLevelTrend;
  exceptionTrend: typeof exceptionTrend;
  bannerPerformance: typeof bannerPerformance;
  nodePerformance: typeof nodePerformance;
  returnTrend: typeof returnTrend;
  activities: typeof activities;
  alerts: typeof alerts;
  refreshedAt: string;
};
export type InventoryResponse = CollectionResponse<InventoryItem> & { trend: typeof inventoryTrend };
export type SkuDocumentationResponse = { product: Product; sections: Array<{ title: string; lines: string[] }> };
export type Notification = { id: string; category: string; severity: string; title: string; message: string; time: string };
export type NotificationResponse = { items: Notification[]; total: number };
export type AiIconKey = 'factCheck' | 'open' | 'hourglass' | 'inventory' | 'shipping' | 'warehouse' | 'dropship' | 'store' | 'timeline' | 'bolt' | 'psychology' | 'insights';
export type OrderStatusAiNode = {
  key: string;
  title: string;
  description: string;
  volume: number;
  stuck: number;
  avgAge: string;
  sla: string;
  accent: string;
  iconKey: AiIconKey;
};
export type OrderStatusAiFulfillmentPath = {
  title: string;
  subtitle: string;
  volume: number;
  stuck: number;
  accent: string;
  iconKey: AiIconKey;
  children?: OrderStatusAiFulfillmentPath[];
  insight: OrderStatusAiTransitionInsight;
};
export type OrderStatusAiStuckOrder = {
  orderId: string;
  currentStatus: string;
  age: string;
  fulfillmentNode: string;
  reason: string;
  probableResolution: string;
  confidence: number;
};
export type OrderStatusAiTransitionInsight = {
  from: string;
  to: string;
  headline: string;
  details: string[];
  stuckOrders: OrderStatusAiStuckOrder[];
};
export type OrderStatusAiCapabilityCard = {
  title: string;
  value: string;
  subtitle: string;
  tone: string;
  iconKey: AiIconKey;
};
export type OrderStatusAiBottleneck = { lane: string; risk: number; orders: number; driver: string };
export type OrderStatusAiRootCause = { name: string; orders: number; confidence: number; resolution: string };
export type OrderStatusAiRecommendedAction = { action: string; impact: string; owner: string; urgency: 'High' | 'Medium' | 'Low' };
export type OrderStatusAiAnalyticsResponse = {
  lifecycleNodes: OrderStatusAiNode[];
  fulfillmentGroups: OrderStatusAiFulfillmentPath[];
  transitionInsights: OrderStatusAiTransitionInsight[];
  aiCapabilityCards: OrderStatusAiCapabilityCard[];
  bottleneckRankings: OrderStatusAiBottleneck[];
  rootCauseClusters: OrderStatusAiRootCause[];
  recommendedActions: OrderStatusAiRecommendedAction[];
  refreshedAt: string;
};
export type OrderQuery = {
  page?: number;
  pageSize?: number;
  orderType?: 'customer' | 'nonCustomer' | 'all';
  orderNumbers?: string[];
  sku?: string;
  statuses?: string[];
  orderDateFrom?: string;
  orderDateTo?: string;
  fulfillmentType?: string;
  banner?: string;
  search?: string;
};
type OrderDetailsRequest = { orderIds: string[] };
type OrderDetailsEnvelope = {
  items?: Order[];
  orders?: Order[];
  data?: Order[] | CollectionResponse<Order>;
  total?: number;
  page?: number;
  pageSize?: number;
};
type OrderDetailsResponse = CollectionResponse<Order> | Order[] | OrderDetailsEnvelope;

const dashboardMock: DashboardResponse = {
  kpis: dashboardKpis, ordersByStatus, fulfillmentMix, inventoryTrend, dailyOrderVolume,
  serviceLevelTrend, exceptionTrend, bannerPerformance, nodePerformance, returnTrend,
  activities, alerts, refreshedAt: '2026-06-24T10:42:00-05:00'
};

const notificationsMock: Notification[] = [
  { id: 'inventory', category: 'Inventory', severity: 'Critical', title: 'Inventory threshold breached', message: 'BB550VTA is unavailable at PHX-DC-02 and 18 orders are at allocation risk.', time: '4 min ago' },
  { id: 'release', category: 'Release', severity: 'Action', title: 'Warehouse release exception', message: 'REL-900211 has remained in Awaiting Inventory beyond the fulfillment SLA.', time: '12 min ago' },
  { id: 'supplier', category: 'Integration', severity: 'Warning', title: 'Supplier ASN feed delayed', message: 'ADI-US acknowledgements are running 22 minutes behind the expected cadence.', time: '28 min ago' },
  { id: 'payment', category: 'Payment', severity: 'Review', title: 'Payment authorization review', message: 'Six high-value launch orders require renewed authorization before release.', time: '41 min ago' },
  { id: 'return', category: 'Return', severity: 'Update', title: 'Return backlog improving', message: 'Open return inspections declined 14% after the latest processing cycle.', time: '1 hr ago' },
  { id: 'sync', category: 'Integration', severity: 'Resolved', title: 'Store inventory sync complete', message: 'Inventory positions were refreshed successfully across 1,284 stores.', time: '2 hr ago' },
  { id: 'carrier', category: 'Shipment', severity: 'Advisory', title: 'Carrier weather advisory', message: 'UPS Ground shipments from the Midwest may experience a one-day delay.', time: '3 hr ago' }
];

const skuDocumentationMock: SkuDocumentationResponse = {
  product: productCatalog[0],
  sections: [
    { title: 'SKU Details', lines: ['Category: Running', 'Colorway: White / Metallic Silver', 'Size Curve: Men 7-14', 'Lifecycle: Active'] },
    { title: 'Vendor Information', lines: ['Vendor: Nike', 'Vendor SKU: FV5029-141', 'Country of Origin: Vietnam', 'Compliance: Approved'] },
    { title: 'Packaging Details', lines: ['Box Type: Standard footwear', 'Each Weight: 2.4 lb', 'Case Pack: 12', 'Hazmat: No'] },
    { title: 'Shipping Constraints', lines: ['Ship Methods: Ground, 2-Day, Pickup', 'Launch Hold: No', 'Store Eligible: Yes', 'Supplier Direct: Eligible'] }
  ]
};

const orderStatusAiAnalyticsMock: OrderStatusAiAnalyticsResponse = {
  lifecycleNodes: [
    { key: 'submitted', title: 'Submitted', description: 'Orders landed from digital, store, and enterprise intake channels.', volume: 18420, stuck: 112, avgAge: '14 min', sla: '< 30 min', accent: '#1769e0', iconKey: 'factCheck' },
    { key: 'open', title: 'Open', description: 'Orders validated, payment checked, and ready for allocation.', volume: 17208, stuck: 284, avgAge: '42 min', sla: '< 60 min', accent: '#117c8b', iconKey: 'open' },
    { key: 'backordered', title: 'Backordered', description: 'Demand waiting for replenishment or alternate sourcing.', volume: 1946, stuck: 418, avgAge: '18 hr', sla: '< 12 hr', accent: '#c62828', iconKey: 'hourglass' },
    { key: 'allocated', title: 'Allocated', description: 'Inventory reserved and fulfillment path selected.', volume: 15392, stuck: 136, avgAge: '27 min', sla: '< 45 min', accent: '#7c3aed', iconKey: 'inventory' },
    { key: 'released', title: 'Released', description: 'Release payload sent to warehouse, store, supplier, or dropship node.', volume: 14984, stuck: 229, avgAge: '1.6 hr', sla: '< 2 hr', accent: '#e77718', iconKey: 'shipping' }
  ],
  transitionInsights: [
    {
      from: 'Submitted',
      to: 'Open',
      headline: 'Payment authorization and address validation are the primary delay drivers.',
      details: ['112 orders held beyond 30 minutes', '64% tied to payment retry events', '27% need customer identity or address review'],
      stuckOrders: [
        { orderId: 'FL-10048291', currentStatus: 'Submitted', age: '46 min', fulfillmentNode: 'OMS Intake', reason: 'Payment authorization retry exceeded normal threshold', probableResolution: 'Trigger payment auth refresh and retry fraud score handoff', confidence: 92 },
        { orderId: 'FL-10048307', currentStatus: 'Submitted', age: '39 min', fulfillmentNode: 'OMS Intake', reason: 'Shipping address validation pending third-party response', probableResolution: 'Send address verification task to customer care queue', confidence: 88 },
        { orderId: 'FL-10048355', currentStatus: 'Submitted', age: '52 min', fulfillmentNode: 'OMS Intake', reason: 'Identity review hold from risk service', probableResolution: 'Escalate identity review and release after confirmed profile match', confidence: 84 }
      ]
    },
    {
      from: 'Open',
      to: 'Backordered',
      headline: 'Size-level inventory gaps are concentrating in launch footwear.',
      details: ['284 open orders are aging near SLA', 'Men 10-12 accounts for 41% of exposure', 'AI recommends alternate node lookup every 15 minutes'],
      stuckOrders: [
        { orderId: 'FL-10048902', currentStatus: 'Open', age: '1.4 hr', fulfillmentNode: 'Allocation Engine', reason: 'No ATP match for primary SKU and size curve', probableResolution: 'Run alternate node lookup and allow split sourcing', confidence: 91 },
        { orderId: 'FL-10048944', currentStatus: 'Open', age: '1.1 hr', fulfillmentNode: 'Allocation Engine', reason: 'Promised node has insufficient safety-stock buffer', probableResolution: 'Relax safety stock for launch priority or move to backorder queue', confidence: 86 },
        { orderId: 'FL-10049018', currentStatus: 'Open', age: '1.8 hr', fulfillmentNode: 'Allocation Engine', reason: 'Inventory reservation service returned partial allocation', probableResolution: 'Split line and reserve available units at JC WHSE', confidence: 89 }
      ]
    },
    {
      from: 'Backordered',
      to: 'Allocated',
      headline: 'Backorder recovery is slower where replenishment ETA is missing.',
      details: ['418 backordered orders are SLA exceptions', 'JC and Camp Hill have recoverable supply in adjacent sizes', 'AI recommends split allocation for 76 multi-line orders'],
      stuckOrders: [
        { orderId: 'FL-10050024', currentStatus: 'Backordered', age: '22 hr', fulfillmentNode: 'JC WHSE', reason: 'Replenishment ETA missing for backordered launch SKU', probableResolution: 'Request replenishment ETA and enable split allocation for non-launch lines', confidence: 94 },
        { orderId: 'FL-10050031', currentStatus: 'Backordered', age: '19 hr', fulfillmentNode: 'Camp Hill WHSE', reason: 'Backorder pool not refreshed after inbound receipt', probableResolution: 'Refresh backorder pool and rerun allocation wave', confidence: 90 },
        { orderId: 'FL-10050044', currentStatus: 'Backordered', age: '15 hr', fulfillmentNode: 'Reno WHSE', reason: 'Size substitution rule blocked adjacent inventory candidate', probableResolution: 'Review substitution rule and release eligible alternate size offer', confidence: 81 }
      ]
    },
    {
      from: 'Allocated',
      to: 'Released',
      headline: 'Allocated orders are mostly healthy, with some release payload retry risk.',
      details: ['136 allocated orders are older than target', 'Supplier direct has the highest retry rate', 'AI recommends release re-publish for 38 orders'],
      stuckOrders: [
        { orderId: 'FL-10050102', currentStatus: 'Allocated', age: '58 min', fulfillmentNode: 'Milton WHSE', reason: 'Release payload acknowledgement not received', probableResolution: 'Re-publish release payload and confirm node acknowledgement', confidence: 93 },
        { orderId: 'FL-10050116', currentStatus: 'Allocated', age: '1.2 hr', fulfillmentNode: 'Supplier Direct', reason: 'Supplier routing profile missing ship method', probableResolution: 'Patch supplier routing profile and re-release', confidence: 87 },
        { orderId: 'FL-10050149', currentStatus: 'Allocated', age: '49 min', fulfillmentNode: 'Store Fulfillment', reason: 'Store pick wave capacity reached', probableResolution: 'Move release to next store wave or reroute to warehouse', confidence: 85 }
      ]
    },
    {
      from: 'Released',
      to: 'Fulfilled',
      headline: 'Released-order aging is concentrated in dropship acknowledgements and store pick waves.',
      details: ['229 released orders need review', 'Dropship ASN lag is 31 minutes above plan', 'AI recommends status sync for 74 release lines'],
      stuckOrders: [
        { orderId: 'FL-10049999', currentStatus: 'Released', age: '2.4 hr', fulfillmentNode: 'Dropship', reason: 'Supplier ASN acknowledgement delayed', probableResolution: 'Send supplier status sync and re-request ASN acknowledgement', confidence: 95 },
        { orderId: 'FL-10050222', currentStatus: 'Released', age: '2.1 hr', fulfillmentNode: 'Store', reason: 'Pick confirmation missing after wave close', probableResolution: 'Sync store pick status and escalate to store ops if still open', confidence: 89 },
        { orderId: 'FL-10050240', currentStatus: 'Released', age: '2.8 hr', fulfillmentNode: 'Camp Hill WHSE', reason: 'Package label created but shipment event missing', probableResolution: 'Run carrier manifest reconciliation and sync shipment status', confidence: 91 }
      ]
    }
  ],
  fulfillmentGroups: [
    {
      title: 'Warehouse',
      subtitle: 'Distribution center release execution',
      volume: 13136,
      stuck: 157,
      accent: '#1769e0',
      iconKey: 'warehouse',
      children: [
        { title: 'Milton WHSE', subtitle: 'Canada/east regional DC', volume: 2104, stuck: 28, accent: '#0f766e', iconKey: 'warehouse', insight: { from: 'Milton WHSE', to: 'Fulfilled', headline: '', details: [], stuckOrders: [] } },
        { title: 'JC WHSE', subtitle: 'Core DC release execution', volume: 4320, stuck: 42, accent: '#1769e0', iconKey: 'warehouse', insight: { from: 'JC WHSE', to: 'Fulfilled', headline: '', details: [], stuckOrders: [] } },
        { title: 'Reno WHSE', subtitle: 'West coast DC flow', volume: 3188, stuck: 36, accent: '#117c8b', iconKey: 'warehouse', insight: { from: 'Reno WHSE', to: 'Fulfilled', headline: '', details: [], stuckOrders: [] } },
        { title: 'Camp Hill WHSE', subtitle: 'East coast DC flow', volume: 3524, stuck: 51, accent: '#7c3aed', iconKey: 'warehouse', insight: { from: 'Camp Hill WHSE', to: 'Fulfilled', headline: '', details: [], stuckOrders: [] } }
      ],
      insight: {
        from: 'Released to Warehouse',
        to: 'Fulfilled',
        headline: 'Warehouse AI analysis found 157 stuck released orders across 13,136 released records.',
        details: ['Warehouse stuck rate is 1.2% for the selected order window', 'Primary node scope: Milton WHSE, JC WHSE, Reno WHSE, Camp Hill WHSE', 'AI recommends node heartbeat, manifest reconciliation, and targeted reroute for stale release lines'],
        stuckOrders: [
          { orderId: 'FL-WHSE-50280', currentStatus: 'Released', age: '2.2 hr', fulfillmentNode: 'Milton WHSE', reason: 'Release acknowledgement is aging near node SLA', probableResolution: 'Republish node release payload and verify acknowledgement heartbeat', confidence: 86 },
          { orderId: 'FL-WHSE-50281', currentStatus: 'Released', age: '1.9 hr', fulfillmentNode: 'JC WHSE', reason: 'Package label or shipment event is lagging after release acknowledgement', probableResolution: 'Run shipment status sync, reconcile manifest, then reroute stale release lines', confidence: 92 },
          { orderId: 'FL-WHSE-50282', currentStatus: 'Released', age: '2.7 hr', fulfillmentNode: 'Reno WHSE', reason: 'Release acknowledgement is aging near node SLA', probableResolution: 'Republish node release payload and verify acknowledgement heartbeat', confidence: 86 }
        ]
      }
    },
    {
      title: 'Dropship',
      subtitle: 'Supplier direct shipment',
      volume: 560,
      stuck: 50,
      accent: '#b45309',
      iconKey: 'dropship',
      insight: {
        from: 'Released to Dropship',
        to: 'Fulfilled',
        headline: 'Dropship AI analysis found 50 stuck released orders across 560 released records.',
        details: ['Dropship stuck rate is 8.9% for the selected order window', 'Primary node scope: Dropship', 'AI recommends status sync first, then reroute only records still missing fulfillment movement'],
        stuckOrders: [
          { orderId: 'FL-DROPSHIP-50311', currentStatus: 'Released', age: '2.6 hr', fulfillmentNode: 'Dropship', reason: 'Supplier ASN acknowledgement delayed beyond expected carrier handoff', probableResolution: 'Trigger supplier status sync and re-request ASN acknowledgement', confidence: 95 },
          { orderId: 'FL-DROPSHIP-50348', currentStatus: 'Released', age: '2.1 hr', fulfillmentNode: 'Dropship', reason: 'Carrier tracking number is pending supplier handoff', probableResolution: 'Queue ASN retry and confirm supplier routing profile', confidence: 91 }
        ]
      }
    },
    {
      title: 'Store',
      subtitle: 'Ship-from-store and pickup',
      volume: 1288,
      stuck: 22,
      accent: '#168a51',
      iconKey: 'store',
      insight: {
        from: 'Released to Store',
        to: 'Fulfilled',
        headline: 'Store AI analysis found 22 stuck released orders across 1,288 released records.',
        details: ['Store stuck rate is 1.7% for the selected order window', 'Primary node scope: Store', 'AI recommends status sync first, then reroute only records still missing fulfillment movement'],
        stuckOrders: [
          { orderId: 'FL-STORE-50311', currentStatus: 'Released', age: '1.8 hr', fulfillmentNode: 'Store', reason: 'Pick confirmation or shipment status has not posted after release', probableResolution: 'Sync node status and escalate remaining misses to store operations', confidence: 88 },
          { orderId: 'FL-STORE-50348', currentStatus: 'Released', age: '1.4 hr', fulfillmentNode: 'Store', reason: 'Node capacity signal indicates release is waiting for next pick wave', probableResolution: 'Move eligible releases to next wave or reroute to alternate node', confidence: 84 }
        ]
      }
    }
  ],
  aiCapabilityCards: [
    { title: 'Predictive SLA Risk', value: '1,179', subtitle: 'orders likely to breach in next 4 hours', tone: '#c62828', iconKey: 'timeline' },
    { title: 'Auto-Resolution Candidates', value: '438', subtitle: 'can be resolved by sync, retry, or reallocation', tone: '#168a51', iconKey: 'bolt' },
    { title: 'Root Cause Confidence', value: '91%', subtitle: 'weighted confidence across detected issues', tone: '#1769e0', iconKey: 'psychology' },
    { title: 'Estimated Revenue Protected', value: '$642K', subtitle: 'if recommended actions are executed today', tone: '#7c3aed', iconKey: 'insights' }
  ],
  bottleneckRankings: [
    { lane: 'Backordered → Allocated', risk: 94, orders: 418, driver: 'Missing replenishment ETA and stale backorder pool' },
    { lane: 'Released → Fulfilled', risk: 88, orders: 229, driver: 'Supplier ASN lag and store pick confirmation gaps' },
    { lane: 'Open → Backordered', risk: 81, orders: 284, driver: 'ATP mismatch for launch footwear sizes' },
    { lane: 'Allocated → Released', risk: 64, orders: 136, driver: 'Release payload acknowledgement retry risk' }
  ],
  rootCauseClusters: [
    { name: 'Inventory / ATP mismatch', orders: 371, confidence: 93, resolution: 'Run alternate-node allocation and split eligible multi-line orders' },
    { name: 'Supplier acknowledgement delay', orders: 156, confidence: 89, resolution: 'Trigger supplier status sync and ASN retry workflow' },
    { name: 'Payment and fraud validation', orders: 112, confidence: 92, resolution: 'Refresh authorization and route high-risk holds to review queue' },
    { name: 'Store pick wave capacity', orders: 74, confidence: 86, resolution: 'Move eligible releases to next wave or reroute to nearby node' }
  ],
  recommendedActions: [
    { action: 'Re-run allocation for high-priority backorders', impact: 'Recover 126 orders', owner: 'Allocation Ops', urgency: 'High' },
    { action: 'Sync supplier ASN status for dropship releases', impact: 'Clear 74 release lines', owner: 'Integration Ops', urgency: 'High' },
    { action: 'Republish release payloads without acknowledgement', impact: 'Resolve 38 orders', owner: 'OMS Support', urgency: 'Medium' },
    { action: 'Escalate address and fraud review holds', impact: 'Release 31 orders', owner: 'Customer Care', urgency: 'Medium' }
  ],
  refreshedAt: '2026-06-30T09:18:00-05:00'
};

function mockResponse<T>(payload: T, signal?: AbortSignal, delay = 320): Promise<T> {
  return new Promise((resolve, reject) => {
    const timeoutId = window.setTimeout(() => resolve(payload), delay);
    signal?.addEventListener('abort', () => {
      window.clearTimeout(timeoutId);
      reject(new DOMException('Request aborted', 'AbortError'));
    }, { once: true });
  });
}

function collection<T>(items: T[], page = 1, pageSize = items.length): CollectionResponse<T> {
  return { items, total: items.length, page, pageSize };
}

function isNonCustomerOrder(order: Order) {
  const normalizedCustomer = order.customerName.toLowerCase();
  const normalizedOrderType = order.orderType.toLowerCase();
  return normalizedCustomer.includes('enterprise bulk')
    || normalizedCustomer.includes('enterprise')
    || normalizedOrderType.includes('enterprise')
    || normalizedOrderType.includes('bulk')
    || normalizedOrderType.includes('transfer')
    || normalizedOrderType.includes('replenishment');
}

function searchOrders(query: OrderQuery) {
  const normalizedSearch = query.search?.trim().toLowerCase();
  const filtered = orders
    .filter((order) => {
      if (!query.orderType || query.orderType === 'all') return true;
      return query.orderType === 'nonCustomer' ? isNonCustomerOrder(order) : !isNonCustomerOrder(order);
    })
    .filter((order) => !query.orderNumbers?.length || query.orderNumbers.includes(order.orderNumber))
    .filter((order) => !query.sku || order.releases.some((release) => release.sku.toLowerCase().includes(query.sku!.toLowerCase())))
    .filter((order) => !query.statuses?.length || query.statuses.includes(order.status))
    .filter((order) => !query.orderDateFrom || order.orderDate >= query.orderDateFrom)
    .filter((order) => !query.orderDateTo || order.orderDate <= query.orderDateTo)
    .filter((order) => !query.fulfillmentType || order.fulfillmentType === query.fulfillmentType)
    .filter((order) => !query.banner || order.organization === query.banner)
    .filter((order) => {
      if (!normalizedSearch) return true;
      return [
        order.orderNumber,
        order.customerName,
        order.customerEmail,
        order.status,
        order.organization,
        order.orderType,
        ...order.releases.map((release) => `${release.lineNumber} ${release.sku} ${release.productName} ${release.currentStatus}`),
        ...order.releases.map((release) => `${release.releaseNumber} ${release.releaseLineId} ${release.assignedNode} ${release.assignedNodeType}`),
        ...order.fulfillments.map((fulfillment) => `${fulfillment.fulfillmentId} ${fulfillment.nodeId} ${fulfillment.nodeName} ${fulfillment.trackingNumber}`)
      ].join(' ').toLowerCase().includes(normalizedSearch);
    });
  const page = query.page ?? 1;
  const pageSize = query.pageSize ?? filtered.length;
  const start = (page - 1) * pageSize;
  return { items: filtered.slice(start, start + pageSize), total: filtered.length, page, pageSize };
}

function buildOrderDetailsRequest(query: OrderQuery): OrderDetailsRequest {
  const orderIds = query.orderNumbers?.filter(Boolean) ?? [];
  return { orderIds: orderIds.length ? orderIds : [''] };
}

function normalizeOrderDetailsResponse(payload: OrderDetailsResponse, query: OrderQuery): CollectionResponse<Order> {
  if (Array.isArray(payload)) {
    return collection(payload, query.page ?? 1, query.pageSize ?? payload.length);
  }

  const response = payload as OrderDetailsEnvelope;

  if (Array.isArray(response.data)) {
    return collection(response.data, response.page ?? query.page ?? 1, response.pageSize ?? query.pageSize ?? response.data.length);
  }

  if (response.data && !Array.isArray(response.data) && Array.isArray(response.data.items)) {
    return {
      items: response.data.items,
      total: response.data.total ?? response.data.items.length,
      page: response.data.page ?? query.page ?? 1,
      pageSize: response.data.pageSize ?? query.pageSize ?? response.data.items.length
    };
  }

  const items = response.items ?? response.orders ?? [];
  return {
    items,
    total: response.total ?? items.length,
    page: response.page ?? query.page ?? 1,
    pageSize: response.pageSize ?? query.pageSize ?? items.length
  };
}

export const omsApi = {
  getDashboard: (signal?: AbortSignal) => apiConfiguration.useMockApi
    ? mockResponse(dashboardMock, signal) : apiClient.get<DashboardResponse>('/dashboard', { signal }),
  getDashboardKpis: (signal?: AbortSignal) => apiConfiguration.useMockApi
    ? mockResponse({ items: dashboardKpis, refreshedAt: dashboardMock.refreshedAt }, signal) : apiClient.get<{ items: typeof dashboardKpis; refreshedAt: string }>('/dashboard/kpis', { signal }),
  getDashboardOrderPortfolio: (signal?: AbortSignal) => apiConfiguration.useMockApi
    ? mockResponse({ items: ordersByStatus }, signal) : apiClient.get<{ items: typeof ordersByStatus }>('/dashboard/order-portfolio', { signal }),
  getDashboardDemandVolume: (signal?: AbortSignal) => apiConfiguration.useMockApi
    ? mockResponse({ items: dailyOrderVolume }, signal) : apiClient.get<{ items: typeof dailyOrderVolume }>('/dashboard/demand-volume', { signal }),
  getDashboardServiceLevels: (signal?: AbortSignal) => apiConfiguration.useMockApi
    ? mockResponse({ items: serviceLevelTrend }, signal) : apiClient.get<{ items: typeof serviceLevelTrend }>('/dashboard/service-levels', { signal }),
  getDashboardFulfillmentMix: (signal?: AbortSignal) => apiConfiguration.useMockApi
    ? mockResponse({ items: fulfillmentMix }, signal) : apiClient.get<{ items: typeof fulfillmentMix }>('/dashboard/fulfillment-mix', { signal }),
  getDashboardNodePerformance: (signal?: AbortSignal) => apiConfiguration.useMockApi
    ? mockResponse({ items: nodePerformance }, signal) : apiClient.get<{ items: typeof nodePerformance }>('/dashboard/node-performance', { signal }),
  getDashboardInventoryPosition: (signal?: AbortSignal) => apiConfiguration.useMockApi
    ? mockResponse({ items: inventoryTrend }, signal) : apiClient.get<{ items: typeof inventoryTrend }>('/dashboard/inventory-position', { signal }),
  getDashboardExceptions: (signal?: AbortSignal) => apiConfiguration.useMockApi
    ? mockResponse({ items: exceptionTrend }, signal) : apiClient.get<{ items: typeof exceptionTrend }>('/dashboard/exceptions', { signal }),
  getDashboardBannerPerformance: (signal?: AbortSignal) => apiConfiguration.useMockApi
    ? mockResponse({ items: bannerPerformance }, signal) : apiClient.get<{ items: typeof bannerPerformance }>('/dashboard/banner-performance', { signal }),
  getDashboardReturns: (signal?: AbortSignal) => apiConfiguration.useMockApi
    ? mockResponse({ items: returnTrend }, signal) : apiClient.get<{ items: typeof returnTrend }>('/dashboard/returns', { signal }),
  getDashboardAlerts: (signal?: AbortSignal) => apiConfiguration.useMockApi
    ? mockResponse({ items: alerts }, signal) : apiClient.get<{ items: typeof alerts }>('/dashboard/alerts', { signal }),
  getDashboardActivities: (signal?: AbortSignal) => apiConfiguration.useMockApi
    ? mockResponse({ items: activities }, signal) : apiClient.get<{ items: typeof activities }>('/dashboard/activities', { signal }),
  getOrders: (signal?: AbortSignal, query: OrderQuery = {}) => apiConfiguration.useMockApi
    ? mockResponse(searchOrders(query), signal)
    : apiClient
        .post<OrderDetailsResponse>('/orders/details', buildOrderDetailsRequest(query), { signal })
        .then((payload) => normalizeOrderDetailsResponse(payload, query)),
  getInventory: (signal?: AbortSignal) => apiConfiguration.useMockApi
    ? mockResponse({ ...collection(inventoryRows), trend: inventoryTrend }, signal)
    : apiClient.get<InventoryResponse>('/inventory', { signal }),
  getProducts: (signal?: AbortSignal) => apiConfiguration.useMockApi
    ? mockResponse(collection(productCatalog), signal)
    : apiClient.get<CollectionResponse<Product>>('/products', { signal }),
  getSkuDocumentation: (sku: string, signal?: AbortSignal) => apiConfiguration.useMockApi
    ? mockResponse(skuDocumentationMock, signal)
    : apiClient.get<SkuDocumentationResponse>(`/products/${encodeURIComponent(sku)}/documentation`, { signal }),
  getUsers: (signal?: AbortSignal) => apiConfiguration.useMockApi
    ? mockResponse(collection(users), signal)
    : apiClient.get<CollectionResponse<OmsUser>>('/users', { signal }),
  addUser: (payload: AddUserRequest) => apiConfiguration.useMockApi
    ? mockResponse({
        ...payload,
        name: `${payload.firstName} ${payload.lastName}`.trim()
      })
    : apiClient.post<OmsUser>('/users', payload),
  updateUserAccess: (userId: string, payload: UpdateUserAccessRequest) => apiConfiguration.useMockApi
    ? mockResponse({ userId, message: 'Access update submitted', ...payload })
    : apiClient.patch<{ userId: string; status: string }>(`/users/${encodeURIComponent(userId)}/access`, payload),
  updateUserStatus: (userId: string, payload: UpdateUserStatusRequest) => apiConfiguration.useMockApi
    ? mockResponse({ userId, message: 'Status update submitted', ...payload })
    : apiClient.patch<{ userId: string; status: string }>(`/users/${encodeURIComponent(userId)}/status`, payload),
  getNotifications: (signal?: AbortSignal) => apiConfiguration.useMockApi
    ? mockResponse({ items: notificationsMock, total: notificationsMock.length }, signal)
    : apiClient.get<NotificationResponse>('/notifications', { signal }),
  getOrderStatusAiAnalytics: (signal?: AbortSignal, query: { orderCreatedFrom?: string; orderCreatedTo?: string } = {}) => apiConfiguration.useMockApi
    ? mockResponse(orderStatusAiAnalyticsMock, signal, 560)
    : apiClient.get<OrderStatusAiAnalyticsResponse>('/ai/order-status-analytics', { signal, query }),
  rereleaseToFulfillmentNode: (releaseId: string) => apiConfiguration.useMockApi
    ? mockResponse({ releaseId, status: 'Fulfillment node re-release requested' })
    : apiClient.post<{ releaseId: string; status: string }>(`/releases/${encodeURIComponent(releaseId)}/rerelease`),
  rerouteRelease: (releaseId: string, createDeliveryNote: boolean) => apiConfiguration.useMockApi
    ? mockResponse({ releaseId, status: 'Reroute requested', createDeliveryNote })
    : apiClient.post<{ releaseId: string; status: string; createDeliveryNote: boolean }>(`/releases/${encodeURIComponent(releaseId)}/reroute`, { createDeliveryNote }),
  hardCancelRelease: (releaseId: string) => apiConfiguration.useMockApi
    ? mockResponse({ releaseId, status: 'Hard cancellation requested' })
    : apiClient.post<{ releaseId: string; status: string }>(`/releases/${encodeURIComponent(releaseId)}/hard-cancel`),
  syncFulfillment: (fulfillmentId: string) => apiConfiguration.useMockApi
    ? mockResponse({ fulfillmentId, status: 'Synchronization requested' })
    : apiClient.post<{ fulfillmentId: string; status: string }>(`/fulfillments/${encodeURIComponent(fulfillmentId)}/sync`),
  updateStoreConfiguration: (storeId: string, payload: UpdateStoreConfigurationRequest) => apiConfiguration.useMockApi
    ? mockResponse({ storeId, message: 'Store configuration update submitted', ...payload })
    : apiClient.patch<{ storeId: string; status: string }>(`/utilities/stores/${encodeURIComponent(storeId)}/configuration`, payload)
};
