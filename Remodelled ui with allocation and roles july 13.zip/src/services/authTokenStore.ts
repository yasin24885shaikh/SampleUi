type TokenProvider = () => Promise<string | null> | string | null;

let tokenProvider: TokenProvider | undefined;

export const authTokenStore = {
  setTokenProvider(provider?: TokenProvider) {
    tokenProvider = provider;
  },
  async getAccessToken() {
    if (!tokenProvider) return null;
    return tokenProvider();
  },
  clear() {
    tokenProvider = undefined;
  }
};
