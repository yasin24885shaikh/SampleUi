# OMS REST API Integration

The UI reads and writes through `src/services/omsApi.ts`. It uses the populated mock REST adapter by default, so the demo works without a server.

## Connect a backend

Create `.env.local` from `.env.example` and set:

```env
VITE_API_BASE_URL=/api/v1
VITE_OMS_API_BASE_URL=/api/oms/v1
VITE_USER_API_BASE_URL=/api/users/v1
VITE_AI_API_BASE_URL=/api/ai/v1
VITE_OMS_API_TARGET=http://localhost:8080
VITE_USER_API_TARGET=http://localhost:8081
VITE_AI_API_TARGET=http://localhost:8090
VITE_API_TIMEOUT_MS=15000
VITE_USE_MOCK_API=false
```

Restart Vite after changing environment variables. During local development, Vite proxies same-origin frontend routes to backend services, which avoids browser CORS errors while still calling the real APIs.

| Frontend path | Backend target | Intended service |
| --- | --- | --- |
| `/api/v1/**` | `VITE_OMS_API_TARGET` | Default OMS compatibility route |
| `/api/oms/v1/**` | `VITE_OMS_API_TARGET` | OMS order APIs |
| `/api/users/v1/**` | `VITE_USER_API_TARGET` | User/admin APIs |
| `/api/ai/v1/**` | `VITE_AI_API_TARGET` | AI analytics APIs |

The proxy rewrites `/api/oms`, `/api/users`, and `/api/ai` back to `/api` before forwarding. For example, `/api/ai/v1/order-trace` is sent to `http://localhost:8090/api/v1/order-trace`.

Requests send and accept JSON and use `credentials: include` for cookie-based sessions. Authentication headers can be added once in `src/services/apiClient.ts` if the backend uses bearer tokens.

## Read endpoints

| Method | Endpoint | UI consumer | Response |
| --- | --- | --- | --- |
| GET | `/dashboard` | Executive Dashboard | `DashboardResponse` |
| POST | `/orders/details` | Order Live Tracking search | `CollectionResponse<Order>`, `{ "items": [] }`, `{ "orders": [] }`, `{ "data": [] }`, or raw `Order[]` |
| GET | `/inventory` | Inventory Management | `InventoryResponse` |
| GET | `/products` | Common Products | `CollectionResponse<Product>` |
| GET | `/products/{sku}/documentation` | SKU Documentation | `SkuDocumentationResponse` |
| GET | `/users` | User Management | `CollectionResponse<OmsUser>` |
| GET | `/notifications` | Header notification drawer | `NotificationResponse` |

`POST /orders/details` is called only when the user clicks Search. The request body sends the selected order IDs:

```json
{
  "orderIds": [
    "FL-10048291"
  ]
}
```

Collection responses use this envelope:

```json
{
  "items": [],
  "total": 0,
  "page": 1,
  "pageSize": 20
}
```

## Command endpoints

| Method | Endpoint | Request body |
| --- | --- | --- |
| POST | `/releases/{releaseId}/rerelease` | none |
| POST | `/releases/{releaseId}/reroute` | `{ "createDeliveryNote": true }` |
| POST | `/releases/{releaseId}/hard-cancel` | none |
| POST | `/fulfillments/{fulfillmentId}/sync` | none |

All TypeScript response contracts are exported from `src/services/omsApi.ts`. Failed non-2xx responses may return `{ "message": "..." }`; the shared client turns these into `ApiError` instances and the screens expose retry states.
