import type { OrderStatus } from '../utils/status';

export type Release = {
  releaseNumber: string;
  releaseLineId: string;
  orderLineId: string;
  itemId: string;
  releaseStatus: string;
  releaseDate: string;
  fulfillmentMethod: string;
  quantity: number;
  fulfilledQty: number;
  cancelledQty: number;
  assignedNode: string;
  updatedDate: string;
};

export type OrderLine = {
  lineNumber: string;
  sku: string;
  productName: string;
  orderedQty: number;
  fulfilledQty: number;
  cancelledQty: number;
  lineTotal: number;
  cancelledTotal: number;
  currentStatus: OrderStatus;
};

export type FulfillmentNode = {
  type: 'Distribution Center' | 'Store Fulfillment' | 'Supplier Fulfillment';
  id: string;
  name: string;
  location?: string;
  inventoryAvailable?: number;
  allocatedQty?: number;
  pickStatus?: string;
  supplierId?: string;
  asnNumber?: string;
  shipmentStatus?: string;
};

export type Fulfillment = {
  fulfillmentId: string;
  type: 'Warehouse' | 'Store' | 'Dropship' | 'Supplier';
  nodeId: string;
  nodeName: string;
  status: string;
  releaseNumber: string;
  releaseLineId: string;
  packageId: string;
  packageDetailId: string;
  shipmentId: string;
  quantity: number;
  shipVia: string;
  trackingNumber: string;
  createdDate?: string;
  updatedDate?: string;
};

export type CustomerCommunication = {
  dateTime: string;
  channel: 'Email' | 'Phone' | 'Chat' | 'Internal Note';
  agent: string;
  direction: 'Inbound' | 'Outbound' | 'Internal';
  summary: string;
  caseId: string;
};

export type OrderAddress = {
  line1: string;
  line2?: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
};

export type Order = {
  orderNumber: string;
  customerId: string;
  customerName: string;
  customerEmail: string;
  orderDate: string;
  orderType: string;
  enterprise: string;
  organization: string;
  paymentStatus: string;
  shippingAddress?: OrderAddress;
  billingAddress?: OrderAddress;
  returnOrderId?: string;
  totalAmount: number;
  status: OrderStatus;
  onHold: boolean;
  holdReason?: string;
  totalUnits: number;
  fulfillmentTypeSummary: string;
  fulfillmentType: 'DC' | 'Store' | 'Supplier' | 'Enterprise';
  communications: CustomerCommunication[];
  releases: Release[];
  lines: OrderLine[];
  nodes: FulfillmentNode[];
  fulfillments: Fulfillment[];
};

const featuredOrders: Order[] = [
  {
    orderNumber: 'FL-10048291',
    customerId: 'C-778193',
    customerName: 'Maya Johnson',
    customerEmail: 'maya.johnson@example.com',
    orderDate: '2026-06-19',
    orderType: 'Digital Ship-to-Home',
    enterprise: 'Foot Locker North America',
    organization: 'footlocker.com',
    paymentStatus: 'Authorized',
    totalAmount: 349.96,
    status: 'Released',
    onHold: true,
    holdReason: 'Address verification required',
    totalUnits: 4,
    fulfillmentTypeSummary: '2 DC releases, 1 store pickup',
    fulfillmentType: 'Enterprise',
    communications: [
      { dateTime: '2026-06-22 10:14 CT', channel: 'Email', agent: 'Erica Stone', direction: 'Outbound', summary: 'Requested confirmation of the delivery address before release.', caseId: 'CASE-90418' },
      { dateTime: '2026-06-22 11:02 CT', channel: 'Phone', agent: 'Sam Reed', direction: 'Inbound', summary: 'Customer confirmed billing and delivery address details.', caseId: 'CASE-90418' },
      { dateTime: '2026-06-22 11:18 CT', channel: 'Internal Note', agent: 'Fraud Operations', direction: 'Internal', summary: 'Address review completed; hold queued for release.', caseId: 'CASE-90418' }
    ],
    releases: [
      {
        releaseNumber: 'REL-900142',
        releaseLineId: '1',
        orderLineId: '1.1',
        itemId: 'FV5029-141',
        releaseStatus: 'Released',
        releaseDate: '2026-06-20',
        fulfillmentMethod: 'DC Ship',
        quantity: 2,
        fulfilledQty: 0,
        cancelledQty: 0,
        assignedNode: 'ATL-DC-01',
        updatedDate: '2026-06-20 14:32 CT'
      },
      {
        releaseNumber: 'REL-900143',
        releaseLineId: '2',
        orderLineId: '2.1',
        itemId: 'ID3715',
        releaseStatus: 'Scheduled',
        releaseDate: '2026-06-20',
        fulfillmentMethod: 'Store Pickup',
        quantity: 1,
        fulfilledQty: 1,
        cancelledQty: 0,
        assignedNode: 'ST-1842',
        updatedDate: '2026-06-20 15:08 CT'
      },
      {
        releaseNumber: 'REL-900144',
        releaseLineId: '3',
        orderLineId: '2.1',
        itemId: 'ID3715',
        releaseStatus: 'Released',
        releaseDate: '2026-06-20',
        fulfillmentMethod: 'DC Ship',
        quantity: 1,
        fulfilledQty: 0,
        cancelledQty: 0,
        assignedNode: 'JC-WH-01',
        updatedDate: '2026-06-20 16:24 CT'
      },
      {
        releaseNumber: 'REL-900145',
        releaseLineId: '4',
        orderLineId: '2.1',
        itemId: 'ID3715',
        releaseStatus: 'Released',
        releaseDate: '2026-06-20',
        fulfillmentMethod: 'Dropship',
        quantity: 1,
        fulfilledQty: 0,
        cancelledQty: 0,
        assignedNode: 'DS-NIKE-08',
        updatedDate: '2026-06-20 16:41 CT'
      }
    ],
    lines: [
      {
        lineNumber: '1.1',
        sku: 'FV5029-141',
        productName: 'Nike Air Max Dn White Metallic Silver',
        orderedQty: 1,
        fulfilledQty: 0,
        cancelledQty: 0,
        lineTotal: 139.99,
        cancelledTotal: 0,
        currentStatus: 'Released'
      },
      {
        lineNumber: '2.1',
        sku: 'ID3715',
        productName: 'adidas Samba OG Cloud White',
        orderedQty: 3,
        fulfilledQty: 1,
        cancelledQty: 0,
        lineTotal: 209.97,
        cancelledTotal: 0,
        currentStatus: 'Scheduled'
      }
    ],
    nodes: [
      {
        type: 'Distribution Center',
        id: 'ATL-DC-01',
        name: 'Atlanta Distribution Campus',
        inventoryAvailable: 1840,
        allocatedQty: 2
      },
      {
        type: 'Store Fulfillment',
        id: 'ST-1842',
        name: 'Foot Locker Lenox Square',
        location: 'Atlanta, GA',
        pickStatus: 'Awaiting Pick'
      }
    ],
    fulfillments: [
      {
        fulfillmentId: 'FUL-610041',
        type: 'Warehouse',
        nodeId: 'JC-WH-01',
        nodeName: 'JC Warehouse',
        status: 'Manifested',
        releaseNumber: 'REL-900142',
        releaseLineId: '1',
        packageId: 'PKG-770142',
        packageDetailId: 'PKGD-770142-01',
        shipmentId: 'SHP-550142',
        quantity: 1,
        shipVia: 'UPS Ground',
        trackingNumber: '1ZFL6100418821'
      },
      {
        fulfillmentId: 'FUL-610042',
        type: 'Store',
        nodeId: 'ST-1842',
        nodeName: 'Foot Locker Lenox Square',
        status: 'Ready for Pickup',
        releaseNumber: 'REL-900143',
        releaseLineId: '2',
        packageId: 'PKG-770143',
        packageDetailId: 'PKGD-770143-01',
        shipmentId: 'SHP-550143',
        quantity: 1,
        shipVia: 'Store Pickup',
        trackingNumber: 'PICKUP-1842-143'
      },
      {
        fulfillmentId: 'FUL-610044',
        type: 'Warehouse',
        nodeId: 'JC-WH-01',
        nodeName: 'JC Warehouse',
        status: 'Awaiting Pick',
        releaseNumber: 'REL-900144',
        releaseLineId: '3',
        packageId: 'PKG-770145',
        packageDetailId: 'PKGD-770145-01',
        shipmentId: 'SHP-550145',
        quantity: 1,
        shipVia: 'UPS Ground',
        trackingNumber: 'Pending'
      },
      {
        fulfillmentId: 'FUL-610043',
        type: 'Dropship',
        nodeId: 'DS-NIKE-08',
        nodeName: 'Nike Dropship Network',
        status: 'Label Created',
        releaseNumber: 'REL-900145',
        releaseLineId: '4',
        packageId: 'PKG-770144',
        packageDetailId: 'PKGD-770144-01',
        shipmentId: 'SHP-550144',
        quantity: 1,
        shipVia: 'FedEx Home Delivery',
        trackingNumber: '784512903661'
      }
    ]
  },
  {
    orderNumber: 'FL-10048307',
    customerId: 'C-554028',
    customerName: 'Daniel Kim',
    customerEmail: 'daniel.kim@example.com',
    orderDate: '2026-06-20',
    orderType: 'Launch Reservation',
    enterprise: 'Foot Locker North America',
    organization: 'Champs Sports',
    paymentStatus: 'Captured',
    totalAmount: 219.99,
    status: 'Shipped',
    onHold: false,
    totalUnits: 1,
    fulfillmentTypeSummary: 'Supplier direct ship',
    fulfillmentType: 'Supplier',
    communications: [
      { dateTime: '2026-06-21 09:05 CT', channel: 'Chat', agent: 'Nina Brooks', direction: 'Inbound', summary: 'Customer requested tracking details for the launch order.', caseId: 'CASE-90463' },
      { dateTime: '2026-06-21 09:12 CT', channel: 'Chat', agent: 'Nina Brooks', direction: 'Outbound', summary: 'Shared carrier tracking and estimated delivery date.', caseId: 'CASE-90463' }
    ],
    releases: [
      {
        releaseNumber: 'REL-900188',
        releaseLineId: '1',
        orderLineId: '1.1',
        itemId: 'HF2903-100',
        releaseStatus: 'Shipped',
        releaseDate: '2026-06-20',
        fulfillmentMethod: 'Supplier Direct',
        quantity: 1,
        fulfilledQty: 1,
        cancelledQty: 0,
        assignedNode: 'SUP-NIKE-08',
        updatedDate: '2026-06-21 08:41 CT'
      }
    ],
    lines: [
      {
        lineNumber: '1.1',
        sku: 'HF2903-100',
        productName: 'Jordan Retro 4 White Thunder',
        orderedQty: 1,
        fulfilledQty: 1,
        cancelledQty: 0,
        lineTotal: 219.99,
        cancelledTotal: 0,
        currentStatus: 'Shipped'
      }
    ],
    nodes: [
      {
        type: 'Supplier Fulfillment',
        id: 'SUP-NIKE-08',
        name: 'Nike Memphis Direct Ship',
        supplierId: 'NIKE-US',
        asnNumber: 'ASN-661982',
        shipmentStatus: 'In Transit'
      }
    ],
    fulfillments: [
      {
        fulfillmentId: 'FUL-610188',
        type: 'Supplier',
        nodeId: 'SUP-NIKE-08',
        nodeName: 'Nike Memphis Direct Ship',
        status: 'In Transit',
        releaseNumber: 'REL-900188',
        releaseLineId: '1',
        packageId: 'PKG-770188',
        packageDetailId: 'PKGD-770188-01',
        shipmentId: 'SHP-550188',
        quantity: 1,
        shipVia: 'FedEx 2Day',
        trackingNumber: '612999084731'
      }
    ]
  },
  {
    orderNumber: 'FL-10048355',
    customerId: 'C-991703',
    customerName: 'Ari Williams',
    customerEmail: 'ari.williams@example.com',
    orderDate: '2026-06-21',
    orderType: 'Mobile App Order',
    enterprise: 'Foot Locker North America',
    organization: 'Kids Foot Locker',
    paymentStatus: 'Authorized',
    totalAmount: 129.98,
    status: 'Backordered',
    onHold: true,
    holdReason: 'Inventory allocation review',
    totalUnits: 2,
    fulfillmentTypeSummary: 'DC allocation exception',
    fulfillmentType: 'DC',
    communications: [
      { dateTime: '2026-06-22 08:46 CT', channel: 'Email', agent: 'Marcus Lee', direction: 'Outbound', summary: 'Advised customer of the inventory allocation delay.', caseId: 'CASE-90511' },
      { dateTime: '2026-06-22 13:20 CT', channel: 'Internal Note', agent: 'Inventory Helpdesk', direction: 'Internal', summary: 'Escalated allocation review to Camp Hill warehouse.', caseId: 'CASE-90511' }
    ],
    releases: [
      {
        releaseNumber: 'REL-900211',
        releaseLineId: '1',
        orderLineId: '1.1',
        itemId: 'BB550VTA',
        releaseStatus: 'Backordered',
        releaseDate: '2026-06-21',
        fulfillmentMethod: 'DC Ship',
        quantity: 2,
        fulfilledQty: 0,
        cancelledQty: 0,
        assignedNode: 'PHX-DC-02',
        updatedDate: '2026-06-21 19:16 CT'
      }
    ],
    lines: [
      {
        lineNumber: '1.1',
        sku: 'BB550VTA',
        productName: 'New Balance 550 Varsity Team',
        orderedQty: 2,
        fulfilledQty: 0,
        cancelledQty: 0,
        lineTotal: 129.98,
        cancelledTotal: 0,
        currentStatus: 'Backordered'
      }
    ],
    nodes: [
      {
        type: 'Distribution Center',
        id: 'PHX-DC-02',
        name: 'Phoenix Distribution Center',
        inventoryAvailable: 0,
        allocatedQty: 0
      }
    ],
    fulfillments: [
      {
        fulfillmentId: 'FUL-610211',
        type: 'Warehouse',
        nodeId: 'CPH-WH-03',
        nodeName: 'Camp Hill Warehouse',
        status: 'Awaiting Inventory',
        releaseNumber: 'REL-900211',
        releaseLineId: '1',
        packageId: 'PKG-770211',
        packageDetailId: 'PKGD-770211-01',
        shipmentId: 'SHP-550211',
        quantity: 2,
        shipVia: 'UPS Ground',
        trackingNumber: 'Pending'
      }
    ]
  },
  {
    orderNumber: 'FL-10048110',
    customerId: 'C-330182',
    customerName: 'Sofia Martinez',
    customerEmail: 'sofia.martinez@example.com',
    orderDate: '2026-06-18',
    orderType: 'Store Assisted Sale',
    enterprise: 'Foot Locker Canada',
    organization: 'Foot Locker CA',
    paymentStatus: 'Refunded',
    returnOrderId: 'RET-300194',
    totalAmount: 189.99,
    status: 'Cancelled',
    onHold: false,
    totalUnits: 1,
    fulfillmentTypeSummary: 'Store fulfillment cancelled',
    fulfillmentType: 'Store',
    communications: [
      { dateTime: '2026-06-18 16:40 CT', channel: 'Phone', agent: 'Tanya Brooks', direction: 'Inbound', summary: 'Customer requested cancellation before store dispatch.', caseId: 'CASE-89971' },
      { dateTime: '2026-06-18 17:05 CT', channel: 'Email', agent: 'Tanya Brooks', direction: 'Outbound', summary: 'Cancellation and refund confirmation sent to customer.', caseId: 'CASE-89971' },
      { dateTime: '2026-06-19 07:35 CT', channel: 'Internal Note', agent: 'Returns Helpdesk', direction: 'Internal', summary: 'Return order RET-300194 linked to the original transaction.', caseId: 'CASE-89971' }
    ],
    releases: [
      {
        releaseNumber: 'REL-899981',
        releaseLineId: '1',
        orderLineId: '1.1',
        itemId: 'U9060ECA',
        releaseStatus: 'Cancelled',
        releaseDate: '2026-06-18',
        fulfillmentMethod: 'Store Ship',
        quantity: 1,
        fulfilledQty: 0,
        cancelledQty: 1,
        assignedNode: 'ST-4501',
        updatedDate: '2026-06-18 17:52 CT'
      }
    ],
    lines: [
      {
        lineNumber: '1.1',
        sku: 'U9060ECA',
        productName: 'New Balance 9060 Sea Salt',
        orderedQty: 1,
        fulfilledQty: 0,
        cancelledQty: 1,
        lineTotal: 189.99,
        cancelledTotal: 189.99,
        currentStatus: 'Cancelled'
      }
    ],
    nodes: [
      {
        type: 'Store Fulfillment',
        id: 'ST-4501',
        name: 'Foot Locker Eaton Centre',
        location: 'Toronto, ON',
        pickStatus: 'Cancelled at Source'
      }
    ],
    fulfillments: [
      {
        fulfillmentId: 'FUL-609981',
        type: 'Store',
        nodeId: 'ST-4501',
        nodeName: 'Foot Locker Eaton Centre',
        status: 'Cancelled',
        releaseNumber: 'REL-899981',
        releaseLineId: '1',
        packageId: 'PKG-769981',
        packageDetailId: 'PKGD-769981-01',
        shipmentId: 'SHP-549981',
        quantity: 1,
        shipVia: 'Store Ship',
        trackingNumber: 'Not Shipped'
      }
    ]
  }
];

const additionalOrderNames = [
  'Olivia Carter', 'Ethan Brown', 'Ava Thompson', 'Noah Davis', 'Isabella Moore', 'Liam Wilson',
  'Sophia Anderson', 'Mason Taylor', 'Mia Thomas', 'Lucas Jackson', 'Amelia White', 'Elijah Harris',
  'Harper Martin', 'James Garcia', 'Evelyn Martinez', 'Benjamin Robinson', 'Luna Clark', 'Henry Rodriguez',
  'Camila Lewis', 'Alexander Lee', 'Sofia Walker', 'Daniel Hall', 'Aria Allen', 'Michael Young'
];

const additionalOrderStatuses: OrderStatus[] = [
  'Created', 'Scheduled', 'Open', 'Released', 'Picked', 'Packed', 'Backordered', 'Shipped',
  'Delivered', 'Cancelled', 'Pending Return', 'Return', 'Return Initiated', 'Returned',
  'Released', 'Shipped', 'Open', 'Packed', 'Delivered', 'Backordered', 'Scheduled', 'Picked', 'Shipped', 'Created'
];

const additionalProducts = [
  { sku: 'FN7805-001', name: 'Nike Vomero 5 Photon Dust', price: 160 },
  { sku: 'IE3439', name: 'adidas Campus 00s Core Black', price: 110 },
  { sku: 'CT8532-106', name: 'Jordan Retro 3 White Cement', price: 210 },
  { sku: 'M2002RST', name: 'New Balance 2002R Steel', price: 145 },
  { sku: '398846-02', name: 'PUMA Speedcat OG Red White', price: 100 },
  { sku: '1203A383-101', name: 'ASICS GEL-Kayano 14 White Sage', price: 150 }
];

const additionalLocations: Array<{ type: Fulfillment['type']; id: string; name: string; location: string; shipVia: string }> = [
  { type: 'Warehouse', id: 'JC-WH-01', name: 'JC Warehouse', location: 'Junction City, KS', shipVia: 'UPS Ground' },
  { type: 'Warehouse', id: 'RNO-WH-02', name: 'Reno Warehouse', location: 'Reno, NV', shipVia: 'FedEx 2Day' },
  { type: 'Warehouse', id: 'CPH-WH-03', name: 'Camp Hill Warehouse', location: 'Camp Hill, PA', shipVia: 'UPS Ground' },
  { type: 'Store', id: 'ST-1093', name: 'Foot Locker North Michigan', location: 'Chicago, IL', shipVia: 'Store Pickup' },
  { type: 'Store', id: 'ST-2268', name: 'Foot Locker Glendale Galleria', location: 'Glendale, CA', shipVia: 'Store Ship' },
  { type: 'Dropship', id: 'DS-ADI-04', name: 'adidas Dropship Network', location: 'Spartanburg, SC', shipVia: 'FedEx Home Delivery' },
  { type: 'Supplier', id: 'SUP-NB-12', name: 'New Balance Direct Fulfillment', location: 'Lawrence, MA', shipVia: 'UPS SurePost' }
];

const statusToExecution: Record<OrderStatus, string> = {
  Created: 'Awaiting Allocation',
  Scheduled: 'Scheduled',
  Open: 'Open',
  Released: 'Released to Node',
  Picked: 'Picked',
  Packed: 'Packed',
  Backordered: 'Awaiting Inventory',
  Shipped: 'In Transit',
  Delivered: 'Delivered',
  Cancelled: 'Cancelled',
  'Pending Return': 'Return Pending',
  Return: 'Return In Transit',
  'Return Initiated': 'Return Authorized',
  Returned: 'Returned'
};

const additionalOrders: Order[] = additionalOrderNames.map((customerName, index) => {
  const status = additionalOrderStatuses[index];
  const product = additionalProducts[index % additionalProducts.length];
  const location = additionalLocations[index % additionalLocations.length];
  const quantity = (index % 3) + 1;
  const sequence = 901000 + index;
  const orderSequence = 10048400 + index * 7;
  const isCancelled = status === 'Cancelled';
  const isCompleted = status === 'Shipped' || status === 'Delivered';
  const isReturn = status === 'Pending Return' || status === 'Return' || status === 'Return Initiated' || status === 'Returned';
  const onHold = status === 'Backordered' || (status === 'Open' && index % 2 === 0);
  const organization = ['footlocker.com', 'Champs Sports', 'Kids Foot Locker', 'Foot Locker CA'][index % 4];
  const customerEmail = `${customerName.toLowerCase().replace(/ /g, '.')}@example.com`;
  const fulfillmentType: Order['fulfillmentType'] = location.type === 'Warehouse' ? 'DC' : location.type === 'Store' ? 'Store' : 'Supplier';
  const nodeType: FulfillmentNode['type'] = location.type === 'Warehouse' ? 'Distribution Center' : location.type === 'Store' ? 'Store Fulfillment' : 'Supplier Fulfillment';

  return {
    orderNumber: `FL-${orderSequence}`,
    customerId: `C-${620000 + index * 317}`,
    customerName,
    customerEmail,
    orderDate: `2026-06-${String((index % 22) + 1).padStart(2, '0')}`,
    orderType: location.type === 'Store' ? 'Store Pickup' : index % 4 === 0 ? 'Mobile App Order' : 'Digital Ship-to-Home',
    enterprise: 'Foot Locker North America',
    organization,
    paymentStatus: isCancelled || isReturn ? 'Refunded' : isCompleted ? 'Captured' : 'Authorized',
    returnOrderId: isReturn ? `RET-${310000 + index}` : undefined,
    totalAmount: product.price * quantity,
    status,
    onHold,
    holdReason: onHold ? (status === 'Backordered' ? 'Inventory allocation pending' : 'Payment review required') : undefined,
    totalUnits: quantity,
    fulfillmentTypeSummary: `${quantity} unit${quantity > 1 ? 's' : ''} via ${location.name}`,
    fulfillmentType,
    communications: [
      {
        dateTime: `2026-06-${String((index % 22) + 1).padStart(2, '0')} ${String(9 + (index % 8)).padStart(2, '0')}:15 CT`,
        channel: index % 3 === 0 ? 'Chat' : index % 3 === 1 ? 'Email' : 'Internal Note',
        agent: index % 2 === 0 ? 'Erica Stone' : 'Sam Reed',
        direction: index % 3 === 2 ? 'Internal' : 'Outbound',
        summary: `${status} status reviewed for ${location.name}.`,
        caseId: `CASE-${91000 + index}`
      }
    ],
    releases: [
      {
        releaseNumber: `REL-${sequence}`,
        releaseLineId: '1',
        orderLineId: '1.1',
        itemId: product.sku,
        releaseStatus: status,
        releaseDate: `2026-06-${String((index % 22) + 1).padStart(2, '0')}`,
        fulfillmentMethod: location.type === 'Warehouse' ? 'DC Ship' : location.type === 'Store' ? 'Store Fulfillment' : location.type,
        quantity,
        fulfilledQty: isCompleted || status === 'Returned' ? quantity : 0,
        cancelledQty: isCancelled ? quantity : 0,
        assignedNode: location.id,
        updatedDate: `2026-06-${String((index % 22) + 1).padStart(2, '0')} 16:30 CT`
      }
    ],
    lines: [
      {
        lineNumber: '1.1',
        sku: product.sku,
        productName: product.name,
        orderedQty: quantity,
        fulfilledQty: isCompleted || status === 'Returned' ? quantity : 0,
        cancelledQty: isCancelled ? quantity : 0,
        lineTotal: product.price * quantity,
        cancelledTotal: isCancelled ? product.price * quantity : 0,
        currentStatus: status
      }
    ],
    nodes: [
      {
        type: nodeType,
        id: location.id,
        name: location.name,
        location: location.location,
        inventoryAvailable: location.type === 'Warehouse' ? 420 + index * 17 : undefined,
        allocatedQty: location.type === 'Warehouse' ? quantity : undefined,
        pickStatus: location.type === 'Store' ? statusToExecution[status] : undefined,
        supplierId: location.type === 'Supplier' || location.type === 'Dropship' ? location.id : undefined,
        shipmentStatus: statusToExecution[status]
      }
    ],
    fulfillments: [
      {
        fulfillmentId: `FUL-${611000 + index}`,
        type: location.type,
        nodeId: location.id,
        nodeName: location.name,
        status: statusToExecution[status],
        releaseNumber: `REL-${sequence}`,
        releaseLineId: '1',
        packageId: `PKG-${771000 + index}`,
        packageDetailId: `PKGD-${771000 + index}-01`,
        shipmentId: `SHP-${551000 + index}`,
        quantity,
        shipVia: location.shipVia,
        trackingNumber: isCompleted ? `1ZFL${String(611000 + index).padStart(12, '0')}` : 'Pending'
      }
    ]
  };
});

const stressProducts = [
  { sku: 'HV2531-101', name: 'Nike Pegasus Premium White Crimson', price: 190 },
  { sku: 'JI2734', name: 'adidas Adizero EVO SL Core Black', price: 150 },
  { sku: 'FQ1759-100', name: 'Jordan Flight Court Summit White', price: 115 },
  { sku: 'U740WM2', name: 'New Balance 740 White Midnight', price: 110 },
  { sku: '1203A549-020', name: 'ASICS GEL-NYC Graphite Grey', price: 130 },
  { sku: 'VN000D5IBKA', name: 'Vans Knu Skool Black White', price: 75 },
  { sku: '396403-01', name: 'PUMA Palermo Leather White Green', price: 90 },
  { sku: '100074456', name: 'Reebok Club C Grounds UK Chalk', price: 85 },
  { sku: 'A12363C', name: 'Converse Weapon Ox Egret', price: 100 },
  { sku: 'DM1124-102', name: 'Nike Dunk Low Retro White Black', price: 115 }
];

const stressLocations: Array<{ type: Fulfillment['type']; id: string; name: string; method: string; shipVia: string; status: string; trackingPrefix: string }> = [
  { type: 'Warehouse', id: 'JC-WH-01', name: 'JC Warehouse', method: 'DC Ship', shipVia: 'UPS Ground', status: 'Awaiting Pick', trackingPrefix: '1ZJC' },
  { type: 'Warehouse', id: 'RNO-WH-02', name: 'Reno Warehouse', method: 'DC Ship', shipVia: 'FedEx 2Day', status: 'Manifested', trackingPrefix: 'RNO' },
  { type: 'Warehouse', id: 'CPH-WH-03', name: 'Camp Hill Warehouse', method: 'DC Ship', shipVia: 'UPS Ground', status: 'Packed', trackingPrefix: '1ZCPH' },
  { type: 'Store', id: 'ST-1093', name: 'Foot Locker North Michigan', method: 'Store Fulfillment', shipVia: 'Store Ship', status: 'Ready for Pickup', trackingPrefix: 'ST1093' },
  { type: 'Dropship', id: 'DS-ADI-04', name: 'adidas Dropship Network', method: 'Dropship', shipVia: 'FedEx Home Delivery', status: 'Label Created', trackingPrefix: 'DSADI' },
  { type: 'Supplier', id: 'SUP-NB-12', name: 'New Balance Direct Fulfillment', method: 'Supplier Direct', shipVia: 'UPS SurePost', status: 'In Transit', trackingPrefix: 'SUPNB' }
];

const stressLines: OrderLine[] = Array.from({ length: 500 }, (_, index) => {
  const product = stressProducts[index % stressProducts.length];
  const orderedQty = (index % 4) + 1;
  const isCancelled = index % 13 === 0;
  const isFulfilled = index % 3 === 0 && !isCancelled;
  return {
    lineNumber: `${index + 1}.1`,
    sku: product.sku,
    productName: product.name,
    orderedQty,
    fulfilledQty: isFulfilled ? orderedQty : 0,
    cancelledQty: isCancelled ? 1 : 0,
    lineTotal: product.price * orderedQty,
    cancelledTotal: isCancelled ? product.price : 0,
    currentStatus: isCancelled ? 'Cancelled' : isFulfilled ? 'Shipped' : index % 5 === 0 ? 'Backordered' : 'Released'
  };
});

const stressReleases: Release[] = stressLines.map((line, index) => {
  const location = stressLocations[index % stressLocations.length];
  return {
    releaseNumber: `REL-950${String(index + 1).padStart(3, '0')}`,
    releaseLineId: String(index + 1),
    orderLineId: line.lineNumber,
    itemId: line.sku,
    releaseStatus: line.currentStatus,
    releaseDate: `2026-06-${String((index % 18) + 5).padStart(2, '0')}`,
    fulfillmentMethod: location.method,
    quantity: line.orderedQty,
    fulfilledQty: line.fulfilledQty,
    cancelledQty: line.cancelledQty,
    assignedNode: location.id,
    updatedDate: `2026-06-${String((index % 18) + 5).padStart(2, '0')} ${String(10 + (index % 9)).padStart(2, '0')}:24 CT`
  };
});

const stressFulfillments: Fulfillment[] = stressReleases.map((release, index) => {
  const location = stressLocations[index % stressLocations.length];
  return {
    fulfillmentId: `FUL-690${String(index + 1).padStart(3, '0')}`,
    type: location.type,
    nodeId: location.id,
    nodeName: location.name,
    status: release.releaseStatus === 'Cancelled' ? 'Cancelled' : location.status,
    releaseNumber: release.releaseNumber,
    releaseLineId: release.releaseLineId,
    packageId: `PKG-790${String(index + 1).padStart(3, '0')}`,
    packageDetailId: `PKGD-790${String(index + 1).padStart(3, '0')}-01`,
    shipmentId: `SHP-590${String(index + 1).padStart(3, '0')}`,
    quantity: release.quantity,
    shipVia: location.shipVia,
    trackingNumber: release.releaseStatus === 'Released' || release.releaseStatus === 'Backordered'
      ? 'Pending'
      : `${location.trackingPrefix}${String(690000 + index).padStart(10, '0')}`
  };
});

const stressOrder: Order = {
  orderNumber: 'FL-10049999',
  customerId: 'C-995050',
  customerName: 'Enterprise Bulk Test',
  customerEmail: 'enterprise.bulk.test@example.com',
  orderDate: '2026-06-24',
  orderType: 'Enterprise Assortment Order',
  enterprise: 'Foot Locker North America',
  organization: 'footlocker.com',
  paymentStatus: 'Authorized',
  totalAmount: stressLines.reduce((total, line) => total + line.lineTotal, 0),
  status: 'Released',
  onHold: true,
  holdReason: 'High line-count orchestration validation',
  totalUnits: stressLines.reduce((total, line) => total + line.orderedQty, 0),
  fulfillmentTypeSummary: '500 lines across JC, Reno, Camp Hill, store, dropship, and supplier',
  fulfillmentType: 'Enterprise',
  communications: [
    { dateTime: '2026-06-24 09:12 CT', channel: 'Internal Note', agent: 'OMS Architecture', direction: 'Internal', summary: 'Created 500-line stress order to validate release and fulfillment popup performance.', caseId: 'CASE-95050' },
    { dateTime: '2026-06-24 09:38 CT', channel: 'Email', agent: 'Client Success', direction: 'Outbound', summary: 'Shared bulk order status and fulfillment split with leadership demo team.', caseId: 'CASE-95050' }
  ],
  releases: stressReleases,
  lines: stressLines,
  nodes: stressLocations.map((location, index) => ({
    type: location.type === 'Warehouse' ? 'Distribution Center' : location.type === 'Store' ? 'Store Fulfillment' : 'Supplier Fulfillment',
    id: location.id,
    name: location.name,
    location: location.type === 'Store' ? 'Chicago, IL' : undefined,
    inventoryAvailable: location.type === 'Warehouse' ? 1200 - index * 85 : undefined,
    allocatedQty: location.type === 'Warehouse' ? stressFulfillments.filter((fulfillment) => fulfillment.nodeId === location.id).reduce((total, fulfillment) => total + fulfillment.quantity, 0) : undefined,
    pickStatus: location.type === 'Store' ? 'Bulk pick wave ready' : undefined,
    supplierId: location.type === 'Supplier' || location.type === 'Dropship' ? location.id : undefined,
    shipmentStatus: location.status
  })),
  fulfillments: stressFulfillments
};

function createBulkOrder({
  sequence,
  lineCount,
  orderNumber,
  customerName,
  orderDate,
  status,
  holdReason
}: {
  sequence: number;
  lineCount: number;
  orderNumber: string;
  customerName: string;
  orderDate: string;
  status: OrderStatus;
  holdReason?: string;
}): Order {
  const lines: OrderLine[] = Array.from({ length: lineCount }, (_, index) => {
    const product = stressProducts[(index + sequence) % stressProducts.length];
    const orderedQty = ((index + sequence) % 5) + 1;
    const isCancelled = (index + sequence) % 17 === 0;
    const isFulfilled = (index + sequence) % 4 === 0 && !isCancelled;
    return {
      lineNumber: `${index + 1}.1`,
      sku: product.sku,
      productName: product.name,
      orderedQty,
      fulfilledQty: isFulfilled ? orderedQty : 0,
      cancelledQty: isCancelled ? 1 : 0,
      lineTotal: product.price * orderedQty,
      cancelledTotal: isCancelled ? product.price : 0,
      currentStatus: isCancelled ? 'Cancelled' : isFulfilled ? 'Shipped' : status === 'Backordered' && index % 3 === 0 ? 'Backordered' : 'Released'
    };
  });
  const releases: Release[] = lines.map((line, index) => {
    const location = stressLocations[(index + sequence) % stressLocations.length];
    return {
      releaseNumber: `REL-${960000 + sequence * 1000 + index + 1}`,
      releaseLineId: String(index + 1),
      orderLineId: line.lineNumber,
      itemId: line.sku,
      releaseStatus: line.currentStatus,
      releaseDate: orderDate,
      fulfillmentMethod: location.method,
      quantity: line.orderedQty,
      fulfilledQty: line.fulfilledQty,
      cancelledQty: line.cancelledQty,
      assignedNode: location.id,
      updatedDate: `${orderDate} ${String(8 + (index % 11)).padStart(2, '0')}:42 CT`
    };
  });
  const fulfillments: Fulfillment[] = releases.map((release, index) => {
    const location = stressLocations[(index + sequence) % stressLocations.length];
    return {
      fulfillmentId: `FUL-${760000 + sequence * 1000 + index + 1}`,
      type: location.type,
      nodeId: location.id,
      nodeName: location.name,
      status: release.releaseStatus === 'Cancelled' ? 'Cancelled' : location.status,
      releaseNumber: release.releaseNumber,
      releaseLineId: release.releaseLineId,
      packageId: `PKG-${860000 + sequence * 1000 + index + 1}`,
      packageDetailId: `PKGD-${860000 + sequence * 1000 + index + 1}-01`,
      shipmentId: `SHP-${660000 + sequence * 1000 + index + 1}`,
      quantity: release.quantity,
      shipVia: location.shipVia,
      trackingNumber: release.releaseStatus === 'Released' || release.releaseStatus === 'Backordered'
        ? 'Pending'
        : `${location.trackingPrefix}${String(760000 + sequence * 1000 + index).padStart(10, '0')}`
    };
  });

  return {
    orderNumber,
    customerId: `NC-${995000 + sequence}`,
    customerName,
    customerEmail: `${customerName.toLowerCase().replace(/[^a-z0-9]+/g, '.')}@footlocker.ops`,
    orderDate,
    orderType: 'Enterprise Bulk Allocation',
    enterprise: 'Foot Locker North America',
    organization: sequence % 2 === 0 ? 'footlocker.com' : 'Champs Sports',
    paymentStatus: sequence % 2 === 0 ? 'Authorized' : 'Captured',
    totalAmount: lines.reduce((total, line) => total + line.lineTotal, 0),
    status,
    onHold: Boolean(holdReason),
    holdReason,
    totalUnits: lines.reduce((total, line) => total + line.orderedQty, 0),
    fulfillmentTypeSummary: `${lineCount} lines across JC, Reno, Camp Hill, store, dropship, and supplier`,
    fulfillmentType: 'Enterprise',
    communications: [
      { dateTime: `${orderDate} 08:15 CT`, channel: 'Internal Note', agent: 'Bulk Order Ops', direction: 'Internal', summary: `Created ${lineCount}-line non-customer bulk order for allocation operations.`, caseId: `CASE-${995000 + sequence}` },
      { dateTime: `${orderDate} 09:05 CT`, channel: 'Email', agent: 'Command Center', direction: 'Outbound', summary: 'Shared fulfillment split and exception summary with operations leadership.', caseId: `CASE-${995000 + sequence}` }
    ],
    releases,
    lines,
    nodes: stressLocations.map((location, index) => ({
      type: location.type === 'Warehouse' ? 'Distribution Center' : location.type === 'Store' ? 'Store Fulfillment' : 'Supplier Fulfillment',
      id: location.id,
      name: location.name,
      location: location.type === 'Store' ? 'Chicago, IL' : undefined,
      inventoryAvailable: location.type === 'Warehouse' ? 980 - index * 70 : undefined,
      allocatedQty: location.type === 'Warehouse' ? fulfillments.filter((fulfillment) => fulfillment.nodeId === location.id).reduce((total, fulfillment) => total + fulfillment.quantity, 0) : undefined,
      pickStatus: location.type === 'Store' ? 'Bulk pick wave ready' : undefined,
      supplierId: location.type === 'Supplier' || location.type === 'Dropship' ? location.id : undefined,
      shipmentStatus: location.status
    })),
    fulfillments
  };
}

const nonCustomerBulkOrders: Order[] = [
  stressOrder,
  createBulkOrder({
    sequence: 2,
    lineCount: 125,
    orderNumber: 'FL-10050024',
    customerName: 'Enterprise Store Replenishment',
    orderDate: '2026-06-25',
    status: 'Backordered',
    holdReason: 'Allocation review for constrained sizes'
  }),
  createBulkOrder({
    sequence: 3,
    lineCount: 80,
    orderNumber: 'FL-10050031',
    customerName: 'Field Marketing Kit Order',
    orderDate: '2026-06-26',
    status: 'Released'
  }),
  createBulkOrder({
    sequence: 4,
    lineCount: 45,
    orderNumber: 'FL-10050044',
    customerName: 'Training Store Fixture Order',
    orderDate: '2026-06-27',
    status: 'Shipped'
  })
];

function withNumericReleaseLineIds(order: Order): Order {
  const releaseLineMap = new Map<string, string>();
  const releaseByOriginalLineId = new Map(order.releases.map((release) => [release.releaseLineId, release]));
  const releases = order.releases.map((release, index) => {
    const releaseLineId = String(index + 1);
    releaseLineMap.set(release.releaseLineId, releaseLineId);
    return { ...release, releaseLineId };
  });

  const fulfillments = order.fulfillments.map((fulfillment, index) => {
    const sourceRelease = releaseByOriginalLineId.get(fulfillment.releaseLineId);
    return {
      ...fulfillment,
      releaseLineId: releaseLineMap.get(fulfillment.releaseLineId) ?? fulfillment.releaseLineId,
      packageDetailId: String(index + 1),
      createdDate: fulfillment.createdDate ?? sourceRelease?.releaseDate ?? order.orderDate,
      updatedDate: fulfillment.updatedDate ?? sourceRelease?.updatedDate ?? sourceRelease?.releaseDate ?? order.orderDate
    };
  });

  return { ...order, releases, fulfillments };
}

export const orders: Order[] = [...nonCustomerBulkOrders, ...featuredOrders, ...additionalOrders].map(withNumericReleaseLineIds);

export const dashboardKpis = [
  { label: 'Total Orders', value: '38,492', delta: '+11.8% vs LW', tone: '#d71920' },
  { label: 'Open Orders', value: '8,216', delta: '+4.2% vs LW', tone: '#1769e0' },
  { label: 'Released Orders', value: '12,874', delta: '+7.5% vs LW', tone: '#e77718' },
  { label: 'Fulfilled Orders', value: '16,204', delta: '+13.1% vs LW', tone: '#168a51' },
  { label: 'Cancelled Orders', value: '1,198', delta: '-2.7% vs LW', tone: '#c62828' },
  { label: 'Inventory Availability', value: '94.6%', delta: '+1.9 pts', tone: '#117c8b' },
  { label: 'Gross Demand', value: '$8.42M', delta: '+9.6% vs LW', tone: '#7c3aed' },
  { label: 'Net Sales', value: '$7.96M', delta: '+10.2% vs LW', tone: '#0f766e' },
  { label: 'Fill Rate', value: '96.8%', delta: '+1.4 pts', tone: '#168a51' },
  { label: 'On-Time Ship', value: '94.2%', delta: '+2.1 pts', tone: '#1769e0' },
  { label: 'Perfect Order Rate', value: '91.7%', delta: '+1.2 pts', tone: '#b45309' },
  { label: 'Average Cycle Time', value: '6.4h', delta: '-0.8h vs LW', tone: '#475569' }
];

export const ordersByStatus = [
  { name: 'Created', value: 4280 },
  { name: 'Released', value: 12874 },
  { name: 'Shipped', value: 9105 },
  { name: 'Delivered', value: 7099 },
  { name: 'Cancelled', value: 1198 }
];

export const fulfillmentMix = [
  { name: 'DC', orders: 15420 },
  { name: 'Store', orders: 11480 },
  { name: 'Supplier', orders: 5220 },
  { name: 'Enterprise', orders: 6372 }
];

export const inventoryTrend = [
  { day: 'Mon', available: 93, reserved: 28 },
  { day: 'Tue', available: 95, reserved: 31 },
  { day: 'Wed', available: 94, reserved: 34 },
  { day: 'Thu', available: 96, reserved: 30 },
  { day: 'Fri', available: 94, reserved: 36 },
  { day: 'Sat', available: 92, reserved: 41 },
  { day: 'Sun', available: 95, reserved: 35 }
];

export const dailyOrderVolume = [
  { day: 'Jun 15', orders: 4210, grossDemand: 0.91, netSales: 0.85 },
  { day: 'Jun 16', orders: 4388, grossDemand: 0.97, netSales: 0.91 },
  { day: 'Jun 17', orders: 4621, grossDemand: 1.03, netSales: 0.98 },
  { day: 'Jun 18', orders: 4910, grossDemand: 1.12, netSales: 1.06 },
  { day: 'Jun 19', orders: 5238, grossDemand: 1.24, netSales: 1.18 },
  { day: 'Jun 20', orders: 5875, grossDemand: 1.68, netSales: 1.58 },
  { day: 'Jun 21', orders: 5512, grossDemand: 1.47, netSales: 1.40 }
];

export const serviceLevelTrend = [
  { day: 'Jun 15', fillRate: 94.8, onTimeShip: 91.2, perfectOrder: 88.7 },
  { day: 'Jun 16', fillRate: 95.1, onTimeShip: 91.9, perfectOrder: 89.2 },
  { day: 'Jun 17', fillRate: 95.6, onTimeShip: 92.5, perfectOrder: 89.9 },
  { day: 'Jun 18', fillRate: 96.0, onTimeShip: 92.8, perfectOrder: 90.1 },
  { day: 'Jun 19', fillRate: 96.3, onTimeShip: 93.4, perfectOrder: 90.8 },
  { day: 'Jun 20', fillRate: 96.5, onTimeShip: 93.8, perfectOrder: 91.2 },
  { day: 'Jun 21', fillRate: 96.8, onTimeShip: 94.2, perfectOrder: 91.7 }
];

export const exceptionTrend = [
  { day: 'Jun 15', inventory: 312, payment: 118, carrier: 76 },
  { day: 'Jun 16', inventory: 296, payment: 104, carrier: 82 },
  { day: 'Jun 17', inventory: 341, payment: 96, carrier: 71 },
  { day: 'Jun 18', inventory: 278, payment: 91, carrier: 68 },
  { day: 'Jun 19', inventory: 254, payment: 87, carrier: 61 },
  { day: 'Jun 20', inventory: 231, payment: 79, carrier: 56 },
  { day: 'Jun 21', inventory: 218, payment: 73, carrier: 49 }
];

export const bannerPerformance = [
  { name: 'Foot Locker', orders: 19420, revenue: 4.21, fillRate: 97.4 },
  { name: 'Champs Sports', orders: 8930, revenue: 1.94, fillRate: 96.8 },
  { name: 'Kids Foot Locker', orders: 6142, revenue: 1.18, fillRate: 95.9 },
  { name: 'Foot Locker CA', orders: 4000, revenue: 0.63, fillRate: 94.7 }
];

export const nodePerformance = [
  { name: 'JC Warehouse', onTime: 97.2, fillRate: 98.1, backlog: 412 },
  { name: 'Reno Warehouse', onTime: 95.8, fillRate: 97.4, backlog: 528 },
  { name: 'Camp Hill', onTime: 93.9, fillRate: 96.2, backlog: 684 },
  { name: 'Store Network', onTime: 92.7, fillRate: 95.6, backlog: 936 },
  { name: 'Supplier Direct', onTime: 90.8, fillRate: 94.9, backlog: 377 }
];

export const returnTrend = [
  { week: 'W20', returnRate: 8.4, refundCycle: 3.8 },
  { week: 'W21', returnRate: 8.1, refundCycle: 3.6 },
  { week: 'W22', returnRate: 7.9, refundCycle: 3.5 },
  { week: 'W23', returnRate: 8.3, refundCycle: 3.3 },
  { week: 'W24', returnRate: 7.7, refundCycle: 3.1 },
  { week: 'W25', returnRate: 7.4, refundCycle: 2.9 }
];

export const activities = [
  'REL-900188 shipped from Nike Memphis Direct Ship',
  'FL-10048355 moved to backorder after PHX-DC-02 shortage',
  'Inventory sync completed for 1,284 Foot Locker stores',
  'ST-1842 accepted pickup release REL-900143',
  'Payment authorization refreshed for high-value launch orders'
];

export const alerts = [
  { severity: 'High', text: 'BB550VTA has zero available units at PHX-DC-02' },
  { severity: 'Medium', text: '18 store pickup releases are beyond SLA in Midwest region' },
  { severity: 'Low', text: 'Supplier ASN feed latency detected for vendor ADI-US' }
];

export const inventoryRows = [
  { sku: 'FV5029-141', productName: 'Nike Air Max Dn White Metallic Silver', category: 'Running', available: 1840, reserved: 226, safety: 200, nodes: 'ATL-DC-01, ST-1842' },
  { sku: 'ID3715', productName: 'adidas Samba OG Cloud White', category: 'Lifestyle', available: 913, reserved: 148, safety: 160, nodes: 'DFW-DC-03, ST-1093' },
  { sku: 'HF2903-100', productName: 'Jordan Retro 4 White Thunder', category: 'Launch', available: 302, reserved: 277, safety: 250, nodes: 'SUP-NIKE-08' },
  { sku: 'BB550VTA', productName: 'New Balance 550 Varsity Team', category: 'Lifestyle', available: 0, reserved: 82, safety: 120, nodes: 'PHX-DC-02' },
  { sku: 'U9060ECA', productName: 'New Balance 9060 Sea Salt', category: 'Lifestyle', available: 620, reserved: 97, safety: 140, nodes: 'ST-4501, EWR-DC-04' }
];

export const productCatalog = inventoryRows.map((item, index) => ({
  ...item,
  price: [170, 100, 220, 115, 190][index],
  vendor: ['Nike', 'adidas', 'Jordan', 'New Balance', 'New Balance'][index],
  image: `https://images.unsplash.com/photo-${['1542291026-7eec264c27ff', '1608231387042-66d1773070a5', '1595950653106-6c9ebd614d3a', '1491553895911-0055eca6402d', '1525966222134-fcfa99b8ae77'][index]}?auto=format&fit=crop&w=900&q=80`
}));

export const users = [
  { userId: 'estone', firstName: 'Erica', lastName: 'Stone', name: 'Erica Stone', role: 'OMS Administrator', permissions: 'Full Access', status: 'Active' },
  { userId: 'rpatel', firstName: 'Ravi', lastName: 'Patel', name: 'Ravi Patel', role: 'Inventory Planner', permissions: 'Inventory, SKUDOC', status: 'Active' },
  { userId: 'tbrooks', firstName: 'Tanya', lastName: 'Brooks', name: 'Tanya Brooks', role: 'Store Operations', permissions: 'Orders, Store Nodes', status: 'Active' },
  { userId: 'mlee', firstName: 'Marcus', lastName: 'Lee', name: 'Marcus Lee', role: 'Support Analyst', permissions: 'Read Only', status: 'Disabled' }
];
